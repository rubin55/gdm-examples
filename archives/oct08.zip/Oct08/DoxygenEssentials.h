/// @file
/// @brief A documented file provided for Doxygen Essentials
///
/// Copyright 2008, Nicholas Olsen
///
/// Feel free to do whatever you want with this software
///
/// @author Nicholas Olsen
/// @version 0.0001
/// @date 2008

/// @addtogroup documentedStuff Documented Stuff
/// A group used to demonstrate Doxygen's grouping capabilities
/// @{

/// @brief A documented C++ class!
///
/// The Doxygenized class serves as a demonstration
/// of how to document C++ code using Doxygen
class Doxygenized {
public:
	/// @brief A documented method
	///
	/// The isDocumented method serves as an example of
	/// how to document methods, along with their parameters
	/// and return value.
	/// @return Always returns true, because this is a contrived example
	/// @param aParameter A documented method parameter. This parameter
	/// is not actually used. Its only purpose in life is to be documented
	bool isDocumented(int aParameter) {
		return true;
	}

	/// @brief A documented enumeration!
	///
	/// An example of documenting an enumeration and its members using
	/// the shorthand for placing documentation inline with declarations
	enum eNumbers {
		kOne,		///< The number One
		kTwo,		///< The number Two
		kThree	///< The Number Three
	};

	int aField; ///< An example documented field

};

/// @brief An unfinished class
/// @todo Figure out what this class
/// is supposed to do and implement it
class UnfinishedClass {
};

/// @brief A buggy function
/// @return num divided by zero
/// @param num number to divide by zero
/// @bug This function always crashes for some reason
int Boom(int num) {
	int divisor = 0;
	return num / divisor;
}

/// @brief A washed up, useless class
/// @deprecated Please don't ever use this code again
class Retired {
};


/// @}
