Dx8 Vertex Shaders Skinning Example
-------------------------------------
Graphic Content Column, April 2001
Game Developer Magazine


This is the final vertex shader from the article.