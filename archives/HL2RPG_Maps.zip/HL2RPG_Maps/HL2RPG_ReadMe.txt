Thank you for downloading the HL2: Ep2 RPG prototype example! Here is what you need to know to get started.

-Installation-

To play, just copy the folder named "ep2" into the location of your 
"half-life 2 episode two" folder.

For most users this will be located here:
"C:/Program files/Steam/steamapps/<YOUR STEAM USERNAME>/half-life 2 episode two/"

Since you are overwriting the existing "ep2" folder with this new one
it will most likely ask you if you want to merge folders, select "Yes" if you get that message.

To play, launch HL2:Ep2 and then go to Options > Keyboard > Advanced and make sure that 
"Enable Developer Console" is checked on. With that option checked, you can open up the console 
using the tilde ( ~ ) key.

Open up the console and type in "map " (without quotation marks) followed by the name of the map you 
wish to play. The name of the 2 provided maps are "D3_map_01" and "d3_map_01_textured".
"D3_map_01" is just the basic layout of the map, with no gameplay added.
"d3_map_01_textured" is a more refined layout of the map with the initial RPG gameplay added.
Hit enter to start playing!

(NOTE: The map is a work-in-progress example of an RPG within HL2. You will notice unfinished parts,
incorrect audio, etc.)


-Example .vmf files-

If you wish to study the example map to learn from it extract the 
folder named "rpg_example" to the folder "mapscr" in the "sdk_content" folder.

For most users this would be:
"C:/Program files/Steam/steamapps/<YOUR STEAM USERNAME>/sourcesdk_content/ep2/mapscr"

From the Source SDK window, launch Hammer and then go to File > Open and locate the map you want to open.

There are 2 maps included. "D3_map_01.vmf" is the basic outline of the level
which you may wish to use if you do not have a level to work with.

"d3_map_01_textured" is the example map. It is still a work-in-progress prototype, but has
functionality.

Also included is the quest instance that is explained in the
tutorial. You may wish to expand it or change it to work better for your ideas.


-Contact-

Please don't publish any of the content provided without
consent.
Any questions or queries about the tutorial or the example map
feel free to contact me via twitter @The_BenEvans

