// wrap = wraparound distance, for periodic noise
// must be a power of 2; 0 means no wrapping
extern float noise3(float x, float y, float z, int wrap);
