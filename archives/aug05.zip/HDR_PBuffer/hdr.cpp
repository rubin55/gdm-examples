/*
   High Dynamic Range Rendering - Using P Buffers
   Allen Sherrod
   Article for the Game Developers Magazine.
*/


#include<windows.h>
#include<gl/gl.h>
#include<gl/glu.h>
#include"glsl.h"
#include"CPBuffer.h"
#include"rgbeLoader.h"

#define WINDOW_WIDTH 640
#define WINDOW_HEIGHT 480

// Function Prototypes
bool InitializeGL();
bool InitPBuffers();
bool InitShaders();
void RenderScene();
void Shutdown();

HDC g_HDC;
HGLRC g_HRC;

// P Buffer.
CPBuffer fullSurface;

// HDR Texture image.
unsigned int hdrID = 0;
int hdrWidth = 0, hdrHeight = 0;
float exposure = 2.0f;

// Shader data.
GLhandleARB toneShader;
unsigned int glslToneOffset;
unsigned int glslToneFullTexture;
unsigned int glslToneExposure;


void SetupPixelFormat(HDC hDC)
{
   int nPixelFormat;

   static PIXELFORMATDESCRIPTOR pfd = { sizeof(PIXELFORMATDESCRIPTOR), 1,
         PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL | PFD_DOUBLEBUFFER, PFD_TYPE_RGBA,
         16, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 16, 0, 0,
         PFD_MAIN_PLANE, 0, 0, 0, 0 };

   nPixelFormat = ChoosePixelFormat(hDC, &pfd);
   SetPixelFormat(hDC, nPixelFormat, &pfd);
}


LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
   static HGLRC hRC;
   static HDC hDC;
   int width, height;

   switch(message)
      {
         case WM_CREATE:
            hDC = GetDC(hwnd);
            g_HDC = hDC;
            SetupPixelFormat(hDC);

            hRC = wglCreateContext(hDC);
            g_HRC = hRC;
            wglMakeCurrent(hDC, hRC);
            return 0;
            break;

         case WM_CLOSE:
         case WM_DESTROY:
            wglMakeCurrent(hDC, NULL);
            wglDeleteContext(hRC);
            PostQuitMessage(0);
            return 0;
            break;

         case WM_SIZE:
            height = HIWORD(lParam);
            width = LOWORD(lParam);
            if(height == 0) height = 1;

            glViewport(0, 0, width, height);
            glMatrixMode(GL_PROJECTION);
            glLoadIdentity();
            gluPerspective(45.0f, (GLfloat)width/(GLfloat)height, 0.1f, 1000.0f);
            glMatrixMode(GL_MODELVIEW);
            glLoadIdentity();
            return 0;
            break;

         case WM_KEYDOWN:
		      switch(wParam) 
		         {
			         case VK_ESCAPE:
				         PostQuitMessage(0);
				         break;
		         }
            break;

         default:
            break;
      }

   return (DefWindowProc(hwnd, message, wParam, lParam));
}


int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nShowCmd)
{
   MSG msg;
   HWND hwnd;
   WNDCLASSEX windowClass;

   memset(&windowClass, 0, sizeof(WNDCLASSEX));
   windowClass.cbSize = sizeof(WNDCLASSEX);
   windowClass.style = CS_HREDRAW | CS_VREDRAW;
   windowClass.lpfnWndProc = WndProc;
   windowClass.hInstance = hInstance;
   windowClass.hIcon = LoadIcon(NULL, IDI_APPLICATION);
   windowClass.hCursor = LoadCursor(NULL, IDC_ARROW);
   windowClass.lpszClassName = "DemoClass";
   windowClass.hIconSm = LoadIcon(NULL, IDI_APPLICATION);
   if(!RegisterClassEx(&windowClass)) return 0;

   // Create the window.
   hwnd = CreateWindowEx(0, "DemoClass", "High Dynamic Range - PBuffer",
            WS_OVERLAPPEDWINDOW | WS_VISIBLE | WS_SYSMENU | WS_CLIPCHILDREN | WS_CLIPSIBLINGS,
            100, 100, WINDOW_WIDTH, WINDOW_HEIGHT, NULL, NULL, hInstance, NULL);

   if(!hwnd) return 0;
   ShowWindow(hwnd, SW_SHOW);
   UpdateWindow(hwnd);

   if(InitializeGL())
      {
         while(1)
            {
               if(PeekMessage(&msg, NULL, NULL, NULL, PM_REMOVE))
                  {
                     if(msg.message == WM_QUIT) { break; }
                     TranslateMessage(&msg);
                     DispatchMessage(&msg);
                  }
               else RenderScene();
            }
      }

   Shutdown();
   return (int)msg.wParam;
}


bool InitializeGL()
{
   glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
   glEnable(GL_TEXTURE_2D);

   // Initialize extensions for p buffer, and GLSL.
   if(!SetupPBufferARB()) return false;
   if(!SetupGLSL()) return false;

   // Create the buffers and load the shaders.
   if(!InitPBuffers()) return false;
   if(!InitShaders()) return false;

   // Load the HDR image file.
   float *hdrImage = ReadRGBEImage("ugp.hdr", &hdrWidth, &hdrHeight);
   if(!hdrImage) return false;

   // Generate and create floating point HDR texture.
   glGenTextures(1, &hdrID);
   glBindTexture(GL_TEXTURE_RECTANGLE_NV, hdrID);
   glTexParameteri(GL_TEXTURE_RECTANGLE_NV, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
   glTexParameteri(GL_TEXTURE_RECTANGLE_NV, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
   glTexImage2D(GL_TEXTURE_RECTANGLE_NV, 0, GL_RGB, hdrWidth,
                hdrHeight, 0, GL_RGB, GL_FLOAT, hdrImage);

   delete[] hdrImage;
   return true;
}


bool InitPBuffers()
{
   // Attribute list to describe the p buffer.
   int attrList[] =
      {
         WGL_SUPPORT_OPENGL_ARB, true, WGL_DRAW_TO_PBUFFER_ARB, true,
         WGL_RED_BITS_ARB, 32, WGL_GREEN_BITS_ARB, 32,
         WGL_BLUE_BITS_ARB, 32, WGL_ALPHA_BITS_ARB, 32,
         WGL_FLOAT_COMPONENTS_NV, true, WGL_DEPTH_BITS_ARB, 16, 0
      };

   // Initialize floating point p buffer.
   fullSurface.Initialize(WINDOW_WIDTH, WINDOW_HEIGHT, attrList, NULL, NULL);
   
   // Share all list with the main window and p buffer (like textures).
   if(!wglShareLists(g_HRC, fullSurface.m_hRC)) return false;
   fullSurface.MakeCurrent();

   // Set p buffer stuff.
   glViewport(0, 0, fullSurface.m_width, fullSurface.m_height);
   glMatrixMode(GL_PROJECTION);
   glLoadIdentity();
   gluPerspective(45.0f, WINDOW_WIDTH / WINDOW_HEIGHT, 0.1f, 100.0f);
   glMatrixMode(GL_MODELVIEW);
   glLoadIdentity();

   // Set p buffer's OpenGL properties.
   glClearColor(0.0, 0.0, 0.0, 1.0);
   glEnable(GL_TEXTURE_2D);

   // Return to back buffer.
   if(!wglMakeCurrent(g_HDC, g_HRC)) return false;

   // Create p buffer's render texture.
   glGenTextures(1, &fullSurface.m_ID);
   glBindTexture(GL_TEXTURE_RECTANGLE_NV, fullSurface.m_ID);
   glTexImage2D(GL_TEXTURE_RECTANGLE_NV, 0, GL_RGBA_FLOAT32_ATI,
                WINDOW_WIDTH, WINDOW_HEIGHT, 0, GL_RGBA, GL_FLOAT, NULL);
   glTexParameteri(GL_TEXTURE_RECTANGLE_NV, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
   glTexParameteri(GL_TEXTURE_RECTANGLE_NV, GL_TEXTURE_MAG_FILTER, GL_NEAREST);

   return true;
}


bool InitShaders()
{
   // Create tone mapping shader.
   if(!CreateShader("toneVS.glsl", "tonePS.glsl", &toneShader))
      return false;

   // Bind our shader variables.
   glslToneOffset = glGetUniformLocationARB(toneShader, "offset");
   glslToneFullTexture = glGetUniformLocationARB(toneShader, "fullTexture");
   glslToneExposure = glGetUniformLocationARB(toneShader, "exposure");

   return true;
}


void FullScreenPass()
{
   // We want to render the scene to this offscreen surface.
   fullSurface.MakeCurrent();

   // Clear the buffers and reset the model view matrix.
   glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
   glLoadIdentity();

   // Use no shaders.
	glUseProgramObjectARB(NULL);

   // Bind the HDR texture image.
   glEnable(GL_TEXTURE_RECTANGLE_NV);
   glBindTexture(GL_TEXTURE_RECTANGLE_NV, hdrID);

   // Display simple quad object.
   glBegin(GL_QUADS);

      glTexCoord2f(0.0f, 0.0f); glVertex3f(-0.5f, -0.45f, -1.6f);
      glTexCoord2f(hdrWidth, 0.0f); glVertex3f(0.5f, -0.45f, -1.6f);
      glTexCoord2f(hdrWidth, hdrHeight); glVertex3f(0.5f, 0.45f, -1.6f);
      glTexCoord2f(0.0f, hdrHeight); glVertex3f(-0.5f, 0.45f, -1.6f);

   glEnd();

   // Copy scene to the texture.
   glBindTexture(GL_TEXTURE_RECTANGLE_NV, fullSurface.m_ID);
   glCopyTexSubImage2D(GL_TEXTURE_RECTANGLE_NV, 0, 0, 0, 0, 0,
                       fullSurface.m_width, fullSurface.m_height);
}


void TonePass()
{
   // Switch back to normal back buffer.
   if(!wglMakeCurrent(g_HDC, g_HRC)) return;

   // Clear the buffers and reset the model view matrix.
   glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
   glLoadIdentity();

   // Prepare to draw full screen quad.
   glMatrixMode(GL_PROJECTION);
   glPushMatrix();
   glLoadIdentity();
   gluOrtho2D(0, WINDOW_WIDTH, 0, WINDOW_HEIGHT);
   
   glMatrixMode(GL_MODELVIEW);
   glPushMatrix();
   glLoadIdentity();

   // Set shader.
   glUseProgramObjectARB(toneShader);
   glUniform2fARB(glslToneOffset, 1 / WINDOW_WIDTH, 1 / WINDOW_HEIGHT);
   glUniform1iARB(glslToneFullTexture, 0);
   glUniform1fARB(glslToneExposure, exposure);

   // Bind the full screen scene image.
   glEnable(GL_TEXTURE_RECTANGLE_NV);
   glBindTexture(GL_TEXTURE_RECTANGLE_NV, fullSurface.m_ID);

   // Draw out the fullscreen quad.   
   glBegin(GL_QUADS);

      glTexCoord2f(0.0f, 0.0f);
      glVertex2f(0, 0);

      glTexCoord2f(fullSurface.m_width, 0.0f);
      glVertex2f(WINDOW_WIDTH, 0);

      glTexCoord2f(fullSurface.m_width, fullSurface.m_height);
      glVertex2f(WINDOW_WIDTH, WINDOW_HEIGHT);

      glTexCoord2f(0.0f, fullSurface.m_height);
      glVertex2f(0, WINDOW_HEIGHT);

   glEnd();

   // Return out of ortho mode.
   glMatrixMode(GL_PROJECTION);
	glPopMatrix();
	glMatrixMode(GL_MODELVIEW);
	glPopMatrix();
}


void RenderScene()
{
   FullScreenPass();
   TonePass();
   SwapBuffers(g_HDC);

   // Gather user input.
   if(GetKeyState(VK_DOWN) & 0x80) exposure -= 0.05f;
   if(GetKeyState(VK_UP) & 0x80) exposure += 0.05f;
   if(exposure < 0.0f) exposure = 0.01f;
}


void Shutdown()
{
   // Release all resources.
   fullSurface.Shutdown();
   glDeleteObjectARB(toneShader);
}