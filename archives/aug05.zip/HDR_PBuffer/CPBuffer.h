/*
   High Dynamic Range Rendering - Using P Buffers
   Allen Sherrod
   Article for the Game Developers Magazine.
*/


#ifndef _CPBUFFER_H_
#define _CPBUFFER_H_

#include<windows.h>
#include<gl/gl.h>
#include<gl/glu.h>
#include<gl/glext.h>
#include<gl/wglext.h>

// PBuffer functions.
extern PFNWGLGETEXTENSIONSSTRINGARBPROC wglGetExtensionsStringARB;
extern PFNWGLGETPIXELFORMATATTRIBIVARBPROC wglGetPixelFormatAttribivARB;
extern PFNWGLGETPIXELFORMATATTRIBFVARBPROC wglGetPixelFormatAttribfvARB;
extern PFNWGLCHOOSEPIXELFORMATARBPROC wglChoosePixelFormatARB;
extern PFNWGLCREATEPBUFFERARBPROC wglCreatePbufferARB;
extern PFNWGLGETPBUFFERDCARBPROC wglGetPbufferDCARB;
extern PFNWGLRELEASEPBUFFERDCARBPROC wglReleasePbufferDCARB;
extern PFNWGLDESTROYPBUFFERARBPROC wglDestroyPbufferARB;
extern PFNWGLQUERYPBUFFERARBPROC wglQueryPbufferARB;

bool SetupPBufferARB();
bool ExtensionSupported(char *ext);
bool WGLExtensionSupported(char *ext);


class CPBuffer
{
   public:
      CPBuffer::CPBuffer() : m_width(0), m_height(0), m_hDC(0), m_hRC(0), m_handle(0), m_ID(0) { }
      ~CPBuffer() { Shutdown(); }

      bool Initialize(int w, int h, const int *iAttriList, const float *fAttriList, const int *flags);
      bool MakeCurrent();
      void Shutdown();

      int m_width, m_height;
      HPBUFFERARB m_handle;
      HGLRC m_hRC;
      HDC m_hDC;

      // GL Texture ID.
      unsigned int m_ID;
};

#endif