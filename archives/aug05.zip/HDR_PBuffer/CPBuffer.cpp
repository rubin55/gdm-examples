/*
   High Dynamic Range Rendering - Using P Buffers
   Allen Sherrod
   Article for the Game Developers Magazine.
*/


#include"CPBuffer.h"


// PBuffer functions.
PFNWGLGETEXTENSIONSSTRINGARBPROC wglGetExtensionsStringARB = NULL;
PFNWGLGETPIXELFORMATATTRIBIVARBPROC wglGetPixelFormatAttribivARB = NULL;
PFNWGLGETPIXELFORMATATTRIBFVARBPROC wglGetPixelFormatAttribfvARB = NULL;
PFNWGLCHOOSEPIXELFORMATARBPROC wglChoosePixelFormatARB = NULL;
PFNWGLCREATEPBUFFERARBPROC wglCreatePbufferARB = NULL;
PFNWGLGETPBUFFERDCARBPROC wglGetPbufferDCARB = NULL;
PFNWGLRELEASEPBUFFERDCARBPROC wglReleasePbufferDCARB = NULL;
PFNWGLDESTROYPBUFFERARBPROC wglDestroyPbufferARB = NULL;
PFNWGLQUERYPBUFFERARBPROC wglQueryPbufferARB = NULL;


bool CPBuffer::Initialize(int w, int h, const int *iAttriList,
                          const float *fAttriList, const int *flags)
{
   int pixelFormat = 0;
   unsigned int numFormats = 0;
   HDC tempCurrenthDC = 0;

   Shutdown();
   
   // Check and make sure the right extensions are supported.
   if(!WGLExtensionSupported("WGL_ARB_pixel_format") || !WGLExtensionSupported("WGL_ARB_pbuffer"))
      return false;

   // Save the current device context into a temp HDC variable.
   tempCurrenthDC = wglGetCurrentDC();
   if(!tempCurrenthDC) return false;

   // Grab the pixel format.
   if(!wglChoosePixelFormatARB(tempCurrenthDC, iAttriList, fAttriList, 1,
                               &pixelFormat, &numFormats)) return false;
   if(numFormats <= 0) return false;

   // Create the p buffer by calling wglCreatePbufferARB().
   m_handle = wglCreatePbufferARB(tempCurrenthDC, pixelFormat, w, h, flags);
   if(!m_handle) return false;

   // Get device contect.
   m_hDC = wglGetPbufferDCARB(m_handle);
   if(!m_hDC) return false;

   // Create rendering context.
   m_hRC = wglCreateContext(m_hDC);
   if(!m_hRC) return false;

   // Grab the actual width and height of the p buffer.
   wglQueryPbufferARB(m_handle, WGL_PBUFFER_WIDTH_ARB, &m_width);
   wglQueryPbufferARB(m_handle, WGL_PBUFFER_HEIGHT_ARB, &m_height);
   return true;
}


bool CPBuffer::MakeCurrent()
{
   if(!m_hDC || !m_hRC) return false;
   if(!wglMakeCurrent(m_hDC, m_hRC)) return false;
   return true;
}


void CPBuffer::Shutdown()
{
   // Release all resources.
   if(m_hRC) { wglDeleteContext(m_hRC); m_hRC = 0; }
   if(m_hDC) { wglReleasePbufferDCARB(m_handle, m_hDC); m_hDC = 0; }
   if(m_handle) wglDestroyPbufferARB(m_handle);
   m_handle = 0;
   m_width = m_height = 0;
}


bool ExtensionSupported(char *ext)
{
   char *extension = (char*)glGetString(GL_EXTENSIONS);
   if(strstr(extension, ext) == NULL) return false;
   return true;
}


bool WGLExtensionSupported(char *ext)
{
   if(wglGetExtensionsStringARB == NULL)
      wglGetExtensionsStringARB = (PFNWGLGETEXTENSIONSSTRINGARBPROC)wglGetProcAddress("wglGetExtensionsStringARB");

	char *extension = NULL;
	
	if(wglGetExtensionsStringARB) extension = (char*)wglGetExtensionsStringARB(wglGetCurrentDC());
	else return false;

   if(strstr(extension, ext) == NULL) return false;
   return true;
}


bool SetupPBufferARB()
{
	if(!WGLExtensionSupported("WGL_ARB_pbuffer")) return false;
	else
	   {
		   wglCreatePbufferARB = (PFNWGLCREATEPBUFFERARBPROC)wglGetProcAddress("wglCreatePbufferARB");
		   wglGetPbufferDCARB = (PFNWGLGETPBUFFERDCARBPROC)wglGetProcAddress("wglGetPbufferDCARB");
		   wglReleasePbufferDCARB = (PFNWGLRELEASEPBUFFERDCARBPROC)wglGetProcAddress("wglReleasePbufferDCARB");
		   wglDestroyPbufferARB = (PFNWGLDESTROYPBUFFERARBPROC)wglGetProcAddress("wglDestroyPbufferARB");
		   wglQueryPbufferARB = (PFNWGLQUERYPBUFFERARBPROC)wglGetProcAddress("wglQueryPbufferARB");

		   if(!wglCreatePbufferARB || !wglGetPbufferDCARB || !wglReleasePbufferDCARB ||
			   !wglDestroyPbufferARB || !wglQueryPbufferARB ) return false;
	   }


	if(!WGLExtensionSupported("WGL_ARB_pixel_format")) return false;
	else
	   {
		   wglGetPixelFormatAttribivARB = (PFNWGLGETPIXELFORMATATTRIBIVARBPROC)wglGetProcAddress("wglGetPixelFormatAttribivARB");
		   wglGetPixelFormatAttribfvARB = (PFNWGLGETPIXELFORMATATTRIBFVARBPROC)wglGetProcAddress("wglGetPixelFormatAttribfvARB");
		   wglChoosePixelFormatARB = (PFNWGLCHOOSEPIXELFORMATARBPROC)wglGetProcAddress("wglChoosePixelFormatARB");

		   if(!wglGetExtensionsStringARB || !wglCreatePbufferARB || !wglGetPbufferDCARB) return false;
	   }

   return true;
}