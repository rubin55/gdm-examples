/*
   High Dynamic Range Rendering - Using P Buffers
   Allen Sherrod
   Article for the Game Developers Magazine.
*/


#ifndef _GLSL_H_
#define _GLSL_H_

#include<fstream>
#include<windows.h>
#include<gl/gl.h>
#include<gl/glext.h>

using std::ifstream;

// GLSlang functions.
extern PFNGLCREATEPROGRAMOBJECTARBPROC glCreateProgramObjectARB;
extern PFNGLCREATESHADEROBJECTARBPROC glCreateShaderObjectARB;
extern PFNGLLINKPROGRAMARBPROC glLinkProgramARB;
extern PFNGLCOMPILESHADERARBPROC glCompileShaderARB;
extern PFNGLGETINFOLOGARBPROC glGetInfoLogARB;
extern PFNGLDELETEOBJECTARBPROC glDeleteObjectARB;
extern PFNGLUSEPROGRAMOBJECTARBPROC glUseProgramObjectARB;
extern PFNGLSHADERSOURCEARBPROC glShaderSourceARB;
extern PFNGLATTACHOBJECTARBPROC glAttachObjectARB;
extern PFNGLGETOBJECTPARAMETERIVARBPROC glGetObjectParameterivARB;
extern PFNGLGETUNIFORMLOCATIONARBPROC glGetUniformLocationARB;
extern PFNGLUNIFORM2FARBPROC glUniform2fARB;
extern PFNGLUNIFORM1FARBPROC glUniform1fARB;
extern PFNGLUNIFORM1IARBPROC glUniform1iARB;

bool SetupGLSL();
bool CreateShader(char *VShader, char *PShader, GLhandleARB *glContext);
char *loadShader(char *shaderName);

#endif