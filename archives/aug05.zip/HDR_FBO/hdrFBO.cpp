/*
   High Dynamic Range Rendering - Using Frame Buffer Objects
   Allen Sherrod
   Article for the Game Developers Magazine.
*/


#include<windows.h>
#include<gl/gl.h>
#include<gl/glu.h>
#include"glsl.h"
#include"fbo.h"
#include"rgbeLoader.h"

#define WINDOW_WIDTH 640
#define WINDOW_HEIGHT 480

// Function Prototypes
bool InitializeGL();
bool InitFBO();
bool InitShaders();
void RenderScene();
void Shutdown();

HDC g_HDC;

// HDR Texture image.
unsigned int hdrID = 0;
int hdrWidth = 0, hdrHeight = 0;
float exposure = 2.0f;

// Shader data.
GLhandleARB toneShader;
unsigned int glslToneTexture;
unsigned int glslToneExposure;

// FBO data.
unsigned int frameBufferIndex = 0;
unsigned int depthBufferIndex = 0;
unsigned int offScreenID = 0;


void SetupPixelFormat(HDC hDC)
{
   int nPixelFormat;

   static PIXELFORMATDESCRIPTOR pfd = { sizeof(PIXELFORMATDESCRIPTOR), 1,
         PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL | PFD_DOUBLEBUFFER, PFD_TYPE_RGBA,
         16, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 16, 0, 0,
         PFD_MAIN_PLANE, 0, 0, 0, 0 };

   nPixelFormat = ChoosePixelFormat(hDC, &pfd);
   SetPixelFormat(hDC, nPixelFormat, &pfd);
}


LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
   static HGLRC hRC;
   static HDC hDC;
   int width, height;

   switch(message)
      {
         case WM_CREATE:
            hDC = GetDC(hwnd);
            g_HDC = hDC;
            SetupPixelFormat(hDC);

            hRC = wglCreateContext(hDC);
            wglMakeCurrent(hDC, hRC);
            return 0;
            break;

         case WM_CLOSE:
         case WM_DESTROY:
            wglMakeCurrent(hDC, NULL);
            wglDeleteContext(hRC);
            PostQuitMessage(0);
            return 0;
            break;

         case WM_SIZE:
            height = HIWORD(lParam);
            width = LOWORD(lParam);
            if(height == 0) height = 1;

            glViewport(0, 0, width, height);
            glMatrixMode(GL_PROJECTION);
            glLoadIdentity();
            gluPerspective(45.0f, (GLfloat)width/(GLfloat)height, 0.1f, 1000.0f);
            glMatrixMode(GL_MODELVIEW);
            glLoadIdentity();
            return 0;
            break;

         case WM_KEYDOWN:
		      switch(wParam) 
		         {
			         case VK_ESCAPE:
				         PostQuitMessage(0);
				         break;
		         }
            break;

         default:
            break;
      }

   return (DefWindowProc(hwnd, message, wParam, lParam));
}


int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nShowCmd)
{
   MSG msg;
   HWND hwnd;
   WNDCLASSEX windowClass;

   memset(&windowClass, 0, sizeof(WNDCLASSEX));
   windowClass.cbSize = sizeof(WNDCLASSEX);
   windowClass.style = CS_HREDRAW | CS_VREDRAW;
   windowClass.lpfnWndProc = WndProc;
   windowClass.hInstance = hInstance;
   windowClass.hIcon = LoadIcon(NULL, IDI_APPLICATION);
   windowClass.hCursor = LoadCursor(NULL, IDC_ARROW);
   windowClass.lpszClassName = "DemoClass";
   windowClass.hIconSm = LoadIcon(NULL, IDI_APPLICATION);
   if(!RegisterClassEx(&windowClass)) return 0;

   // Create the window.
   hwnd = CreateWindowEx(0, "DemoClass", "High Dynamic Range - FBO",
            WS_OVERLAPPEDWINDOW | WS_VISIBLE | WS_SYSMENU | WS_CLIPCHILDREN | WS_CLIPSIBLINGS,
            100, 100, WINDOW_WIDTH, WINDOW_HEIGHT, NULL, NULL, hInstance, NULL);

   if(!hwnd) return 0;
   ShowWindow(hwnd, SW_SHOW);
   UpdateWindow(hwnd);

   if(InitializeGL())
      {
         while(1)
            {
               if(PeekMessage(&msg, NULL, NULL, NULL, PM_REMOVE))
                  {
                     if(msg.message == WM_QUIT) { break; }
                     TranslateMessage(&msg);
                     DispatchMessage(&msg);
                  }
               else RenderScene();
            }
      }

   Shutdown();
   return (int)msg.wParam;
}


bool InitializeGL()
{
   glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
   glEnable(GL_TEXTURE_2D);

   // Initialize extensions for GLSL and FBO.
   if(!SetupGLSL() || !SetupFBO()) return false;

   // Create and load the shaders and FBO.
   if(!InitShaders() || !InitFBO()) return false;

   // Load the HDR image file.
   float *hdrImage = ReadRGBEImage("ugp.hdr", &hdrWidth, &hdrHeight);
   if(!hdrImage) return false;

   // Generate and create floating point HDR texture.
   glGenTextures(1, &hdrID);
   glBindTexture(GL_TEXTURE_RECTANGLE_NV, hdrID);
   glTexParameteri(GL_TEXTURE_RECTANGLE_NV, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
   glTexParameteri(GL_TEXTURE_RECTANGLE_NV, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
   glTexImage2D(GL_TEXTURE_RECTANGLE_NV, 0, GL_RGB, hdrWidth,
                hdrHeight, 0, GL_RGB, GL_FLOAT, hdrImage);

   delete[] hdrImage;
   return true;
}


bool InitFBO()
{
   // Generate frame buffer object then bind it.
   glGenFramebuffersEXT(1, &frameBufferIndex);
   glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, frameBufferIndex);
   glGenRenderbuffersEXT(1, &depthBufferIndex);

   // Create the texture we will be using to render to.
   glGenTextures(1, &offScreenID);
   glBindTexture(GL_TEXTURE_2D, offScreenID);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
   glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
   glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, WINDOW_WIDTH, WINDOW_HEIGHT, 0,
                GL_RGB, GL_FLOAT, 0);

   // Bind the texture to the frame buffer.
   glFramebufferTexture2DEXT(GL_FRAMEBUFFER_EXT, GL_COLOR_ATTACHMENT0_EXT,
                             GL_TEXTURE_2D, offScreenID, 0);

   // Initialize the render buffer.
   glBindRenderbufferEXT(GL_RENDERBUFFER_EXT, depthBufferIndex);
   glRenderbufferStorageEXT(GL_RENDERBUFFER_EXT, GL_DEPTH_COMPONENT24, WINDOW_WIDTH, WINDOW_HEIGHT);
   glFramebufferRenderbufferEXT(GL_FRAMEBUFFER_EXT, GL_DEPTH_ATTACHMENT_EXT,
                                GL_RENDERBUFFER_EXT, depthBufferIndex);

   // Make sure we have not errors.
   if(glCheckFramebufferStatusEXT(GL_FRAMEBUFFER_EXT) != GL_FRAMEBUFFER_COMPLETE_EXT)
      return false;

   // Return out of the frame buffer.
   glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, 0);

   return true;
}


bool InitShaders()
{
   // Create tone mapping shader.
   if(!CreateShader("toneVS.glsl", "tonePS.glsl", &toneShader))
      return false;

   // Bind our shader variables.
   glslToneTexture = glGetUniformLocationARB(toneShader, "fullTexture");
   glslToneExposure = glGetUniformLocationARB(toneShader, "exposure");

   return true;
}


void OffScreenPass()
{
   // Bind the frame buffer so we can render to it.
   glBindTexture(GL_TEXTURE_2D, 0);
   glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, frameBufferIndex);

      // Clear the buffers and reset the model view matrix.
      glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
      glLoadIdentity();

      // Use no shaders.
	   glUseProgramObjectARB(NULL);

      // Bind the HDR texture image.
      glEnable(GL_TEXTURE_RECTANGLE_NV);
      glBindTexture(GL_TEXTURE_RECTANGLE_NV, hdrID);

      // Display simple quad object.
      glBegin(GL_QUADS);

         glTexCoord2f(0.0f, 0.0f); glVertex3f(-0.5f, -0.45f, -1.6f);
         glTexCoord2f(hdrWidth, 0.0f); glVertex3f(0.5f, -0.45f, -1.6f);
         glTexCoord2f(hdrWidth, hdrHeight); glVertex3f(0.5f, 0.45f, -1.6f);
         glTexCoord2f(0.0f, hdrHeight); glVertex3f(-0.5f, 0.45f, -1.6f);

      glEnd();

   // End rendering to FBO.
   glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, 0);
}


void TonePass()
{
   // Clear the buffers and reset the model view matrix.
   glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
   glLoadIdentity();

   // Prepare to draw full screen quad.
   glMatrixMode(GL_PROJECTION);
   glPushMatrix();
   glLoadIdentity();
   gluOrtho2D(0, WINDOW_WIDTH, 0, WINDOW_HEIGHT);
   
   glMatrixMode(GL_MODELVIEW);
   glPushMatrix();
   glLoadIdentity();

   // Set shader.
   glUseProgramObjectARB(toneShader);
   glUniform1iARB(glslToneTexture, 0);
   glUniform1fARB(glslToneExposure, exposure);

   // Bind the full screen scene image.
   glEnable(GL_TEXTURE_2D);
   glBindTexture(GL_TEXTURE_2D, offScreenID);

   // Draw out the fullscreen quad.   
   glBegin(GL_QUADS);

      glTexCoord2f(0, 0); glVertex2f(0, 0);
      glTexCoord2f(1, 0); glVertex2f(WINDOW_WIDTH, 0);
      glTexCoord2f(1, 1); glVertex2f(WINDOW_WIDTH, WINDOW_HEIGHT);
      glTexCoord2f(0, 1); glVertex2f(0, WINDOW_HEIGHT);

   glEnd();

   // Return out of ortho mode.
   glMatrixMode(GL_PROJECTION);
	glPopMatrix();
	glMatrixMode(GL_MODELVIEW);
	glPopMatrix();
}


void RenderScene()
{
   OffScreenPass();
   TonePass();
   SwapBuffers(g_HDC);

   // Gather user input.
   if(GetKeyState(VK_DOWN) & 0x80) exposure -= 0.05f;
   if(GetKeyState(VK_UP) & 0x80) exposure += 0.05f;
   if(exposure < 0.0f) exposure = 0.01f;
}


void Shutdown()
{
   // Release all resources.
   if(depthBufferIndex) glDeleteRenderbuffersEXT(1, &depthBufferIndex);
   if(frameBufferIndex) glDeleteFramebuffersEXT(1, &frameBufferIndex);
   if(offScreenID) glDeleteTextures(1, &offScreenID);
   glDeleteObjectARB(toneShader);
}