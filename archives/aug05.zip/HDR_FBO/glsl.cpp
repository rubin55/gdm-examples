/*
   High Dynamic Range Rendering - Using P Buffers
   Allen Sherrod
   Article for the Game Developers Magazine.
*/


#include"glsl.h"


// GLSlang functions.
PFNGLCREATEPROGRAMOBJECTARBPROC glCreateProgramObjectARB = NULL;
PFNGLCREATESHADEROBJECTARBPROC glCreateShaderObjectARB = NULL;
PFNGLLINKPROGRAMARBPROC glLinkProgramARB = NULL;
PFNGLCOMPILESHADERARBPROC glCompileShaderARB = NULL;
PFNGLGETINFOLOGARBPROC glGetInfoLogARB = NULL;
PFNGLDELETEOBJECTARBPROC glDeleteObjectARB = NULL;
PFNGLUSEPROGRAMOBJECTARBPROC glUseProgramObjectARB = NULL;
PFNGLSHADERSOURCEARBPROC glShaderSourceARB = NULL;
PFNGLATTACHOBJECTARBPROC glAttachObjectARB = NULL;
PFNGLGETOBJECTPARAMETERIVARBPROC glGetObjectParameterivARB = NULL;
PFNGLGETUNIFORMLOCATIONARBPROC glGetUniformLocationARB = NULL;
PFNGLUNIFORM2FARBPROC glUniform2fARB = NULL;
PFNGLUNIFORM1FARBPROC glUniform1fARB = NULL;
PFNGLUNIFORM1IARBPROC glUniform1iARB = NULL;


bool SetupGLSL()
{
   char *extensions = (char*)glGetString(GL_EXTENSIONS);

   // Check for the neccessary extensions.
   if(strstr(extensions, "GL_ARB_shading_language_100") == NULL) return false;
   if(strstr(extensions, "GL_ARB_shader_objects") == NULL) return false;

   glCreateProgramObjectARB = (PFNGLCREATEPROGRAMOBJECTARBPROC)wglGetProcAddress("glCreateProgramObjectARB");
   glCreateShaderObjectARB = (PFNGLCREATESHADEROBJECTARBPROC)wglGetProcAddress("glCreateShaderObjectARB");
   glCompileShaderARB = (PFNGLCOMPILESHADERARBPROC)wglGetProcAddress("glCompileShaderARB");
   glLinkProgramARB = (PFNGLLINKPROGRAMARBPROC)wglGetProcAddress("glLinkProgramARB");
   glGetInfoLogARB = (PFNGLGETINFOLOGARBPROC)wglGetProcAddress("glGetInfoLogARB");
   glDeleteObjectARB  = (PFNGLDELETEOBJECTARBPROC)wglGetProcAddress("glDeleteObjectARB");
   glUseProgramObjectARB = (PFNGLUSEPROGRAMOBJECTARBPROC)wglGetProcAddress("glUseProgramObjectARB");
   glShaderSourceARB = (PFNGLSHADERSOURCEARBPROC)wglGetProcAddress("glShaderSourceARB");
   glAttachObjectARB = (PFNGLATTACHOBJECTARBPROC)wglGetProcAddress("glAttachObjectARB");
   glGetObjectParameterivARB = (PFNGLGETOBJECTPARAMETERIVARBPROC)wglGetProcAddress("glGetObjectParameterivARB");
   glGetUniformLocationARB = (PFNGLGETUNIFORMLOCATIONARBPROC)wglGetProcAddress("glGetUniformLocationARB");
   glUniform2fARB = (PFNGLUNIFORM2FARBPROC)wglGetProcAddress("glUniform2fARB");
   glUniform1fARB = (PFNGLUNIFORM1FARBPROC)wglGetProcAddress("glUniform1fARB");
   glUniform1iARB = (PFNGLUNIFORM1IARBPROC)wglGetProcAddress("glUniform1iARB");

   if(!glCreateProgramObjectARB || !glCreateShaderObjectARB ||  !glCompileShaderARB ||
      !glLinkProgramARB || !glGetInfoLogARB || !glDeleteObjectARB || !glUseProgramObjectARB ||
      !glShaderSourceARB || !glAttachObjectARB || !glGetObjectParameterivARB ||
      !glGetUniformLocationARB || !glUniform2fARB || !glUniform1iARB || !glUniform1fARB)
      {
         return false;
      }

   return true;
}


bool CreateShader(char *VShader, char *PShader, GLhandleARB *glContext)
{
   char error[4096];
   int result;
   GLhandleARB glVertexShader;
   GLhandleARB glPixelShader;

   // Create the program object.
   *glContext = glCreateProgramObjectARB();

   // Load the vertex shader.
   char *ShaderCode = loadShader(VShader);
   if(!ShaderCode) return false;
   glVertexShader = glCreateShaderObjectARB(GL_VERTEX_SHADER_ARB);
   glShaderSourceARB(glVertexShader, 1, (const char**)&ShaderCode, NULL);
   glCompileShaderARB(glVertexShader);
   glGetObjectParameterivARB(glVertexShader, GL_OBJECT_COMPILE_STATUS_ARB, &result);
   glAttachObjectARB(*glContext, glVertexShader);
   delete[] ShaderCode;
   ShaderCode = NULL;

   // Load the pixel shader.
   ShaderCode = loadShader(PShader);
   if(!ShaderCode) return false;
   glPixelShader = glCreateShaderObjectARB(GL_FRAGMENT_SHADER_ARB);
   glShaderSourceARB(glPixelShader, 1, (const char**)&ShaderCode, NULL);
   glCompileShaderARB(glPixelShader);
   glGetObjectParameterivARB(glPixelShader, GL_OBJECT_COMPILE_STATUS_ARB, &result);
   glAttachObjectARB(*glContext, glPixelShader);
   delete[] ShaderCode;
   ShaderCode = NULL;

   // Link our shaders.
   glLinkProgramARB(*glContext);
   glGetObjectParameterivARB(*glContext, GL_OBJECT_LINK_STATUS_ARB, &result);

   if(!result)
      {
         glGetInfoLogARB(*glContext, sizeof(error), NULL, error);
         MessageBox(NULL, error, "Error linking shaders...", MB_OK);
         return false;
      }

   glDeleteObjectARB(glVertexShader);
   glDeleteObjectARB(glPixelShader);
   return true;
}


char* loadShader(char *shaderName)
{
   char tempLine[256] = {0};
   int count = 0;

   // input object.
   ifstream tempInput;
   tempInput.open(shaderName);
   if(!tempInput.is_open()) return NULL;

   // Loop through each line of the file and get the total size.
   while(!tempInput.eof())
      {
         tempInput.getline(tempLine, 256, '\n');
         count++;
      }

   tempInput.close();
   if(count == 0) return NULL;

   // Read in the data for use this time.
   ifstream input;

   // Create array to hold shader code.
   char *ShaderSource = new char[256 * count];

   // Re-open the shader and read in the whole thing into the array.
   input.open(shaderName);
   input.getline(ShaderSource , 256 * count, '\0');
   input.close();
   return ShaderSource;
}