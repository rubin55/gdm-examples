// ---
// -- Pattern Creator by Cesar Botana
// --   Use: creator.exe image.png pattern.pat
// -- Warning: this is just a sample application. A complete error management isn't implemented.
// ---
#include "cv.h"
#include "highgui.h"

// ...
#define E_PATTERN_SIZE_X ( 32 )
#define E_PATTERN_SIZE_Y ( 32 )

#define Min(a,b)  ( ( a ) < ( b ) ? ( a ) : ( b ) )

// ...
enum EImages
{
   IMG_ORIGINAL = 0,
   IMG_CONTOURS,
   IMG_CONTOURS_POLY,
   IMG_INTERNAL_0,
   IMG_INTERNAL_90,
   IMG_INTERNAL_180,
   IMG_INTERNAL_270,

   NUM_IMAGES
};

// ...
IplImage*     apImages[ NUM_IMAGES ]       = { NULL };
const char*   aWindowsNames[ NUM_IMAGES ]  = { "original", "contours", "contours_poly", "internal0", "internal90", "internal180", "internal270" };
int*          aPosesValues[ 4 ]            = { NULL };
CvMemStorage* pStorage                     = NULL;

// ------------------------------------------------------------------------------------------------------------------------
// --
// --
// ------------------------------------------------------------------------------------------------------------------------
int OnExit( const char* pszMessage, int iCode )
{
   printf( pszMessage );

   // ... clean up ...
   for ( int i = 0; i < NUM_IMAGES; ++i )
      cvReleaseImage( &apImages[ i ] );

   if ( pStorage != NULL )
      cvReleaseMemStorage( &pStorage );

   for ( int i = 0; i < 4; ++i )
   {
      if ( aPosesValues[ i ] != NULL )
         delete[] aPosesValues[ i ];
   }

   cvDestroyAllWindows();

   return -1;
}

// ------------------------------------------------------------------------------------------------------------------------
// --
// --
// ------------------------------------------------------------------------------------------------------------------------
int main( int argc, char* argv[] )
{
   // ... error checking ...
   if ( argc < 3 )
      return OnExit( "Number of params invalid. Use: creator.exe image.png file.pattern\n", -1 );

   // ...
   apImages[ IMG_ORIGINAL ] = cvLoadImage( argv[ 1 ], 0 );

   if ( apImages[ IMG_ORIGINAL ] == NULL )
      return OnExit( "Error to load image file\n", -1 );

   // ...
   CvSize ImageSize = cvGetSize( apImages[ IMG_ORIGINAL ] );

   if ( ImageSize.width != ImageSize.height )
      return OnExit( "Image must be square (width = height)\n", -1 );

   // ... find contours ...
   CvSeq* pContours = NULL;

   pStorage = cvCreateMemStorage();

   apImages[ IMG_CONTOURS ]      = cvCreateImage( cvGetSize( apImages[ IMG_ORIGINAL ] ), 8, 1 );
   apImages[ IMG_CONTOURS_POLY ] = cvCreateImage( cvGetSize( apImages[ IMG_ORIGINAL ] ), 8, 1 );

   cvCopyImage( apImages[ IMG_ORIGINAL ], apImages[ IMG_CONTOURS ] );

   cvFindContours( apImages[ IMG_CONTOURS ], pStorage, &pContours, sizeof( CvContour ), CV_RETR_TREE, CV_CHAIN_APPROX_SIMPLE );
   cvDrawContours( apImages[ IMG_CONTOURS ], pContours, cvScalarAll( 255 ), cvScalarAll( 255 ), 255 );

   pContours = cvApproxPoly( pContours, sizeof( CvContour ), pStorage, CV_POLY_APPROX_DP, 4, 100 );
   cvSetIdentity( apImages[ IMG_CONTOURS_POLY ]);
   cvDrawContours( apImages[ IMG_CONTOURS_POLY ], pContours, cvScalarAll( 255 ), cvScalarAll( 255 ), 255 );

   // ...
   if ( pContours->total != 4 )
      return OnExit( "Image not valid\n", -1 );

   // ... 
   int     aiIdxs[] = { 0, 3, 2, 1 };
   CvPoint aVertexs[ 4 ];

   for ( int i = 0; i < 4; ++i )
   {
      CvPoint* p = ( CvPoint* )cvGetSeqElem( pContours, i );

      aVertexs[ aiIdxs[ i ] ].x = p->x;
      aVertexs[ aiIdxs[ i ] ].y = p->y;
   }

   // ... e must create the four differentes poses ...
   CvSize size = cvSize( aVertexs[ 1 ].x - aVertexs[ 0 ].x + 1, aVertexs[ 2 ].y - aVertexs[ 1 ].y + 1 );

   // ...
   if ( size.width != size.height )
      return OnExit( "Image not valid\n", -1 );

   // ...
   for ( int i = 0; i < 4; ++i )
      apImages[ IMG_INTERNAL_0 + i ] = cvCreateImage( size, 8, 1 );

   cvSetImageROI( apImages[ IMG_ORIGINAL ], cvRect( aVertexs[ 0 ].x, aVertexs[ 0 ].y, size.width, size.height ) );

   // ... original image ...
   cvCopyImage( apImages[ IMG_ORIGINAL ], apImages[ IMG_INTERNAL_0 ] );

   // ... image rotated 90  ...
   for ( int y = 0; y < size.height; ++y )
      for ( int x = 0; x < size.width; ++x )
         cvSet2D( apImages[ IMG_INTERNAL_90 ], size.height - x - 1, y, cvGet2D( apImages[ IMG_INTERNAL_0 ], y, x ) );

   // ... image rotated 180 ...
   for ( int y = 0; y < size.height; ++y )
      for ( int x = 0; x < size.width; ++x )
         cvSet2D( apImages[ IMG_INTERNAL_180 ], size.height - x - 1, y, cvGet2D( apImages[ IMG_INTERNAL_90 ], y, x ) );


   // ... image rotated 270 ...
   for ( int y = 0; y < size.height; ++y )
      for ( int x = 0; x < size.width; ++x )
         cvSet2D( apImages[ IMG_INTERNAL_270 ], x, size.width - y - 1, cvGet2D( apImages[ IMG_INTERNAL_0 ], y, x ) );

   cvSetImageROI( apImages[ IMG_ORIGINAL ], cvRect( 0, 0, ImageSize.width, ImageSize.height ) );

   // ...
   int       rx = 0;
   int       ry = 0;
   int       Values[ 4 ][ E_PATTERN_SIZE_X ][ E_PATTERN_SIZE_Y ] = { 0 };
   CvScalar  Color;

   // ...
   int bx        = ( size.width / E_PATTERN_SIZE_X );
   int by        = ( size.height / E_PATTERN_SIZE_Y );
   int iArrayLen = ( E_PATTERN_SIZE_X * E_PATTERN_SIZE_Y );

   // ... we sum every pixel value in the cell ...
   for ( int i = 0; i < 4; ++i )
   {
      aPosesValues[ i ] = new int[ iArrayLen ];

      memset( aPosesValues[ i ], 0, iArrayLen * sizeof( int ) );
      memset( Values[ i ], 0, sizeof( Values[ i ] ) );

      for ( int y = 0; y < size.height; ++y )
      {
         ry = Min( ( y / by ), E_PATTERN_SIZE_Y - 1 );

         for ( int x = 0; x < size.width; ++x )
         {
            rx    = Min( ( x / bx ), E_PATTERN_SIZE_X - 1 );
            Color = cvGet2D( apImages[ IMG_INTERNAL_0 + i ], y, x );

            aPosesValues[ i ][ rx + ( ry * E_PATTERN_SIZE_X ) ] += ( int )Color.val[ 0 ];
            ++Values[ i ][ rx ][ ry ];
         }
      }
   }

   // ... and compute the average value ...
   for ( int i = 0; i < 4; ++i )
   {
      rx = 0;
      ry = 0;

      cvSetIdentity( apImages[ IMG_INTERNAL_0 + i ] );

      for ( int y = 0; y < E_PATTERN_SIZE_Y; ++y )
      {
         for ( int x = 0; x < E_PATTERN_SIZE_X; ++x )
         {
            if ( Values[ i ][ x ][ y ] != 0 )
            {
               aPosesValues[ i ][ x + ( y * E_PATTERN_SIZE_X ) ] /= Values[ i ][ x ][ y ];
               aPosesValues[ i ][ x + ( y * E_PATTERN_SIZE_X ) ] = ( aPosesValues[ i ][ x + ( y * E_PATTERN_SIZE_X ) ] < 127 ) ? 0 : 255;
            }

            // ...
            cvRectangle( apImages[ IMG_INTERNAL_0 + i ], cvPoint( rx, ry ), cvPoint( rx + bx - 1, ry + by - 1 ), cvScalarAll( aPosesValues[ i ][ x + ( y * E_PATTERN_SIZE_X ) ] ), CV_FILLED );
            rx += bx;
         }

         rx = 0;
         ry += by;
      }
      // ...
      for ( int x = 0; x <= E_PATTERN_SIZE_X; ++x )
         cvLine( apImages[ IMG_INTERNAL_0 + i ], cvPoint( x * bx, 0 ), cvPoint( x * bx, E_PATTERN_SIZE_Y * by ), cvScalarAll( 127 ) );

      for ( int y = 0; y <= E_PATTERN_SIZE_Y; ++y )
         cvLine( apImages[ IMG_INTERNAL_0 + i ], cvPoint( 0, y * by ), cvPoint( E_PATTERN_SIZE_X * bx, y * by ), cvScalarAll( 127 ) );
   }

   // ... show results ...
   int iX = 0;

   for ( int i = 0; i <= IMG_CONTOURS_POLY; ++i )
   {
      cvNamedWindow( aWindowsNames[ i ] );
      cvMoveWindow( aWindowsNames[ i ], iX, 0 );
      cvShowImage( aWindowsNames[ i ], apImages[ i ] );
      iX += 370;
   }

   iX = 0;

   for ( int i = IMG_INTERNAL_0; i < NUM_IMAGES; ++i )
   {
      cvNamedWindow( aWindowsNames[ i ] );
      cvMoveWindow( aWindowsNames[ i ], iX, 400 );
      cvShowImage( aWindowsNames[ i ], apImages[ i ] );
      iX += 280;
   }

   printf( "Press any key to save pattern and exit\n" );
   cvWaitKey();

   // ...
   FILE* f = fopen( argv[ 2 ], "wb" );

   if ( f == NULL )
      return OnExit( "Error to create detination file", -1 );

   int iWidth  = E_PATTERN_SIZE_X;
   int iHeight = E_PATTERN_SIZE_Y;

   fwrite( &iWidth, sizeof( iWidth ), 1, f );
   fwrite( &iHeight, sizeof( iHeight ), 1, f );

   // ... image pos & size info ...
   fwrite( &aVertexs[ 0 ].x, sizeof( aVertexs[ 0 ].x ), 1, f );
   fwrite( &aVertexs[ 0 ].y, sizeof( aVertexs[ 0 ].y ), 1, f );
   fwrite( &size.width, sizeof( size.width ), 1, f );
   fwrite( &size.height, sizeof( size.height ), 1, f );
   fwrite( &ImageSize.width, sizeof( ImageSize.width ), 1, f );
   fwrite( &ImageSize.height, sizeof( ImageSize.height ), 1, f );

   // ... 
   for ( int i = 0; i < 4; ++i )
   {
      for ( int y = 0; y < E_PATTERN_SIZE_Y; ++y )
      {
         for ( int x = 0; x < E_PATTERN_SIZE_X; ++x )
            fwrite( &aPosesValues[ i ][ x + ( y * E_PATTERN_SIZE_X ) ], sizeof( unsigned char ), 1, f );
      }
   }

   fclose( f );

   // ...
   return OnExit( "all ok", 0 );
}