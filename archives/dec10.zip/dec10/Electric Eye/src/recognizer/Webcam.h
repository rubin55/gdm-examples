// ---
// --
// ---
#ifndef _WEBCAM_H
#define _WEBCAM_H

#include "cxtypes.h"

namespace Webcam
{
   bool        Init           ( const CvSize& WndSize );
   void        End            ( );

   void        CaptureFrame   ( );
   void        PresentFrame   ( );

   IplImage*   GetFrame       ( );
}

#endif // _WEBCAM_H