// ---
// --
// ---
#include "cv.h"
#include "highgui.h"
#include "Pattern.h"
#include "GLWindow.h"
#include "World.h"

#include "Recognizer.h"

#define DEBUG_WINDOW_NAME           ( "debug" )
#define MATCH_VALID                 ( 0.85f )
#define NUM_MAX_RECURSIVE_CONTOURS  ( 500 )
#define Min(a,b)                    ( ( a ) < ( b ) ? ( a ) : ( b ) )

// ...
namespace Recognizer
{
   enum EDebugImages
   {
      IMG_BINARIZED = 0,
      IMG_CONTOURS,
      IMG_POLY_CONTOURS,
      IMG_POSSIBLES_CONTOURS,
      IMG_PATTERN_PROJECTED,
      IMG_CELL_PATTERN,

      NUM_DEBUG_IMAGES
   };

   struct TPatternInfo
   {
      CPattern*      pPattern;
      float          afPos2DZ[ 3 ];
      float          afRotation[ 9 ];
      bool           bValidData;

       TPatternInfo( ) : pPattern( NULL ), bValidData( false ) 
       { 
          memset( afRotation, 0, sizeof( afRotation ) );
          memset( afPos2DZ, 0, sizeof( afPos2DZ ) );
       }
      ~TPatternInfo( ) { delete pPattern; }
   };

   // ...
   void                       GenerateDebugImages                    ( CvSeq* pContours, CvSeq* pPolyContours, std::vector< CvSeq* >& adPossiblesContours );
   void                       GenerateDebugCellPatternImage          ( CPattern* pPattern, unsigned char* pCellPattern );
   void                       ManageDebugInput                       ( );
   void                       GetPossiblesContours                   ( CvSeq* pContour, std::vector< CvSeq* >& adPossiblesContours, int iStep );
   bool                       ContourInClockwise                     ( CvSeq* contour );
   void                       BuildPoly                              ( CvSeq* pContour, CvPoint* paPoly );
   int                        MatchPolyToPattern                     ( IplImage* pImage, CvPoint *paInternalPoly, CvPoint *paExternalPoly, CPattern* pPattern );
   void                       BuildHomographyMatrix                  ( CvPoint* paInternalPoly, CvPoint* paExternalPoly, CPattern* pPattern );
   unsigned char*             BuildCellPattern                       ( IplImage* pImage, CPattern* pPattern );
   void                       CalcRotationMatrixAndTranslateVector   ( CvPoint* paInternalPoly, CvPoint* paExternalPoly, int iPose, Recognizer::TPatternInfo* pPatInfo );

   // ...
   std::vector< TPatternInfo* >  s_adPatterns;
   CvMemStorage*                 s_pStorage                                = NULL;
   IplImage*                     s_pImageBinarized                         = NULL;
   IplImage*                     s_pImageAux                               = NULL;
   IplImage*                     s_pPatternProjected                       = NULL;
   IplImage*                     s_pDebugImageActive                       = NULL;
   IplImage*                     s_apDebugImages[ NUM_DEBUG_IMAGES ]       = { NULL };
   char*                         s_aDebugImagesNames[ NUM_DEBUG_IMAGES ]   = { "Binarized", "Contours", "Poly Contours", "Possibles Contours", "Homography", "Cell Pattern" };
   bool                          s_abPressedValid[ GLWindow::NUM_KEYS ]    = { true };
   int                           s_iIdxActiveDebugImage                    = 0;
   CvMat*                        s_MatImagePoints                          = NULL;
   CvMat*                        s_MatObjectPoints                         = NULL;
   CvMat*                        s_MatHomography                           = NULL;
   CvMat*                        s_MatIntrinsic                            = NULL;
   CvMat*                        s_RotationVector                          = NULL;
   CvMat*                        s_TranslationVector                       = NULL;
   CvMat*                        s_MatRot3x3                               = NULL;
   float                         s_fLastPC                                 = 0.f;
   CvFont                        s_DebugFont;
   CvSize                        s_WndSize;
}

// ------------------------------------------------------------------------------------------------------------------------
// --
// --
// ------------------------------------------------------------------------------------------------------------------------
void Recognizer::End()
{
   for ( int i = 0; i < ( int )s_adPatterns.size(); ++i )
      delete ( s_adPatterns[ i ] );

   s_adPatterns.clear();

   // ...
   cvReleaseMemStorage( &s_pStorage );

   cvReleaseImage( &s_pImageBinarized );
   cvReleaseImage( &s_pImageAux );
   cvReleaseImage( &s_pPatternProjected );
   cvReleaseImage( &s_pDebugImageActive );

   // ...
   cvReleaseMat( &s_MatImagePoints );
   cvReleaseMat( &s_MatObjectPoints );
   cvReleaseMat( &s_MatHomography );
   cvReleaseMat( &s_MatIntrinsic );
   cvReleaseMat( &s_RotationVector );
   cvReleaseMat( &s_TranslationVector );
   cvReleaseMat( &s_MatRot3x3 );

   // ..
   for ( int i = 0; i < NUM_DEBUG_IMAGES; ++i )
      cvReleaseImage( &s_apDebugImages[ i ] );

   cvDestroyWindow( DEBUG_WINDOW_NAME );
}

// ------------------------------------------------------------------------------------------------------------------------
// --
// --
// ------------------------------------------------------------------------------------------------------------------------
bool Recognizer::Init( const CvSize& WndSize )
{
   s_pStorage           = cvCreateMemStorage( 0 );
   s_pImageBinarized    = cvCreateImage( WndSize, 8, 1 );
   s_pImageAux          = cvCreateImage( WndSize, 8, 1 );
   s_pPatternProjected  = cvCreateImage( WndSize, 8, 1 );
   s_pDebugImageActive  = cvCreateImage( WndSize, 8, 1 );
   s_MatImagePoints     = cvCreateMat( 2, 8, CV_32FC1 );
   s_MatObjectPoints    = cvCreateMat( 3, 8, CV_32FC1 );
   s_MatHomography      = cvCreateMat( 3, 3, CV_32FC1 );
   s_RotationVector     = cvCreateMat( 3, 1, CV_32FC1 );
   s_TranslationVector  = cvCreateMat( 3, 1, CV_32FC1 );
   s_MatRot3x3          = cvCreateMat( 3, 3, CV_32FC1 );
   s_MatIntrinsic       = ( CvMat* )cvLoad( "intrinsics.xml" );

   // ...
   cvNamedWindow( DEBUG_WINDOW_NAME );
   cvMoveWindow( DEBUG_WINDOW_NAME, WndSize.width + 30, 0 );

   cvInitFont( &s_DebugFont, CV_FONT_HERSHEY_COMPLEX_SMALL, 1.0, 1.0 );

   s_WndSize = WndSize;

   // ...
   for ( int i = 0; i < NUM_DEBUG_IMAGES; ++i )
      s_apDebugImages[ i ] = cvCreateImage( WndSize, 8, 1 );

   // ...
   return true;
}

// ------------------------------------------------------------------------------------------------------------------------
// --
// --
// ------------------------------------------------------------------------------------------------------------------------
void Recognizer::BuildPoly( CvSeq* pContour, CvPoint* paPoly )
{
  // ... we copy contour points to poly ...
  for ( int i = 0; i < 4; ++i )
  {
    CvPoint* p = ( CvPoint* )cvGetSeqElem( pContour, i );

    paPoly[ i ].x = p->x;
    paPoly[ i ].y = p->y;
  }

  // we arrange the poly's points so the first one is always the one on the top-left corner and CW they.
  // we look for the initial vertex. To do that we take the two vertex with lower Y values (if there are more that 2, 
  // we take the lower X values). Then, between them we select the one with the lower X.
  int iIdxMinY[ 4 ] = { 0, 1, 2, 3 };

  for ( int i = 0; i < 3; ++i )
  {
    for ( int j = i + 1; j < 4; ++j )
    {
      if ( paPoly[ iIdxMinY[ i ] ].y > paPoly[ iIdxMinY[ j ] ].y )
      {
        int aux = iIdxMinY[ i ];
        iIdxMinY[ i ] = iIdxMinY[ j ];
        iIdxMinY[ j ] = aux;
      }
    }
  }

  // ... 
  if ( paPoly[ iIdxMinY[ 1 ] ].y == paPoly[ iIdxMinY[ 2 ] ].y )
  {
    if ( paPoly[ iIdxMinY[ 2 ] ].x < paPoly[ iIdxMinY[ 1 ] ].x )
      iIdxMinY[ 1 ] = iIdxMinY[ 2 ];
  }

  // ... 
  int iIdx0 = ( ( paPoly[ iIdxMinY[ 0 ] ].x < paPoly[ iIdxMinY[ 1 ] ].x ) ? iIdxMinY[ 0 ] : iIdxMinY[ 1 ] );

  // ... 
  int     fi = 0;
  CvPoint aTempPoly[ 4 ];

  memcpy( aTempPoly, paPoly, sizeof( CvSize ) * 4 );

  for ( int i = iIdx0; i < 4; ++i )
  {
    paPoly[ fi ].x = aTempPoly[ i ].x;
    paPoly[ fi ].y = aTempPoly[ i ].y;
    ++fi;
  }

  for ( int i = 0; i < iIdx0; ++i )
  {
    paPoly[ fi ].x = aTempPoly[ i ].x;
    paPoly[ fi ].y = aTempPoly[ i ].y;
    ++fi;
  }

  // ... 
  if ( !ContourInClockwise( pContour ) )
  {
    memcpy( aTempPoly, paPoly, sizeof( CvSize ) * 4 );

    for ( int i = 1; i < 4; ++i )
    {
      paPoly[ i ].x = aTempPoly[ 4 - i ].x;
      paPoly[ i ].y = aTempPoly[ 4 - i ].y;
    }
  }
}

// ------------------------------------------------------------------------------------------------------------------------
// --
// --
// ------------------------------------------------------------------------------------------------------------------------
unsigned char* Recognizer::BuildCellPattern( IplImage* pImage, CPattern* pPattern )
{
   CvSize         CellSize       = pPattern->GetCellSize();
   int            iArrayLen      = ( CellSize.width * CellSize.height );
   CvPoint        InternalPos    = pPattern->GetInternalPos();
   CvSize         InternalSize   = pPattern->GetInternalSize();
   unsigned char* paPattern      = new unsigned char[ iArrayLen ];
   int*           paValues       = new int[ iArrayLen ];
   int*           paCounter      = new int[ iArrayLen ];
   int            rx             = 0;
   int            ry             = 0;
   int            iIdx           = 0;
   CvScalar       Color;

   // ...
   int bx = ( InternalSize.width / CellSize.width );
   int by = ( InternalSize.height / CellSize.height );

   // ... we sum every pixel value in the cell ...
   memset( paPattern, 0, iArrayLen * sizeof( unsigned char ) );
   memset( paValues, 0, iArrayLen * sizeof( int ) );
   memset( paCounter, 0, iArrayLen * sizeof( int ) );

   for ( int y = 0; y < InternalSize.height; ++y )
   {
      ry = Min( ( y / by ), CellSize.height - 1 );

      for ( int x = 0; x < InternalSize.width; ++x )
      {
         rx    = Min( ( x / bx ), CellSize.width - 1 );
         Color = cvGet2D( pImage, y + InternalPos.y, x + InternalPos.x );

         iIdx = ( rx + ( ry * CellSize.width ) );

         paValues[ iIdx ] += ( int )Color.val[ 0 ];
         ++paCounter[ iIdx ];
      }
   }

   // ... and compute the average value ...
   float fMed = 0.f;

   rx = 0;
   ry = 0;

   for ( int y = 0; y < CellSize.height; ++y )
   {
      for ( int x = 0; x < CellSize.width; ++x )
      {
         iIdx = ( x + ( y * CellSize.width ) );

         if ( paCounter[ iIdx ] != 0 )
         {
            fMed = ( ( float )paValues[ iIdx ] / ( float )paCounter[ iIdx ] );
            paPattern[ iIdx ] = ( fMed < 127.f ) ? 0 : 255;
         }

         // ...
         rx += bx;
      }

      rx = 0;
      ry += by;
   }

   //!!debug help
   cvRectangle( pImage, InternalPos, cvPoint( InternalPos.x + InternalSize.width - 1, InternalPos.y + InternalSize.height - 1 ), cvScalarAll( 127 ) );
   //!!/debug help

   // ...
   delete[] paValues;
   delete[] paCounter;

   return paPattern;
}

// ------------------------------------------------------------------------------------------------------------------------
// --
// --
// ------------------------------------------------------------------------------------------------------------------------
int Recognizer::MatchPolyToPattern( IplImage* pImage, CvPoint *paInternalPoly, CvPoint *paExternalPoly, CPattern* pPattern )
{
   BuildHomographyMatrix( paInternalPoly, paExternalPoly, pPattern );
   cvWarpPerspective( pImage, s_pPatternProjected, s_MatHomography, CV_INTER_NN );

   // ... 
   unsigned char*       CellPattern = BuildCellPattern( s_pPatternProjected, pPattern );
   int                  iMatch      = 0;
   int                  iLen        = ( pPattern->GetCellSize().width * pPattern->GetCellSize().height );
   float                fPC         = 0.f;
   const unsigned char* pTestPose   = NULL;
   int                  iPose       = -1;
   int                  iBlackLen   = 0;

   // ... 
   for ( int i = 0; i < 4; ++i )
   {
      pTestPose =  pPattern->GetPose( i );
      iMatch    = 0;
      iBlackLen = 0;

      for ( int j = 0; j < iLen; ++j )
      {
         if ( CellPattern[ j ] == 0 ) // ... only compares to black values ...
         {
            if ( pTestPose[ j ] == CellPattern[ j ] )
               ++iMatch;
            
            ++iBlackLen;
         }
      }

      fPC = ( ( float )iMatch / ( float )iBlackLen );

      if ( ( fPC > MATCH_VALID ) && ( fPC > s_fLastPC ) )
      {
         iPose     = i;
         s_fLastPC = fPC;
      }
   }

   // ...
   GenerateDebugCellPatternImage( pPattern, CellPattern );

   delete[] CellPattern;

   // ...
   return iPose;
}

// ------------------------------------------------------------------------------------------------------------------------
// --
// --
// ------------------------------------------------------------------------------------------------------------------------
void Recognizer::BuildHomographyMatrix( CvPoint* paInternalPoly, CvPoint* paExternalPoly, CPattern* pPattern )
{
   CvPoint InternalPos  = pPattern->GetInternalPos();
   CvSize  InternalSize = pPattern->GetInternalSize();
   CvSize  ExternalSize = pPattern->GetExternalSize();

   // ...
   for ( int i = 0; i < 4; ++i )
   {
      *( ( float* )CV_MAT_ELEM_PTR( *s_MatImagePoints, 0, i ) ) = ( float )paExternalPoly[ i ].x;
      *( ( float* )CV_MAT_ELEM_PTR( *s_MatImagePoints, 1, i ) ) = ( float )paExternalPoly[ i ].y;
      *( ( float* )CV_MAT_ELEM_PTR( *s_MatImagePoints, 0, i + 4 ) ) = ( float )paInternalPoly[ i ].x;
      *( ( float* )CV_MAT_ELEM_PTR( *s_MatImagePoints, 1, i + 4 ) ) = ( float )paInternalPoly[ i ].y;
   }

   // ...
   *( ( float* )CV_MAT_ELEM_PTR( *s_MatObjectPoints, 0, 0 ) ) = 0.f;
   *( ( float* )CV_MAT_ELEM_PTR( *s_MatObjectPoints, 1, 0 ) ) = 0.f;
   *( ( float* )CV_MAT_ELEM_PTR( *s_MatObjectPoints, 2, 0 ) ) = 0.f;

   *( ( float* )CV_MAT_ELEM_PTR( *s_MatObjectPoints, 0, 1 ) ) = ( float )ExternalSize.width - 1.f;
   *( ( float* )CV_MAT_ELEM_PTR( *s_MatObjectPoints, 1, 1 ) ) = 0.f;
   *( ( float* )CV_MAT_ELEM_PTR( *s_MatObjectPoints, 2, 1 ) ) = 0.f;

   *( ( float* )CV_MAT_ELEM_PTR( *s_MatObjectPoints, 0, 2 ) ) = ( float )ExternalSize.width - 1.f;
   *( ( float* )CV_MAT_ELEM_PTR( *s_MatObjectPoints, 1, 2 ) ) = ( float )ExternalSize.height - 1.f;
   *( ( float* )CV_MAT_ELEM_PTR( *s_MatObjectPoints, 2, 2 ) ) = 0.f;

   *( ( float* )CV_MAT_ELEM_PTR( *s_MatObjectPoints, 0, 3 ) ) = 0.f;
   *( ( float* )CV_MAT_ELEM_PTR( *s_MatObjectPoints, 1, 3 ) ) = ( float )ExternalSize.height - 1.f;
   *( ( float* )CV_MAT_ELEM_PTR( *s_MatObjectPoints, 2, 3 ) ) = 0.f;

   // ...
   *( ( float* )CV_MAT_ELEM_PTR( *s_MatObjectPoints, 0, 4 ) ) = ( float )InternalPos.x;
   *( ( float* )CV_MAT_ELEM_PTR( *s_MatObjectPoints, 1, 4 ) ) = ( float )InternalPos.y;
   *( ( float* )CV_MAT_ELEM_PTR( *s_MatObjectPoints, 2, 4 ) ) = 0.f;

   *( ( float* )CV_MAT_ELEM_PTR( *s_MatObjectPoints, 0, 5 ) ) = ( float )( InternalPos.x + InternalSize.width - 1 );
   *( ( float* )CV_MAT_ELEM_PTR( *s_MatObjectPoints, 1, 5 ) ) = ( float )InternalPos.y;
   *( ( float* )CV_MAT_ELEM_PTR( *s_MatObjectPoints, 2, 5 ) ) = 0.f;

   *( ( float* )CV_MAT_ELEM_PTR( *s_MatObjectPoints, 0, 6 ) ) = ( float )( InternalPos.x + InternalSize.width - 1 );
   *( ( float* )CV_MAT_ELEM_PTR( *s_MatObjectPoints, 1, 6 ) ) = ( float )( InternalPos.y + InternalSize.height - 1 );
   *( ( float* )CV_MAT_ELEM_PTR( *s_MatObjectPoints, 2, 6 ) ) = 0.f;

   *( ( float* )CV_MAT_ELEM_PTR( *s_MatObjectPoints, 0, 7 ) ) = ( float )InternalPos.x;
   *( ( float* )CV_MAT_ELEM_PTR( *s_MatObjectPoints, 1, 7 ) ) = ( float )( InternalPos.y + InternalSize.height - 1 );
   *( ( float* )CV_MAT_ELEM_PTR( *s_MatObjectPoints, 2, 7 ) ) = 0.f;

   cvFindHomography( s_MatImagePoints, s_MatObjectPoints, s_MatHomography );
}

// ------------------------------------------------------------------------------------------------------------------------
// --
// --
// ------------------------------------------------------------------------------------------------------------------------
void Recognizer::AnalyzeImage( IplImage* pImage )
{
   for ( int i = 0; i < NUM_DEBUG_IMAGES; ++i )
      cvZero( s_apDebugImages[ i ] );

   cvZero( s_pPatternProjected );

   s_fLastPC = 0.f;

   // ...
   if ( ( s_adPatterns.size() > 0 ) && ( pImage != NULL ) )
   {
      for ( int i = 0; i < ( int )s_adPatterns.size(); ++i )
         s_adPatterns[ i ]->bValidData = false;

      // ...
      CvSeq*                pContours      = NULL;
      CvSeq*                pPolyContours  = NULL;
      std::vector< CvSeq* > adPossiblesContours;

      cvClearMemStorage( s_pStorage );

      // ... 
      cvCvtColor( pImage, s_pImageBinarized, CV_BGR2GRAY );
      cvThreshold( s_pImageBinarized, s_pImageBinarized, 127, 255, CV_THRESH_BINARY );

      // ...
      cvCopy( s_pImageBinarized, s_pImageAux ); // ... just to debug purpose ...
      cvFindContours( s_pImageAux, s_pStorage, &pContours, sizeof( CvContour ), CV_RETR_TREE, CV_CHAIN_APPROX_SIMPLE );

      if ( pContours != NULL )
      {
         // ... 
         pPolyContours = cvApproxPoly( pContours, sizeof( CvContour ), s_pStorage, CV_POLY_APPROX_DP, 16, 100 );

         if ( pPolyContours != NULL )
         {
            GetPossiblesContours( pPolyContours, adPossiblesContours, 0 );

            // ... 
            CvPoint aInternalPoly[ 4 ];
            CvPoint aExternalPoly[ 4 ];
            int     iNumContours = ( int )adPossiblesContours.size();

            for ( int i = 0; i < iNumContours ; ++i )
            {
               BuildPoly( adPossiblesContours[ i ], aExternalPoly );
               BuildPoly( adPossiblesContours[ i ]->v_next, aInternalPoly );

               // ... 
               int iPose = -1;

               for ( int p = 0; p < ( int )s_adPatterns.size(); ++p )
               {
                  iPose = MatchPolyToPattern( s_pImageBinarized, aInternalPoly, aExternalPoly, s_adPatterns[ p ]->pPattern );

                  if ( iPose != -1 )
                  {
                     s_adPatterns[ p ]->bValidData = true;

                     // ... 2D position is the center of poly ...
                     float fX = 0.f;
                     float fY = 0.f;

                     for ( int c = 0; c < 4; ++c )
                     { 
                        fX += aInternalPoly[ c ].x;
                        fY += aInternalPoly[ c ].y;
                     }

                     fX /= 4.f;
                     fY /= 4.f;

                     s_adPatterns[ p ]->afPos2DZ[ 0 ] = fX;
                     s_adPatterns[ p ]->afPos2DZ[ 1 ] = fY;

                     // ... 3D position and rotacion ...
                     CalcRotationMatrixAndTranslateVector( aInternalPoly, aExternalPoly, iPose, s_adPatterns[ p ] );
                     break;
                  }
               }
            }
         }
      }

      // ... debug ...
      GenerateDebugImages( pContours, pPolyContours, adPossiblesContours );
      ManageDebugInput();
   }
}

// ------------------------------------------------------------------------------------------------------------------------
// --
// --
// ------------------------------------------------------------------------------------------------------------------------
void Recognizer::CalcRotationMatrixAndTranslateVector( CvPoint* paInternalPoly, CvPoint* paExternalPoly, int iPose, Recognizer::TPatternInfo* pPatInfo )
{
   int iIdx = ( 4 - iPose );

   for ( int i = 0; i < 4; ++i )
   {
      if ( iIdx > 3 )
         iIdx = 0;

      *( ( float* )CV_MAT_ELEM_PTR( *s_MatImagePoints, 0, i ) ) = ( float )paExternalPoly[ iIdx ].x;
      *( ( float* )CV_MAT_ELEM_PTR( *s_MatImagePoints, 1, i ) ) = ( float )paExternalPoly[ iIdx ].y;
      *( ( float* )CV_MAT_ELEM_PTR( *s_MatImagePoints, 0, i + 4 ) ) = ( float )paInternalPoly[ iIdx ].x;
      *( ( float* )CV_MAT_ELEM_PTR( *s_MatImagePoints, 1, i + 4 ) ) = ( float )paInternalPoly[ iIdx ].y;

      ++iIdx;
   }

   // ... s_MatObjectPoints values were set when we calculated homography matrix ...

   // ...
   cvFindExtrinsicCameraParams2( s_MatObjectPoints, s_MatImagePoints, s_MatIntrinsic, NULL, s_RotationVector, s_TranslationVector );

   *( ( float* )CV_MAT_ELEM_PTR( *s_RotationVector, 0, 0 ) ) = -CV_MAT_ELEM( *s_RotationVector, float, 0, 0 ); // ... X rotation is inverted ...

   cvRodrigues2( s_RotationVector, s_MatRot3x3 );

   // ... matrix transpose to use in OpenGL ...
   for ( int f = 0; f < 3; f++ )
      for ( int c = 0; c < 3; c++ )
         pPatInfo->afRotation[ ( c * 3 ) + f ] = CV_MAT_ELEM( *s_MatRot3x3, float, c, f );

   // ... Z position ...
   pPatInfo->afPos2DZ[ 2 ] = ( CV_MAT_ELEM( *s_TranslationVector, float, 2, 0 ) / pPatInfo->pPattern->GetInternalSize().width );
}

// ------------------------------------------------------------------------------------------------------------------------
// --
// --
// ------------------------------------------------------------------------------------------------------------------------
void Recognizer::GetPossiblesContours( CvSeq* pContour, std::vector< CvSeq* >& adPossiblesContours, int iStep )
{
   // ... to avoid stack overflow ...
   if ( ( pContour != NULL ) && ( iStep < NUM_MAX_RECURSIVE_CONTOURS ) )
   {
      // ... contorn is valid when:

      // ... 1� has 4 sides and a son with 4 sides ...
      bool bIs = ( ( pContour->total == 4 ) && ( pContour->v_next != NULL ) && ( pContour->v_next->total == 4 ) );

      // ... 2� is in clockwis and it son is in counterclockwise ...
      bIs = bIs && ContourInClockwise( pContour ) && !ContourInClockwise( pContour->v_next );

      if ( bIs )
         adPossiblesContours.push_back( pContour );

      // ...
      GetPossiblesContours( pContour->v_next, adPossiblesContours, iStep + 1 );
      GetPossiblesContours( pContour->h_next, adPossiblesContours, iStep + 1 );
   }
}

// ------------------------------------------------------------------------------------------------------------------------
// --
// --
// ------------------------------------------------------------------------------------------------------------------------
bool Recognizer::ContourInClockwise( CvSeq* pContour )
{
   CvPoint aPoints[ 3 ];

   for ( int i = 0; i < 3; ++i )
   {
      CvPoint* p = ( CvPoint* )cvGetSeqElem( pContour, i );
      aPoints[ i ].x = p->x;
      aPoints[ i ].y = p->y;
   }

   int det = ( ( ( ( aPoints[ 1 ].x * aPoints[ 2 ].y ) + ( aPoints[ 0 ].x * aPoints[ 1 ].y ) + ( aPoints[ 0 ].y * aPoints[ 2 ].x ) ) - 
                 ( ( aPoints[ 0 ].y * aPoints[ 1 ].x ) + ( aPoints[ 1 ].y * aPoints[ 2 ].x ) + ( aPoints[ 0 ].x * aPoints[ 2 ].y ) ) ) );

   return ( det > 0 );
}

// ------------------------------------------------------------------------------------------------------------------------
// --
// --
// ------------------------------------------------------------------------------------------------------------------------
void Recognizer::ManageDebugInput()
{
   if ( GLWindow::IsKeyPressed( GLWindow::KEY_F1 ) )
   {
      if ( s_abPressedValid[ GLWindow::KEY_F1 ] )
      {
         ++s_iIdxActiveDebugImage;

         if ( s_iIdxActiveDebugImage >= NUM_DEBUG_IMAGES )
            s_iIdxActiveDebugImage = 0;

         s_abPressedValid[ GLWindow::KEY_F1 ] = false;
      }
   }
   else
      s_abPressedValid[ GLWindow::KEY_F1 ] = true;
}

// ------------------------------------------------------------------------------------------------------------------------
// --
// --
// ------------------------------------------------------------------------------------------------------------------------
void Recognizer::GenerateDebugCellPatternImage( CPattern* pPattern, unsigned char* pCellPattern )
{
   CvSize CellSize  = pPattern->GetCellSize();
   int    bx        = ( pPattern->GetInternalSize().width / CellSize.width );
   int    by        = ( pPattern->GetInternalSize().height / CellSize.height );
   int    rx        = 0;
   int    ry        = 0;

   // ...
   for ( int y = 0; y < CellSize.height; ++y )
   {
      for ( int x = 0; x < CellSize.width; ++x )
      {
         cvRectangle( s_apDebugImages[ IMG_CELL_PATTERN ], cvPoint( rx, ry ), cvPoint( rx + bx - 1, ry + by - 1 ), cvScalarAll( pCellPattern[ x + ( y * CellSize.width ) ] ), CV_FILLED );
         rx += bx;
      }

      rx = 0;
      ry += by;
   }

   for ( int x = 0; x <= CellSize.width; ++x )
      cvLine( s_apDebugImages[ IMG_CELL_PATTERN ], cvPoint( x * bx, 0 ), cvPoint( x * bx, CellSize.height * by ), cvScalarAll( 127 ) );

   for ( int y = 0; y <= CellSize.height; ++y )
      cvLine( s_apDebugImages[ IMG_CELL_PATTERN ], cvPoint( 0, y * by ), cvPoint( CellSize.width * bx, y * by ), cvScalarAll( 127 ) );
}

// ------------------------------------------------------------------------------------------------------------------------
// --
// --
// ------------------------------------------------------------------------------------------------------------------------
void Recognizer::GenerateDebugImages( CvSeq* pContours, CvSeq* pPolyContours, std::vector< CvSeq* >& adPossiblesContours )
{
   cvCopy( s_pImageBinarized, s_apDebugImages[ IMG_BINARIZED ] );

   // ...
   if ( pContours != NULL )
      cvDrawContours( s_apDebugImages[ IMG_CONTOURS ], pContours, cvScalarAll( 255 ), cvScalarAll( 255 ), 100 );

   // ...
   if ( pPolyContours != NULL )
      cvDrawContours( s_apDebugImages[ IMG_POLY_CONTOURS ], pPolyContours, cvScalarAll( 255 ), cvScalarAll( 255 ), 100 );

   // ...
   for ( int i = 0; i < ( int )adPossiblesContours.size(); ++i )
      cvDrawContours( s_apDebugImages[ IMG_POSSIBLES_CONTOURS ], adPossiblesContours[ i ], cvScalarAll( 255 ), cvScalarAll( 255 ), 1 );

   // ...
   cvCopy( s_pPatternProjected, s_apDebugImages[ IMG_PATTERN_PROJECTED ] );
}

// ------------------------------------------------------------------------------------------------------------------------
// --
// --
// ------------------------------------------------------------------------------------------------------------------------
void Recognizer::DrawDebug()
{
   cvCopy( s_apDebugImages[ s_iIdxActiveDebugImage ], s_pDebugImageActive );

   cvRectangle( s_pDebugImageActive, cvPoint( 0, 0 ), cvPoint( s_WndSize.width - 1, 30 ), cvScalarAll( 255 ), CV_FILLED );
   cvRectangle( s_pDebugImageActive, cvPoint( 0, 0 ), cvPoint( s_WndSize.width - 1, 30 ), cvScalarAll( 0 ) );
   cvPutText( s_pDebugImageActive, s_aDebugImagesNames[ s_iIdxActiveDebugImage ], cvPoint( 10, 20 ), &s_DebugFont, cvScalarAll( 0 ) );

   cvRectangle( s_pDebugImageActive, cvPoint( 0, s_WndSize.height - 30 ), cvPoint( s_WndSize.width - 1, s_WndSize.height - 1 ), cvScalarAll( 255 ), CV_FILLED );
   cvRectangle( s_pDebugImageActive, cvPoint( 0, s_WndSize.height - 30 ), cvPoint( s_WndSize.width - 1, s_WndSize.height - 1 ), cvScalarAll( 0 ) );

   char szAux[ 256 ] = "";
   sprintf( szAux, "Cicle pressing F1 on recognizer window (%d%%)", ( int )( s_fLastPC * 100.f ) );

   cvPutText( s_pDebugImageActive, szAux, cvPoint( 10, s_WndSize.height - 10 ), &s_DebugFont, cvScalarAll( 0 ) );

   cvShowImage( DEBUG_WINDOW_NAME, s_pDebugImageActive );
}

// ------------------------------------------------------------------------------------------------------------------------
// --
// --
// ------------------------------------------------------------------------------------------------------------------------
int Recognizer::AddPattern( const char* pszFile )
{
   TPatternInfo* pPatInfo = new TPatternInfo;
   int           iIdx     = -1;

   pPatInfo->pPattern = new CPattern;

   if ( pPatInfo->pPattern->Init( pszFile ) )
   {
      iIdx = ( int )s_adPatterns.size();
      s_adPatterns.push_back( pPatInfo );
   }
   else
      delete pPatInfo->pPattern;

   return iIdx;
}

// ------------------------------------------------------------------------------------------------------------------------
// --
// --
// ------------------------------------------------------------------------------------------------------------------------
int Recognizer::GetNumPatterns()
{
   return ( int )s_adPatterns.size();
}

// ------------------------------------------------------------------------------------------------------------------------
// --
// --
// ------------------------------------------------------------------------------------------------------------------------
bool Recognizer::PatternIsDetected( int iIdxPat )
{
   return s_adPatterns[ iIdxPat ]->bValidData;
}

// ------------------------------------------------------------------------------------------------------------------------
// --
// --
// ------------------------------------------------------------------------------------------------------------------------
float* Recognizer::GetRotationMatrix( int iIdxPat )
{
   return s_adPatterns[ iIdxPat ]->afRotation;
}

// ------------------------------------------------------------------------------------------------------------------------
// --
// --
// ------------------------------------------------------------------------------------------------------------------------
float* Recognizer::Get2DPositionZ( int iIdxPat )
{
   return s_adPatterns[ iIdxPat ]->afPos2DZ;
}