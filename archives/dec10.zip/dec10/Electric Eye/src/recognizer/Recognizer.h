// ---
// --
// ---
#ifndef _RECOGNIZER_H
#define _RECOGNIZER_H

#include <vector>
#include "cxtypes.h"

class CPattern;

namespace Recognizer
{
   bool        Init                 ( const CvSize& WndSize );
   void        End                  ( );

   void        AnalyzeImage         ( IplImage* pImage );
   void        DrawDebug            ( );

   int         AddPattern           ( const char* pszFile );
   int         GetNumPatterns       ( );

   bool        PatternIsDetected    ( int iIdxPat );
   float*      GetRotationMatrix    ( int iIdxPat );
   float*      Get2DPositionZ       ( int iIdxPat );
};

#endif // _RECOGNIZER_H