// ---
// --
// ---
#ifndef _PATTERN_H
#define _PATTERN_H

#include "cxtypes.h"

class CPattern
{
public:

                        CPattern          ( );
                       ~CPattern          ( );

   // ...
   bool                 Init              ( const char* pszFile );

   CvPoint              GetInternalPos    ( ) const { return m_InternalPos; }
   CvSize               GetInternalSize   ( ) const { return m_InternalSize; }
   CvSize               GetExternalSize   ( ) const { return m_ExternalSize; }
   CvSize               GetCellSize       ( ) const { return m_CellSize; }

   const unsigned char* GetPose           ( int iIdx ) const { return m_aPattern[ iIdx ]; }
   
private:

   unsigned char* m_aPattern[ 4 ];
   CvSize         m_CellSize;
   CvPoint        m_InternalPos;
   CvSize         m_InternalSize;
   CvSize         m_ExternalSize;
};

#endif // _PATTERN_H