// ---
// --
// ---
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "Pattern.h"

// ------------------------------------------------------------------------------------------------------------------------
// --
// --
// ------------------------------------------------------------------------------------------------------------------------
CPattern::CPattern()
{
   m_CellSize      = cvSize( 0, 0 );
   m_InternalPos   = cvPoint( 0, 0 );
   m_InternalSize  = cvSize( 0, 0 );
   m_ExternalSize  = cvSize( 0, 0 );

   memset( m_aPattern, 0, sizeof( m_aPattern ) );
}

// ------------------------------------------------------------------------------------------------------------------------
// --
// --
// ------------------------------------------------------------------------------------------------------------------------
CPattern::~CPattern()
{
   for ( int i = 0; i < 4; ++i )
   {
      if ( m_aPattern[ i ] != NULL )
         delete[] m_aPattern[ i ];
   }
}

// ------------------------------------------------------------------------------------------------------------------------
// --
// --
// ------------------------------------------------------------------------------------------------------------------------
bool CPattern::Init( const char* pszFile )
{
   bool  bOk = false;
   FILE* f   = fopen( pszFile, "rb" );
   int   x   = 0;

   // ...
   if ( f != NULL )
   {
      fread( &m_CellSize.width, sizeof( m_CellSize.width ), 1, f );
      fread( &m_CellSize.height, sizeof( m_CellSize.height ), 1, f );

      fread( &m_InternalPos.x, sizeof( m_InternalPos.x ), 1, f );
      fread( &m_InternalPos.y, sizeof( m_InternalPos.y ), 1, f );
      fread( &m_InternalSize.width, sizeof( m_InternalSize.width ), 1, f );
      fread( &m_InternalSize.height, sizeof( m_InternalSize.height ), 1, f );
      fread( &m_ExternalSize.width, sizeof( m_ExternalSize.width ), 1, f );
      fread( &m_ExternalSize.height, sizeof( m_ExternalSize.height ), 1, f );

      // ...
      int iSize = ( m_CellSize.width * m_CellSize.height );

      // ...
      for ( int i = 0; i < 4; ++i )
      {
         m_aPattern[ i ] = new unsigned char[ iSize ];

         for ( int j = 0; j < iSize; ++j )
            fread( &m_aPattern[ i ][ j ], sizeof( unsigned char ), 1, f );
      }

      fclose( f );

      bOk = true;
   }   

   return bOk;
}