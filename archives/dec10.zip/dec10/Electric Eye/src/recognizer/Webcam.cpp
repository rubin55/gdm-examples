// ---
// --
// ---
#include <windows.h>
#include <gl\gl.h>
#include "cv.h"
#include "highgui.h"

#include "Webcam.h"

// ...
namespace Webcam
{
   CvCapture* s_pCapture   = NULL;
   IplImage*  s_pFrame     = NULL;
   IplImage*  s_pRGBFrame  = NULL;
   GLuint     s_uTextureID = 0;
   CvSize     s_WndSize;
};

// ------------------------------------------------------------------------------------------------------------------------
// --
// --
// ------------------------------------------------------------------------------------------------------------------------
bool Webcam::Init( const CvSize& WndSize )
{
   s_pCapture = cvCreateCameraCapture( CV_CAP_ANY );
   if ( s_pCapture == NULL )
      return false;

   cvSetCaptureProperty( s_pCapture, CV_CAP_PROP_FRAME_WIDTH, WndSize.width );

   s_pRGBFrame = cvCreateImage( WndSize, 8, 3 );

   // ... opengl texture ...
   glGenTextures( 1, &s_uTextureID );
   glBindTexture( GL_TEXTURE_2D, s_uTextureID );

   glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR );
	glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR );

   glTexImage2D( GL_TEXTURE_2D, 0, 3, WndSize.width, WndSize.height, 0, GL_RGB, GL_UNSIGNED_BYTE, NULL );

   // ...
   s_WndSize = WndSize;

   return true;
}

// ------------------------------------------------------------------------------------------------------------------------
// --
// --
// ------------------------------------------------------------------------------------------------------------------------
void Webcam::CaptureFrame()
{
   s_pFrame = cvQueryFrame( s_pCapture );

   // ... camera frame is in BGR, convert it to RGB ...
   if ( s_pFrame != NULL )
   {
      cvCvtColor( s_pFrame, s_pRGBFrame, CV_BGR2RGB );

      // ... copy to texture ...
	   glEnable( GL_TEXTURE_2D );
	   glBindTexture( GL_TEXTURE_2D, s_uTextureID );
	   glTexSubImage2D( GL_TEXTURE_2D, 0, 0, 0, s_WndSize.width, s_WndSize.height, GL_RGB, GL_UNSIGNED_BYTE, s_pRGBFrame->imageData );
   }
}

// ------------------------------------------------------------------------------------------------------------------------
// --
// --
// ------------------------------------------------------------------------------------------------------------------------
void Webcam::PresentFrame()
{
   if ( s_pFrame != NULL )
   {
      glDisable( GL_CULL_FACE );
      glDisable( GL_LIGHTING );
      glDisable( GL_DEPTH_TEST );

      glPolygonMode( GL_BACK, GL_FILL );

      glMatrixMode( GL_PROJECTION );
      glLoadIdentity();

      glOrtho( 0, s_WndSize.width, s_WndSize.height, 0, -1.f, 1.f );

      glMatrixMode( GL_MODELVIEW );
      glLoadIdentity();

      glEnable( GL_TEXTURE_2D );
      glBindTexture( GL_TEXTURE_2D, s_uTextureID );

      glTranslatef( 0.f, 0.f, 0.f );
      glColor3f( 1.f, 1.f, 1.f );

      // ...
      glBegin( GL_QUADS );
         glTexCoord2f( 0.f, 0.f );
         glVertex2f( 0.f, 0.f );

         glTexCoord2f( 1.f, 0.f );
         glVertex2f( ( float )( s_WndSize.width - 1 ), 0.f );

         glTexCoord2f( 1.f, 1.f );
         glVertex2f( ( float )( s_WndSize.width  - 1 ), ( float )( s_WndSize.height - 1 ) );

         glTexCoord2f( 0.f, 1.f );
         glVertex2f( 0.f, ( float )( s_WndSize.height - 1 ) );
      glEnd();
   }
}

// ------------------------------------------------------------------------------------------------------------------------
// --
// --
// ------------------------------------------------------------------------------------------------------------------------
void Webcam::End()
{
   if ( s_pCapture != NULL )
      cvReleaseCapture( &s_pCapture );

   if ( s_pRGBFrame != NULL )
      cvReleaseImage( &s_pRGBFrame );

   if ( s_uTextureID != 0 )
      glDeleteTextures( 1, &s_uTextureID );
}

// ------------------------------------------------------------------------------------------------------------------------
// --
// --
// ------------------------------------------------------------------------------------------------------------------------
IplImage* Webcam::GetFrame()
{
   return s_pFrame;
}