// ---
// --
// ---
#include <windows.h>
#include <gl\gl.h>
#include <gl\glu.h>

#include "GLWindow.h"

// ...
LRESULT CALLBACK WndProc ( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam );

namespace GLWindow
{
   void CreateWindowGL( int iWidth, int iHeight, int iBits, bool bFullscreen );

   // ...
   HINSTANCE  s_hInstance                = NULL;
   HWND       s_hWnd                     = NULL;
   HDC        s_hDC                      = NULL;
   HGLRC      s_hRC                      = NULL;
   bool       s_bFullscreen              = false;
   bool       s_bExitApp                 = false;
   bool       s_abKeyPressed[ NUM_KEYS ] = { false };
   MSG        s_Msg;
};

// ------------------------------------------------------------------------------------------------------------------------
// --
// --
// ------------------------------------------------------------------------------------------------------------------------
void GLWindow::CreateWindowGL( int iWidth, int iHeight, int iBits, bool bFullscreen )
{
   GLuint		PixelFormat;
	WNDCLASS	   wc;
	DWORD		   dwExStyle;
	DWORD		   dwStyle;
	RECT		   WindowRect;

	WindowRect.left   = 0;
	WindowRect.right  = iWidth;
	WindowRect.top    = 0;
	WindowRect.bottom = iHeight;

	s_hInstance			= GetModuleHandle( NULL );
	wc.style			   = CS_HREDRAW | CS_VREDRAW | CS_OWNDC;
	wc.lpfnWndProc		= WndProc;
	wc.cbClsExtra		= 0;
	wc.cbWndExtra		= 0;
	wc.hInstance		= s_hInstance;
	wc.hIcon			   = LoadIcon( NULL, IDI_WINLOGO );
	wc.hCursor			= LoadCursor( NULL, IDC_ARROW );
	wc.hbrBackground	= NULL;
	wc.lpszMenuName	= NULL;
	wc.lpszClassName	= "OpenGL";

	s_bFullscreen     = bFullscreen;

	RegisterClass( &wc );
	
	if ( s_bFullscreen )
	{
		DEVMODE dmScreenSettings;

		memset( &dmScreenSettings, 0, sizeof( dmScreenSettings ) );

		dmScreenSettings.dmSize       = sizeof( dmScreenSettings );
		dmScreenSettings.dmPelsWidth	= iWidth;
		dmScreenSettings.dmPelsHeight	= iHeight;
		dmScreenSettings.dmBitsPerPel	= iBits;
		dmScreenSettings.dmFields     = ( DM_BITSPERPEL | DM_PELSWIDTH | DM_PELSHEIGHT );

		// ...
		if ( ChangeDisplaySettings( &dmScreenSettings, CDS_FULLSCREEN )!= DISP_CHANGE_SUCCESSFUL )
		{
			// ... windowed ...
		   s_bFullscreen = false;
		}
	}

   // ...
	if ( s_bFullscreen )
	{
		dwExStyle = WS_EX_APPWINDOW;
		dwStyle   = WS_POPUP;

		ShowCursor( false );
	}
	else
	{
		dwExStyle = ( WS_EX_APPWINDOW | WS_EX_WINDOWEDGE );
		dwStyle   = WS_OVERLAPPEDWINDOW;
	}

   // ...
	AdjustWindowRectEx( &WindowRect, dwStyle, false, dwExStyle );

	// ... Create the window ...
	s_hWnd = CreateWindowEx( dwExStyle, "OpenGL", "recognizer", dwStyle | WS_CLIPSIBLINGS | WS_CLIPCHILDREN, 0, 0, WindowRect.right - WindowRect.left, 
                            WindowRect.bottom - WindowRect.top, NULL, NULL, s_hInstance, NULL );

   // ...
   PIXELFORMATDESCRIPTOR pfd;

   memset( &pfd, 0, sizeof( pfd ) );

   pfd.nSize      = sizeof( PIXELFORMATDESCRIPTOR );
   pfd.nVersion   = 1;
   pfd.dwFlags    = ( PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL | PFD_DOUBLEBUFFER );
   pfd.iPixelType = PFD_TYPE_RGBA;
   pfd.cColorBits = iBits;
   pfd.cDepthBits = 16;
   pfd.iLayerType = PFD_MAIN_PLANE;

   // ...
   s_hDC = GetDC( s_hWnd );

	PixelFormat = ChoosePixelFormat( s_hDC,&pfd );
   SetPixelFormat( s_hDC, PixelFormat, &pfd );

	s_hRC = wglCreateContext( s_hDC );

   wglMakeCurrent( s_hDC, s_hRC );
}

// ------------------------------------------------------------------------------------------------------------------------
// --
// --
// ------------------------------------------------------------------------------------------------------------------------
bool GLWindow::Init( const CvSize& Size, int iBits, bool bFullscreen )
{
   CreateWindowGL( Size.width, Size.height, iBits, bFullscreen );

   // ... init opengl ...
	Resize( Size.width, Size.height );

   glShadeModel( GL_SMOOTH );
   glClearColor( 0.0f, 0.0f, 0.0f, 0.5f );
   glClearDepth( 1.0f );
   glEnable( GL_DEPTH_TEST );
   glDepthFunc( GL_LEQUAL );
   glHint( GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST );

   // ...
	ShowWindow( s_hWnd, SW_SHOW );
	SetForegroundWindow( s_hWnd );
	SetFocus( s_hWnd );
   
   return true;
}

// ------------------------------------------------------------------------------------------------------------------------
// --
// --
// ------------------------------------------------------------------------------------------------------------------------
void GLWindow::End()
{
	if ( s_bFullscreen )
	{
		ChangeDisplaySettings( NULL, 0 );
		ShowCursor( TRUE );
	}

	if ( s_hRC != NULL )
	{
      wglMakeCurrent( NULL, NULL );
		wglDeleteContext( s_hRC );

		s_hRC = NULL;
	}

	if ( s_hDC != NULL )
   {
      ReleaseDC( s_hWnd, s_hDC );
      s_hDC = NULL;
   }

	if ( s_hWnd != NULL )
   {
      DestroyWindow( s_hWnd );
      s_hWnd = NULL;
   }

	UnregisterClass( "OpenGL", s_hInstance );
   s_hInstance = NULL;
}

// ------------------------------------------------------------------------------------------------------------------------
// --
// --
// ------------------------------------------------------------------------------------------------------------------------
void GLWindow::Resize( int iWidth, int iHeight )
{
	glViewport( 0, 0, iWidth, iHeight );
}

// ------------------------------------------------------------------------------------------------------------------------
// --
// --
// ------------------------------------------------------------------------------------------------------------------------
void GLWindow::BeginDraw()
{
   glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
}

// ------------------------------------------------------------------------------------------------------------------------
// --
// --
// ------------------------------------------------------------------------------------------------------------------------
void GLWindow::EndDraw()
{
   SwapBuffers( s_hDC );
}

// ------------------------------------------------------------------------------------------------------------------------
// --
// --
// ------------------------------------------------------------------------------------------------------------------------
bool GLWindow::ProcessMessages()
{
   bool bEnd = false;

   while( PeekMessage( &s_Msg, NULL, 0, 0, PM_NOREMOVE ) )
   {
      if ( !GetMessage( &s_Msg, NULL, 0, 0 ) ) 
        bEnd = true;
      else
      {
        TranslateMessage( &s_Msg );
        DispatchMessage( &s_Msg );
      }
   }

   return ( bEnd || s_bExitApp );
}

// ------------------------------------------------------------------------------------------------------------------------
// --
// --
// ------------------------------------------------------------------------------------------------------------------------
bool GLWindow::IsKeyPressed( EKey Key )
{
   return s_abKeyPressed[ Key ];
}

// ------------------------------------------------------------------------------------------------------------------------
// --
// --
// ------------------------------------------------------------------------------------------------------------------------
LRESULT CALLBACK WndProc( HWND hWnd, UINT	uMsg, WPARAM wParam, LPARAM lParam )
{
   switch ( uMsg )
	{
		case WM_CLOSE:
			PostQuitMessage( 0 );
			return 0;

		case WM_SIZE:
         GLWindow::Resize( LOWORD( lParam ),HIWORD( lParam ) );
			return 0;

      case WM_KEYDOWN:
         if ( wParam == VK_F1 )
            GLWindow::s_abKeyPressed[ GLWindow::KEY_F1 ] = true;
         else if ( wParam == VK_ESCAPE )
            GLWindow::s_bExitApp = true;
         return 0;

      case WM_KEYUP:
         if ( wParam == VK_F1 )
            GLWindow::s_abKeyPressed[ GLWindow::KEY_F1 ] = false;
         return 0;
	}

   return DefWindowProc( hWnd, uMsg, wParam, lParam );
}