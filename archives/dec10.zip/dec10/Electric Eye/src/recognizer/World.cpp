// ---
// --
// ---
#include <windows.h>
#include <gl\gl.h>
#include <gl\glu.h>
#include <vector>
#include <math.h>

#include "World.h"

// ...
namespace World
{
   // ...
   struct TObject
   {
      int            iType;
      float          afRotation[ 9 ];
      float          afPosition[ 3 ];
      bool           bVisible;

      TObject()
      {
         iType    = OT_CUBE;
         bVisible = false;

         memset( afRotation, 0, sizeof( afRotation ) );
         memset( afPosition, 0, sizeof( afPosition ) );
      }
   };

   // ...
   void  DrawCube    ( float* pRotation, float* pPosition );
   void  GetOGLPos   ( int iX, int iY, float fZ, float* afPos3D );

   // ...
   std::vector< TObject* >    s_adObjects;
   float                      s_fAspect = 0.f;
   CvSize                     s_ScreenSize;
};

// ------------------------------------------------------------------------------------------------------------------------
// --
// --
// ------------------------------------------------------------------------------------------------------------------------
void World::End()
{
   for ( int i = 0; i < ( int )s_adObjects.size(); ++i )
      delete s_adObjects[ i ];

   s_adObjects.clear();
}

// ------------------------------------------------------------------------------------------------------------------------
// --
// --
// ------------------------------------------------------------------------------------------------------------------------
bool World::Init( const CvSize& ScreenSize )
{
   s_ScreenSize = ScreenSize;
   s_fAspect    = ( ( float )ScreenSize.width / ( float )ScreenSize.height );

   return true;
}

// ------------------------------------------------------------------------------------------------------------------------
// --
// --
// ------------------------------------------------------------------------------------------------------------------------
int World::AddObject( EObjectType eType )
{
   TObject* pObj = new TObject;
   pObj->iType = eType;

   s_adObjects.push_back( pObj );

   return ( int )( s_adObjects.size() - 1 );
}

// ------------------------------------------------------------------------------------------------------------------------
// --
// --
// ------------------------------------------------------------------------------------------------------------------------
void World::SetObjectVisible( int iIdxObject, bool bVisible )
{
   s_adObjects[ iIdxObject ]->bVisible = bVisible;
}

// ------------------------------------------------------------------------------------------------------------------------
// --
// --
// ------------------------------------------------------------------------------------------------------------------------
void World::SetObjectRotationAndPosition( int iIdxObject, float* pRotation, float* pPosition )
{   
   memcpy( s_adObjects[ iIdxObject ]->afRotation, pRotation, sizeof( s_adObjects[ iIdxObject ]->afRotation ) );
   memcpy( s_adObjects[ iIdxObject ]->afPosition, pPosition, sizeof( s_adObjects[ iIdxObject ]->afPosition ) );
}

// ------------------------------------------------------------------------------------------------------------------------
// --
// --
// ------------------------------------------------------------------------------------------------------------------------
void World::Draw()
{
   glEnable( GL_DEPTH_TEST );
   glDisable( GL_TEXTURE_2D );

	glMatrixMode( GL_PROJECTION );
	glLoadIdentity();

   gluPerspective( 45.f, s_fAspect, 0.1f, 1000.f );

   // ...
   int iNumObjs = ( int )s_adObjects.size();

   for ( int i = 0; i < iNumObjs; ++i )
   {
      if ( s_adObjects[ i ]->bVisible )
      {
         switch( s_adObjects[ i ]->iType )
         {
            case OT_CUBE:
               DrawCube( s_adObjects[ i ]->afRotation, s_adObjects[ i ]->afPosition );
               break;
         }
      }
   }
}

// ------------------------------------------------------------------------------------------------------------------------
// --
// --
// ------------------------------------------------------------------------------------------------------------------------
void World::DrawCube( float* pRotation, float* pPosition )
{
   glMatrixMode( GL_MODELVIEW );
   glLoadIdentity();

   // ...
   float afPos3D[ 3 ]   = { 0.f };
   float afMatrix[ 16 ] = { 0.f };

   afMatrix[ 15 ] = 1.f;

   // ... translation ...
   GetOGLPos( ( int )pPosition[ 0 ], ( int )pPosition[ 1 ], pPosition[ 2 ], &afMatrix[ 12 ] );

   // ... rotation ...
   for ( int f = 0; f < 3; f++ )
      memcpy( &afMatrix[ f * 4 ], &pRotation[ f * 3 ], sizeof( float ) * 3 );

   // ...
   glLoadMatrixf( afMatrix );

   // ...
   glBegin( GL_QUADS );								
      glColor3f( 0.0f, 1.f, 0.0f );		
      glVertex3f(  0.5f, 0.5f, 0.f );
      glVertex3f( -0.5f, 0.5f, 0.f );
      glVertex3f( -0.5f, 0.5f, 1.f );
      glVertex3f(  0.5f, 0.5f, 1.f );

      glColor3f( 1.f, 0.5f, 0.0f );
      glVertex3f(  0.5f, -0.5f, 1.f );
      glVertex3f( -0.5f, -0.5f, 1.f );
      glVertex3f( -0.5f, -0.5f, 0.f );
      glVertex3f(  0.5f, -0.5f, 0.f );

      glColor3f( 1.f, 0.0f, 0.0f );
      glVertex3f(  0.5f,  0.5f, 1.f );
      glVertex3f( -0.5f,  0.5f, 1.f );
      glVertex3f( -0.5f, -0.5f, 1.f );
      glVertex3f(  0.5f, -0.5f, 1.f );

      glColor3f( 1.f, 1.f, 0.0f );		
      glVertex3f(  0.5f, -0.5f, 0.f );
      glVertex3f( -0.5f, -0.5f, 0.f );
      glVertex3f( -0.5f,  0.5f, 0.f );
      glVertex3f(  0.5f,  0.5f, 0.f );

      glColor3f( 0.0f, 0.0f, 1.f );		
      glVertex3f( -0.5f,  0.5f, 1.f );
      glVertex3f( -0.5f,  0.5f, 0.f );
      glVertex3f( -0.5f, -0.5f, 0.f );
      glVertex3f( -0.5f, -0.5f, 1.f );

      glColor3f( 1.f, 0.0f, 1.f );		
      glVertex3f( 0.5f,  0.5f, 0.f );
      glVertex3f( 0.5f,  0.5f, 1.f );
      glVertex3f( 0.5f, -0.5f, 1.f );
      glVertex3f( 0.5f, -0.5f, 0.f );
   glEnd();
}

// ------------------------------------------------------------------------------------------------------------------------
// -- cast a ray from screen coords (iX, iY) using camera direction to fZ
// --
// ------------------------------------------------------------------------------------------------------------------------
void World::GetOGLPos( int iX, int iY, float fZ, float* afPos3D )
{
   GLdouble ray_x, ray_y, ray_z;
   GLint    viewport[ 4 ];
   GLdouble proj[ 16 ];
   GLdouble modelview[ 16 ];

   glGetIntegerv( GL_VIEWPORT, viewport );
   glGetDoublev( GL_PROJECTION_MATRIX, proj );
   glGetDoublev( GL_MODELVIEW_MATRIX, modelview );

   GLdouble _mouseY = viewport[ 3 ] - iY;

   gluUnProject( iX, _mouseY, 1.0f, modelview, proj, viewport, &ray_x, &ray_y, &ray_z );

   // ...
   afPos3D[ 0 ] = ( float )ray_x;
   afPos3D[ 1 ] = ( float )ray_y;
   afPos3D[ 2 ] = ( float )ray_z;

   float fVSize = ( float )sqrt( ( afPos3D[ 0 ] * afPos3D[ 0 ] ) + ( afPos3D[ 1 ] * afPos3D[ 1 ] ) + ( afPos3D[ 2 ] * afPos3D[ 2 ] ) );
   
   for ( int i = 0; i < 3; ++i )
      afPos3D[ i ] /= fVSize;

   afPos3D[ 0 ] *= fZ;
   afPos3D[ 1 ] *= fZ;
   afPos3D[ 2 ] *= fZ;
}