// ---
// -- Pattern Recognizer by Cesar Botana
// -- Warning: this is just a sample application. A complete error management isn't implemented.
// ---
#include <windows.h>

#include "GLWindow.h"
#include "Webcam.h"
#include "Recognizer.h"
#include "World.h"

// ...
#define APP_WIDTH    ( 640 )
#define APP_HEIGHT   ( 480 )

// ------------------------------------------------------------------------------------------------------------------------
// --
// --
// ------------------------------------------------------------------------------------------------------------------------
int WINAPI WinMain( HINSTANCE	hInstance, HINSTANCE	hPrevInstance, LPSTR	lpCmdLine, int	nCmdShow )
{
   CvSize WndSize = cvSize( APP_WIDTH, APP_HEIGHT );

   // ...
   GLWindow::Init( WndSize, 16, false );
   Webcam::Init( WndSize );
   Recognizer::Init( WndSize );
   World::Init( WndSize );

   // ... add patterns ...
   Recognizer::AddPattern( "teapot.pat" );
   Recognizer::AddPattern( "scooter.pat" );

   World::AddObject( World::OT_CUBE ); // <--| assign cube to teapot.pat
   World::AddObject( World::OT_CUBE ); // <--| assign cube to scooter.pat

   int iNumPatterns = Recognizer::GetNumPatterns();

   // ... messages loop ...
   while( !GLWindow::ProcessMessages() )
   {
      // ... update ...
      Webcam::CaptureFrame();
      Recognizer::AnalyzeImage( Webcam::GetFrame() );

      // ... draw ...
      GLWindow::BeginDraw();

      Webcam::PresentFrame();
      Recognizer::DrawDebug();

      // ...
      for ( int i = 0; i < iNumPatterns; ++i )
      {
         if ( Recognizer::PatternIsDetected( i ) )
         {
            World::SetObjectVisible( i, true );
            World::SetObjectRotationAndPosition( i, Recognizer::GetRotationMatrix( i ), Recognizer::Get2DPositionZ( i ) );
         }
         else
            World::SetObjectVisible( i, false );
      }

      World::Draw();

      // ...
      GLWindow::EndDraw();
   }

   // ...
   World::End();
   Recognizer::End();
   Webcam::End();
   GLWindow::End();

   // ...
   return 0;
}