// ---
// --
// ---
#ifndef _GLWINDOW_H
#define _GLWINDOW_H

#include "cxtypes.h"

namespace GLWindow
{
   enum EKey
   {
      KEY_F1 = 0,
      KEY_ESC,

      NUM_KEYS
   };

   // ...
   bool        Init              ( const CvSize& Size, int iBits, bool bFullscreen );
   void        End               ( );

   bool        ProcessMessages   ( );

   void        BeginDraw         ( );
   void        EndDraw           ( );

   void        Resize            ( int iWidth, int iHeight );

   bool        IsKeyPressed      ( EKey Key );
}

#endif // _GLWINDOW_H