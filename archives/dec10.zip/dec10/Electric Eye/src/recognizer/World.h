// ---
// --
// ---
#ifndef _WORLD_H
#define _WORLD_H

#include "cxtypes.h"

namespace World
{
   enum EObjectType
   {
      OT_CUBE = 0
   };

   // ...
   bool        Init                          ( const CvSize& ScreenSize );
   void        End                           ( );

   void        Draw                          ( );

   int         AddObject                     ( EObjectType eType );

   void        SetObjectVisible              ( int iIdxObject, bool bVisible );
   void        SetObjectRotationAndPosition  ( int iIdxObject, float* pRotation, float* pPosition );
}

#endif // _WORLD_H