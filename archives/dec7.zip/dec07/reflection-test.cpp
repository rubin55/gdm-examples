// reflection-test.cpp
// Copyright (c) 2007 Mick West
// http://cowboyprogramming.com/
// Permission is hereby granted, free of charge, to any person obtaining a 
// copy of this software and associated documentation files (the "Software"),
// to deal in the Software without restriction, including without limitation
// the rights to use, copy, modify, merge, publish, distribute, sublicense,
// and/or sell copies of the Software, and to permit persons to whom the
// Software is furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included
// in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
// OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
// IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
// ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
// DEALINGS IN THE SOFTWARE.
//

// This is proof-of-concept code, and as such is not 64-bit safe.
// Compile without /Wp64 to avoid warnings about pointer arithmatic
// Should otherwise build and run as a standard Visual Studio console application
// (Without precompiled headers)
// and I don't think it really has anything compiler specific, except the pragma, which you can remove

#include <stdio.h>
#include <string.h>
#pragma warning( disable : 4996 ) // disable deprecated warning 


//////////////////////////////////////////////////////////////////////////
// Simple Vector3 lib (not really funtional)

class	Vector3	
{
public:
	float x,y,z;	
	Vector3();
	Vector3(float x,float y, float z);
};

Vector3::Vector3() {}

Vector3::Vector3(float vx, float vy, float vz)
{
	x=vx;
	y=vy;
	z=vz;
}


/*
// Reflection tables can be created at run-time
CReflection m_ref[] = {
	{"m_id",REF_INT,(int)&((CGameObj1*)NULL)->m_id},
	{"m_velocity",REF_VECTOR3,(int)&((CGameObj1*)NULL)->m_velocity},
};
*/

///////////////////////////////////////////////////////////////////////////////

// LISTING 1 START

#define	MAX_REF 32
#define MAX_ID_LEN 128
 


enum	EReflectionType
{
		REF_INT,
		REF_VECTOR3,
		REF_FLOAT
};

class CReflection
{
public:
	char			m_name[MAX_ID_LEN];
	EReflectionType m_type;
	int				m_offset;
};

class	CReflectInfo
{
public:
	void Register(EReflectionType type, const char* p_name, int offset);
	int	m_num_refs;
	CReflection	m_ref_table[MAX_REF];
};

void	CReflectInfo::Register(EReflectionType type, const char* p_name, int offset)
{
	strncpy(m_ref_table[m_num_refs].m_name,p_name,MAX_ID_LEN);
	m_ref_table[m_num_refs].m_offset = offset;
	m_ref_table[m_num_refs++].m_type = type;
	printf ("Register(%d, %s, %d)\n",type, p_name, offset);
}


// Base type for all object that are to be reflected
class	CReflectable
{
public:
	void	RegisterMembers(CReflectInfo* p_info) {};
	void *  GetMemberPointer(const char *p_member_name);
	template <typename T> 
	T		RGet(const char *p_member_name);
	template <typename T> 
	void	RSet(const char *p_member_name,T value);
	void	DumpMembers();
	virtual CReflectInfo * GetReflectInfo()=0;
};

// LISTING 1 END


// LISTING 2 - Two data types, showing how reflection info is added and the utility functions to register them
#define REFLECTION_INFO	static CReflectInfo m_ref_info; \
	virtual CReflectInfo * GetReflectInfo() {return &m_ref_info;} \
	void RegisterMembers(CReflectInfo* p_info); 

#define REGISTER(TYPE,MEMBER)	p_info->Register(TYPE,#MEMBER,(int)((long)&MEMBER-(long)this))

class CGameObj1 : public CReflectable 
{
public:
	REFLECTION_INFO;
	int GetID() {return m_id;}
	int			m_id;
	Vector3		m_position;
	Vector3		m_velocity;
	float		m_power;
};



inline void CGameObj1::RegisterMembers(CReflectInfo* p_info)
{

	REGISTER(REF_INT,m_id);
	REGISTER(REF_VECTOR3,m_position);
	REGISTER(REF_VECTOR3,m_velocity);
	REGISTER(REF_FLOAT,m_power);
}

class CGameobj1 : public CGameObj1
{
public:
	REFLECTION_INFO;
	int			m_count;
};

inline void CGameobj1::RegisterMembers(CReflectInfo* p_info)
{
	// Register parent class's members
	CGameObj1::RegisterMembers(p_info);
	// Then this object's 
	REGISTER(REF_INT,m_count);
}

// LISITNG END

// LISTING 3 - Initialize the reflection information for each class
template <class T>
void InitReflect() { ((T*)NULL)->RegisterMembers(&T::m_ref_info); }

CReflectInfo CGameObj1::m_ref_info; 
CReflectInfo CGameobj1::m_ref_info; 

void	ReflectAllObjects()
{
   InitReflect<CGameObj1>();
   InitReflect<CGameobj1>();
}

// LISTING END

// LISTING 4 - Reflected access and modification of object member by name
void * CReflectable::GetMemberPointer(const char *p_member_name)
{
	CReflectInfo *p_info = GetReflectInfo();
	CReflection *p_ref = p_info->m_ref_table;
	for (int i=0;i<p_info->m_num_refs;i++) {
		if (strcmp(p_ref[i].m_name,p_member_name)==0) {
			return (void*)((int)this + (int)p_ref[i].m_offset);
		}
	}
	return NULL;
}

template <typename T>
T CReflectable::RGet(const char *p_member_name)
{
	return *(T*)GetMemberPointer(p_member_name);
}

template <typename T>
void CReflectable::RSet(const char *p_member_name, T value)
{
	*(T*)GetMemberPointer(p_member_name) = value;
}
// LISTING end


// LISTING 4 - Dump the members of a structure, the basis of a serialization function
void CReflectable::DumpMembers()
{
	CReflectInfo *p_info = GetReflectInfo();
	CReflection  *p_ref  = p_info->m_ref_table;
	for (int i=0;i<p_info->m_num_refs;i++) {
		void *p = (void*)((int)this + (int)p_ref[i].m_offset);
		printf ("%d,%s,",p_ref[i].m_type,p_ref[i].m_name);
		switch (p_ref[i].m_type) {
		case REF_INT:
			printf("%d",*(int*)p);
			break;
		case REF_VECTOR3:
			printf("%f,%f,%f",(*(Vector3*)p).x,(*(Vector3*)p).y,(*(Vector3*)p).z);
			break;
		case REF_FLOAT:
			printf("%f",*(float*)p);
			break;
		}
		printf("\n");	
	}
}

// LISTING END




// LISTING 6 START - test code showing getting and setting via name, and dumping an arbitary structure.
int main(int argc, char* argv[])
{

	ReflectAllObjects();

	CGameObj1 *p_obj1 = new CGameObj1; 
	CGameobj1 *p_obj2 = new CGameobj1; 

	p_obj1->m_id = 2;
	p_obj1->m_position = Vector3(1,2,3);
	p_obj1->m_velocity = Vector3(4,5,6);
	p_obj1->m_power = 1.666f;

	printf("p_obj1->GetID() = %d\n",p_obj1->GetID());
	printf("p_obj1->RGet<int>(\"m_id\") = %d\n",p_obj1->RGet<int>("m_id"));
	printf("Reflected m_power = %f\n",p_obj1->RGet<float>("m_power"));
	p_obj1->RSet("m_id", 5);
	printf("Reflected m_id = %d\n",p_obj1->RGet<int>("m_id"));

	p_obj2->m_id = 3;
	p_obj2->m_position = Vector3(11,12,13);
	p_obj2->m_velocity = Vector3(14,15,16);
	p_obj2->m_power = 11.666f;
	p_obj2->m_count = 1100;

	p_obj1->DumpMembers();
	p_obj2->DumpMembers();

	return 0;
}
// LISTING END

