/*
MySQL Data Transfer
Source Host: localhost
Source Database: db1
Target Host: localhost
Target Database: db1
Date: 11/5/2007 9:01:05 AM
*/

SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Table structure for asserts
-- ----------------------------
CREATE TABLE `asserts` (
  `assert` text,
  `message` text,
  `file` text,
  `line` int(11) default NULL,
  `machine` text,
  `time` timestamp NULL default CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Table structure for table1
-- ----------------------------
CREATE TABLE `table1` (
  `id` int(11) NOT NULL auto_increment,
  `name` text,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12668 DEFAULT CHARSET=latin1;


