// mysql_test.cpp : Sample code to generate unique IDs with a database, and 
// a version of assert() that logs useful information to a database
// Released into the Public Domain November 2007, Mick West.  
// http://cowboyprogramming.com/inner-product/
//

#include "stdafx.h"
#include <stdio.h>
#include <stdlib.h>
#define W32_LEAN_AND_MEAN
#include <winsock2.h>
#include "mysql.h"


#define SERVER_NAME "localhost"
#define DB_USER "user_name"
#define DB_USERPASS "password"
#define DB_NAME "db1"

typedef	unsigned int uint32;

MYSQL *handle=NULL;


uint32 GetID(const char *name)
{
	char select_query[1024];
	char add_query[1024];
	MYSQL_RES *result=NULL; // result of querying for all rows in table
    MYSQL_ROW row; // one row returned
	uint32 id = -1;
	sprintf(select_query,"SELECT * FROM table1 WHERE name='%s'",name);
    if (!mysql_query(handle,select_query))
	{
        result = mysql_use_result(handle);
        row = mysql_fetch_row(result);
		if (!row)
		{
			sprintf(add_query,"INSERT INTO `table1` (`id`,`name`) VALUES (NULL,'%s')",name);
			mysql_query(handle,add_query);			   
			mysql_query(handle,select_query);
			result = mysql_use_result(handle);
			row = mysql_fetch_row(result);
		}
		id = atoi(row[0]);
		mysql_free_result(result);
	}
	return id;
}

const char * GetMachineName()
{
	return "Mick";
}

char assert_buffer[1024];
void		assert_printf( const char* text, ... ) 
{
	va_list a;
	va_start(a, text );
	vsprintf( assert_buffer,text,a);
	va_end(a);
}

void SQLAssert(const char *assert, const char *file, int line)
{
	printf ("%s, %s, %d\n",assert_buffer, file, line);
	char query[2048];
	sprintf(query,"INSERT INTO `asserts` (`assert`,`message`,`file`,`line`,`machine`)	VALUES ('%s','%s','%s','%d','%s')",
		assert,assert_buffer,file,line,GetMachineName());
	mysql_query(handle,query);	
	if (0 /*don't ignore test goes here*/ ) __asm int 3
}

#define NewAssert( test)\
  if( !(test)) { \
	assert_buffer[0]=0 ;	\
	SQLAssert(#test,__FILE__,__LINE__); \
}

#define NewAssertM( test, params )\
  if( !(test)) { \
	assert_printf params ;	\
	SQLAssert(#test,__FILE__,__LINE__); \
}

// Usage, note extra parentheses:
//	NewAssertM(p==NULL,("p not NULL (%p)",p));
//	NewAssert(p==NULL);



int main(int argc, char* argv[])
{

    handle = mysql_init(NULL);
    mysql_real_connect(handle,SERVER_NAME,DB_USER,DB_USERPASS,DB_NAME,0,NULL,0);

	GetID("MDL_MECH01_LARGE");
	GetID("MDL_MECH02_LARGE");
	GetID("ANM_FOX_JUMP");


	char *p = "ff";
	NewAssertM(p==NULL,("p not NULL (%p)",p));
	NewAssert(p==NULL);

	mysql_close(handle);

    return 0;
}






