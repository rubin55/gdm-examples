This demo shows how to set up 3D stereo reprojection. It swaps between two modes: standard stereo, where you render a scene twice, and reprojection, where you render the scene once and use a shader to reproject to the left and right views. It uses anaglyphic stereo (magenta and green), so get out your old copy of Coraline or How to Train Your Dragon to view it.

I'm using OpenGL 2.4 here, mainly because that's all my poor laptop supports.

The code is broken up as follows:

Main.cpp:          Where we find main().
Framework.{cpp,h}: Sets up the GLUT callbacks.
Input.{cpp,h}:     Simple input handling.
Shader.{cpp,h}:    Set up all the shaders and shader programs.
Render.{cpp,h}:    The lion's share of the work is here. This sets the base OpenGL context, constructs the render targets, handles 
                   input and does the high-level setup for the stereo modes.

There are some open issues:
1) The base scene is very simple, so reprojection in this case is actually slower than rendering the scene twice. Adding a more complex scene would do a better job of demonstrating the appeal of reprojection. For now it stands as an example of how to set things up for such a complex scene.
2) To avoid the black bars on the left and right of the reprojected scene (used to cover up reconstruction errors) we should expand our viewport and then crop the result when copying the reprojected result to the final display. A future version of this demo will include that.
3) The code to generate linear depth textures isn't complete -- for some reason my Mac driver doesn't support attaching a luminance texture to an FBO, and on other cards it appears to do nothing. The #define LINEAR_DEPTH enables and disables this. Because the luminance texture values run from 0 to 1, the parameter s*c gets divided by the far plane value to maintain the same units.

Controls
--------
T: switch between standard and reprojection stereo
W,S: move forward and backward
A,D: turn left and right

Enjoy, and let me know if there are any problems. Updates will be available at the website www.essentialmath.com.

Jim Van Verth
jim@essentialmath.com