//
//  GLUTSetup.cpp
//  Stereo
//
//  Created by James Van Verth on 4/11/12.
//  Copyright (c) 2012 James M. Van Verth. All rights reserved.
//

#include "Framework.h"

#include <stdio.h>
#ifdef PLATFORM_OSX
#include <GLUT/glut.h>
#else
#include <GL/glew.h>
#include <GL/wglew.h>
#include <GL/glut.h>
#endif
#include "Render.h"
#include "Input.h"

namespace Framework
{

// forward decls
extern "C" void DisplayCallback(void);
extern "C" void VisibilityCallback(int vis);
extern "C" void ReshapeCallback(int w, int h);
extern "C" void KeyboardCallback(unsigned char key, int x, int y);
extern "C" void KeyboardupCallback(unsigned char key, int x, int y);
extern "C" void MouseCallback(int button, int state, int x, int y);
extern "C" void IdleCallback(void);

int s_LastTime = 0;

//
// Main init function
//
void Init(int argc, char** argv)
{
    glutInit(&argc,argv); 
    glutInitDisplayMode (GLUT_DOUBLE | GLUT_RGB);  
    
    glutInitWindowSize(1024, 768);
    glutCreateWindow("Stereo: Standard");

	glutInitWindowPosition(0,0); 

	s_LastTime = glutGet(GLUT_ELAPSED_TIME);
    
#ifndef PLATFORM_OSX
	GLenum err = glewInit();
    if ( GLEW_OK != err )
    {
        printf("Error: %s\n", glewGetErrorString(err));
        return;
    }

    // check for version compatibility
    if ( !GLEW_VERSION_2_0 )
    {
        printf("Error: OpenGL version 2.0 is not supported.\n");
        return;
    }

    // check for ARB compatibility
    if ( !GLEW_ARB_shader_objects || !GLEW_ARB_fragment_shader || !GLEW_ARB_vertex_shader )
    {
        printf("Error: GLSL is not supported.\n");
        return;
    }

    printf("Using GLEW %s\n", glewGetString(GLEW_VERSION));

	if ( WGLEW_EXT_swap_control )
	{
		wglSwapIntervalEXT(1);
	}
#endif
	
	Render::Init(1024, 768);
    
    glutDisplayFunc(DisplayCallback);
    
    // set up display callbacks
    glutDisplayFunc(DisplayCallback);
    glutVisibilityFunc(VisibilityCallback);
    glutReshapeFunc(ReshapeCallback);
    
    // set up event handler
    glutIgnoreKeyRepeat(1);
    glutKeyboardFunc(KeyboardCallback);
    glutKeyboardUpFunc(KeyboardupCallback);
    glutMouseFunc(MouseCallback);
    
    // set up game update
    glutIdleFunc(IdleCallback);
    
}

//
// Main run function
//
void Run()
{
	glutMainLoop();
}


//
// GLUT Callbacks
//
extern "C"
void DisplayCallback(void)
{
    Render::DisplayScene( 0 );
}

extern "C" 
void VisibilityCallback(int vis)
{
    Render::Activate( vis == GLUT_VISIBLE );
}
    
extern "C" 
void ReshapeCallback(int w, int h)
{
    Render::Resize( w, h );
}
    
extern "C" 
void KeyboardCallback(unsigned char key, int x, int y)
{
    Input::OnKeyDown( key );
}
    
extern "C" 
void KeyboardupCallback(unsigned char key, int x, int y)
{
    Input::OnKeyUp( key );
}
    
extern "C" 
void MouseCallback(int button, int state, int x, int y)
{
}
    
extern "C" 
void IdleCallback(void)
{
	int time = glutGet(GLUT_ELAPSED_TIME);
	int interval = 0;
	if ( time < s_LastTime )
	{
		// Not sure if this will work, can't find where GLUT_ELAPSED_TIME will wrap. But it's a guess.
		interval = 0x7ffffff - (s_LastTime - time);
	}
	else
	{
		interval = time - s_LastTime;
	}
	s_LastTime = time;

    Render::DisplayScene( interval );
    
    glutSwapBuffers();
    
    Input::Update();
}
    
};