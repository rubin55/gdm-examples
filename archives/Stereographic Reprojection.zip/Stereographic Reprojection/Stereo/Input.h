//
//  Input.h
//  Stereo
//
//  Created by James Van Verth on 8/18/12.
//  Copyright (c) 2012 James M. Van Verth. All rights reserved.
//

#ifndef Stereo_Input_h
#define Stereo_Input_h

namespace Input
{
    void OnKeyDown( unsigned char key );
    void OnKeyUp( unsigned char key );
    
    bool KeyPressed( unsigned char key );   // was key pressed this frame
    bool KeyReleased( unsigned char key );  // was key released this frame
    bool KeyDown( unsigned char key );      // is key down
    bool KeyUp( unsigned char key );        // is key up
    
    void Update();                          // update key state
}

#endif
