//
//  Render.h
//  Stereo
//
//  Created by James Van Verth on 4/11/12.
//  Copyright (c) 2012 James M. Van Verth. All rights reserved.
//

#ifndef Stereo_Render_h
#define Stereo_Render_h

namespace Render
{
    void Init( int w, int h );
    void Activate( bool active );
    void Resize( int w, int h );
    
    void DisplayScene( int interval );
    void DrawObjects();
    void SetProjection( float interocular, float convergence, float screenWidth, float eye );
}

#endif
