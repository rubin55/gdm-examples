//
//  Input.cpp
//  Stereo
//
//  Created by James Van Verth on 8/18/12.
//  Copyright (c) 2012 James M. Van Verth. All rights reserved.
//

#include <string.h>
#include "Input.h"

namespace Input
{
    static bool s_Key[256]         = {0};    
    static bool s_KeyPressed[256]  = {0};    
    static bool s_KeyReleased[256] = {0};    
        
    void OnKeyDown( unsigned char key )
    {
        if (!s_Key[key])
        {
            s_Key[key] = true;
            s_KeyPressed[key] = true;
        }
    }
        
    void OnKeyUp( unsigned char key )
    {
        if (s_Key[key])
        {
            s_Key[key] = false;
            s_KeyReleased[key] = true;
        }
    }

    bool KeyPressed( unsigned char key )
    {
        return s_KeyPressed[key];
    }
    
    bool KeyReleased( unsigned char key ) 
    {
        return s_KeyReleased[key];
    }
    
    bool KeyDown( unsigned char key )
    {
        return s_Key[key];
    }
    
    bool KeyUp( unsigned char key )
    {
        return !s_Key[key];
    }
    
    void Update()
    {
        memset( s_KeyPressed, 0, sizeof(bool)*256 );
        memset( s_KeyReleased, 0, sizeof(bool)*256 );
    }
}
