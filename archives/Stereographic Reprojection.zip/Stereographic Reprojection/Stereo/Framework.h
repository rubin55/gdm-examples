//
//  GLUTSetup.h
//  Stereo
//
//  Created by James Van Verth on 4/11/12.
//  Copyright (c) 2012 James M. Van Verth. All rights reserved.
//

#ifndef Stereo_GLUTSetup_h
#define Stereo_GLUTSetup_h

namespace Framework 
{
    void Init(int argc, char** argv);
    void Run();
}

#endif
