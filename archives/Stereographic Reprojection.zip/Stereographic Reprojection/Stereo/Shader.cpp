//
//  Shader.cpp
//  Stereo
//
//  Created by James Van Verth on 4/12/12.
//  Copyright (c) 2012 James M. Van Verth. All rights reserved.
//

#include "Shader.h"

#ifdef PLATFORM_OSX
#include <OpenGL/gl.h>
#else
#include <GL/glew.h>
#endif
#include <stdio.h>
#include <string.h>

namespace Shader
{
    static VertexShader s_VertShaderNP;
//    static VertexShader s_VertShaderP;
    static VertexShader s_VertShaderTP;
    
    static FragmentShader s_FragShaderGouraud;
    static FragmentShader s_FragShaderTexture;
    static FragmentShader s_FragShaderLinearDepth;
    static FragmentShader s_FragShaderStereo;
//    static FragmentShader s_FragShaderTest;
    
    static Program      s_LightingProgram;
    static Program      s_DisplayCopyProgram;
    static Program      s_DisplayStereoProgram;
    static Program      s_LinearDepthProgram;
    
    VertexShader CreateVertexShader( const char* string );
    void DestroyVertexShader( VertexShader shaderID );
    
    FragmentShader CreateFragmentShader( const char* string );
    void DestroyFragmentShader( FragmentShader shaderID );
    
    Program CreateProgram( VertexShader vertexShaderID, FragmentShader fragmentShaderID );
    void SetActiveProgram( Program programID );
    void DestroyProgram( Program programID );
    
    void SetFloat4Constant( Program program, const char* name, float* values );
    void SetMatrix44Constant( Program program, const char* name, float* values );
    void SetTextureSampler( Program program, const char* name, GLuint textureID, GLuint textureUnit );
    
    static const char s_VertShaderNPStr[] = 
    "uniform vec4 uLightDirection;\n"
    "uniform vec4 uLightAmbient;\n"
    "uniform vec4 uLightDiffuse;\n"
    "varying vec4 color;\n"
    "void main()\n"\
    "{\n"
    "    gl_Position = ftransform();\n"
    "    vec4 transNormal = vec4(normalize(gl_NormalMatrix * gl_Normal), 0.0);\n"
    "    float ndotVP = clamp(dot(transNormal, uLightDirection), 0.0, 1.0);\n"
    "    vec4 lightValue = uLightAmbient + uLightDiffuse*ndotVP;\n"
    "    color = lightValue*gl_Color;\n"
    "//    uv = gl_MultiTexCoord0.xy;\n"
    "}\n";
    
    static const char s_VertShaderPStr[] = 
    "void main()\n"\
    "{\n"
    "    gl_Position = ftransform();\n"
    "}\n";
    
    static const char s_VertShaderTPStr[] = 
    "varying vec2 uv;\n"
    "void main()\n"\
    "{\n"
    "    gl_Position = ftransform();\n"
    "    uv = gl_MultiTexCoord0.xy;\n"
    "}\n";
    
    static const char s_FragShaderGouraudStr[] = 
    "varying vec4 color;\n"
    "void main()\n"
    "{\n"
    "    gl_FragColor = color;\n"
    "}\n";
    
    static const char s_FragShaderTextureStr[] = 
    "uniform sampler2D color_texture;\n"
    "varying vec2 uv;\n"
    "void main()\n"
    "{\n"
    "    gl_FragColor = texture2D(color_texture, uv);\n"
    "}\n";

    static const char s_FragShaderLinearDepthStr[] = 
    "uniform sampler2D depth_texture;\n"
    "varying vec2 uv;\n"
    "uniform vec4 depth_params;\n"
    "void main()\n"
    "{\n"
	"    vec4 depth = texture2D(depth_texture, uv);\n"
	"    gl_FragColor = vec4(depth_params.x/(depth_params.y - depth.x*depth_params.z)/depth_params.y);\n"
    "}\n";
       
    static const char s_FragShaderStereoStr[] = 
    "uniform sampler2D color_texture;\n"
    "uniform sampler2D depth_texture;\n"
    "uniform vec4 stereo_params;\n"
#ifndef LINEAR_DEPTH
    "uniform vec4 depth_params;\n"
#endif
    "varying vec2 uv;\n"
    "void main()\n"
    "{\n"
    "    vec2 out_tex_coords = uv - vec2(stereo_params.x, 0.0);\n"
    "    vec2 reproj_tex_coords = uv;\n"
    "    float s = sign(stereo_params.y);\n"
    "    float orig_x = uv.x;\n"
    "    float shift = stereo_params.z;\n"
    "    float step = 0.0625*stereo_params.w;\n"
    "    int index = 0;\n"
    "    while (index <= 16)\n"
    "    {\n"
    "        reproj_tex_coords.x = orig_x + shift;\n"
    "        vec4 depth = texture2D(depth_texture, reproj_tex_coords);\n"
#ifdef LINEAR_DEPTH
    "        float depth_adjust = stereo_params.x + stereo_params.y / depth.x;\n"  
#else
    "        float l = depth_params.x/(depth_params.y - depth.x*depth_params.z);\n"
    "        float depth_adjust = stereo_params.x + stereo_params.y / l;\n"  
#endif
    "        float test = shift + depth_adjust;\n"
    "        if (s*test >= 0.0)\n"
    "        {\n"
    "            out_tex_coords.x = orig_x - depth_adjust;\n"
    "            break;\n"
    "        }\n"
    "        shift = shift + step; index = index + 1;\n"
    "    }\n"
    "    gl_FragColor = texture2D(color_texture, out_tex_coords);\n"
    "}\n";
       
    static const char s_FragShaderTestStr[] = 
    "void main()\n"
    "{\n"
    "    gl_FragColor = vec4(1.0, 1.0, 0.0, 1.0);\n"
    "}\n";
    
    void Init()
    {
        s_VertShaderNP = CreateVertexShader( s_VertShaderNPStr );
        s_FragShaderGouraud = CreateFragmentShader( s_FragShaderGouraudStr );
        
        s_LightingProgram = CreateProgram( s_VertShaderNP, s_FragShaderGouraud );
    
        s_VertShaderTP = CreateVertexShader( s_VertShaderTPStr );
        s_FragShaderTexture = CreateFragmentShader( s_FragShaderTextureStr );
        
 //       s_FragShaderTest = CreateFragmentShader( s_FragShaderTestStr );
        
        s_DisplayCopyProgram = CreateProgram( s_VertShaderTP, s_FragShaderTexture );
        
        s_FragShaderStereo = CreateFragmentShader( s_FragShaderStereoStr );
        s_DisplayStereoProgram = CreateProgram( s_VertShaderTP, s_FragShaderStereo );

		s_FragShaderLinearDepth = CreateFragmentShader( s_FragShaderLinearDepthStr );
        s_LinearDepthProgram = CreateProgram( s_VertShaderTP, s_FragShaderLinearDepth );
    }
    
    void SetBasicLighting()
    {
        float lightDir[4] = { .7f, .7f, 0.0f, 0.0f};
        float lightAmbient[4] = { .4f, .4f, .4f, 1.0f };
        float lightDiffuse[4] = { .6f, .6f, .6f, 0.0f };
        
        SetActiveProgram( s_LightingProgram );
        
        SetFloat4Constant( s_LightingProgram, "uLightDirection", lightDir );
        SetFloat4Constant( s_LightingProgram, "uLightAmbient", lightAmbient );
        SetFloat4Constant( s_LightingProgram, "uLightDiffuse", lightDiffuse );
    }
    
    void SetDisplayCopyShader( GLuint textureID )
    {
        SetActiveProgram( s_DisplayCopyProgram );
        
        SetTextureSampler( s_DisplayCopyProgram, "color_texture", textureID, 0 );
    }
    
    void SetDisplayStereoShader( GLuint colortextureID, GLuint depthtextureID, GLfloat* stereoParams, GLfloat* depthParams )
    {
        SetActiveProgram( s_DisplayStereoProgram );
        
        SetTextureSampler( s_DisplayStereoProgram, "color_texture", colortextureID, 0 );
        SetTextureSampler( s_DisplayStereoProgram, "depth_texture", depthtextureID, 1 );
        SetFloat4Constant( s_DisplayStereoProgram, "stereo_params", stereoParams );
#ifndef LINEAR_DEPTH
        SetFloat4Constant( s_DisplayStereoProgram, "depth_params", depthParams );
#endif
    }
    
    void SetLinearDepthShader( GLuint depthtextureID, GLfloat* depthParams )
    {
        SetActiveProgram( s_LinearDepthProgram );
        
        SetTextureSampler( s_LinearDepthProgram, "depth_texture", depthtextureID, 1 );
        SetFloat4Constant( s_LinearDepthProgram, "depth_params", depthParams );
    }
    
    VertexShader CreateVertexShader( const char* string )
    {
        // allocate the shader id
        GLuint shaderID = glCreateShader( GL_VERTEX_SHADER );
        if ( shaderID == 0 )
            return 0;
        
        // load in the source
        GLint length = strlen(string);
        glShaderSource( shaderID, 1, &string, &length );
        
        // compile it
        glCompileShader( shaderID );
        GLint status = 0;
        glGetShaderiv( shaderID, GL_COMPILE_STATUS, &status );
        if (status == 0)
        {
            GLint len;
            glGetShaderiv(shaderID, GL_INFO_LOG_LENGTH, &len);
            if (len > 0) 
            {
                char* str = new char[len];
                glGetShaderInfoLog(shaderID, len, NULL, str);
                printf("Shader error: %s\n", str);
            }
            return 0;
        }
        
        return shaderID;    
    }
    
    FragmentShader CreateFragmentShader( const char* string )
    {
        // allocate the shader id
        GLuint shaderID = glCreateShader( GL_FRAGMENT_SHADER );
        if ( shaderID == 0 )
            return 0;
        
        // load in the source
        GLint length = strlen(string);
        glShaderSource( shaderID, 1, &string, &length );
        
        // compile it
        glCompileShader( shaderID );
        GLint status = 0;
        glGetShaderiv( shaderID, GL_COMPILE_STATUS, &status );
        if (status == 0)
        {
            GLint len;
            glGetShaderiv(shaderID, GL_INFO_LOG_LENGTH, &len);
            if (len > 0) 
            {
                char* str = new char[len];
                glGetShaderInfoLog(shaderID, len, NULL, str);
                printf("Shader error: %s\n", str);
            }
            return 0;
        }
        
        return shaderID;    
    }
    
    void DestroyVertexShader( VertexShader shaderID )
    {
        glDeleteShader( shaderID );
    }
    
    void DestroyFragmentShader( FragmentShader shaderID )
    {
        glDeleteShader( shaderID );
    }
    
    Program CreateProgram( VertexShader vertexShaderID, FragmentShader fragmentShaderID )
    {
        // check for valid inputs
        if ( 0 == vertexShaderID || 0 == fragmentShaderID )
            return 0;
        
        // allocate the shader id
        GLuint programID = glCreateProgram();
        if ( programID == 0 )
            return 0;
        
        // attach the shaders
        glAttachShader( programID, vertexShaderID );
        glAttachShader( programID, fragmentShaderID );
        
        // link it
        glLinkProgram( programID );
        GLint status = 0;
        glGetProgramiv( programID, GL_LINK_STATUS, &status );
        if ( 0 == status )
        {
            GLint len;
            glGetProgramiv( programID, GL_INFO_LOG_LENGTH, &len );   
            if (len > 0) 
            {
                char* str = new char[len];
                glGetProgramInfoLog( programID, len, NULL, str );
                printf("Program error: %s\n", str);
            }
            return 0;
        }
        
        return programID;
    }
    
    void SetActiveProgram( Program programID )
    {
        glUseProgram( programID );
    }
    
    void DestroyProgram( Program programID )
    {
        if ( programID != 0 )
        {
            glDeleteProgram( programID );
        }
    }
    
    void SetFloat4Constant( Program program, const char* name, float* values )
    {
        // First, query the location
        GLint location = glGetUniformLocation(program, name);
        if (location == -1)
            return;
        
        glUniform4fv(location, 1, values); 
    }
    
    void SetMatrix44Constant( Program program, const char* name, float* values )
    {
        // First, query the location
        GLint location = glGetUniformLocation(program, name);
        if (location == -1)
            return;
        
        glUniform4fv(location, 4, values); 
    }

    void SetTextureSampler( Program program, const char* name, GLuint textureID, GLuint textureUnit )
    {
        // First, query the location
        GLint location = glGetUniformLocation(program, name);
        if (location == -1)
            return;
        
        // bind to texture unit
        glActiveTexture(GL_TEXTURE0+textureUnit);
        glBindTexture(GL_TEXTURE_2D, textureID);
        
        // tie sampler to texture unit
        glUniform1iARB(location, textureUnit);
    }
}