//
//  main.cpp
//  Stereo
//
//  Created by James Van Verth on 4/11/12.
//  Copyright (c) 2012 James M. Van Verth. All rights reserved.
//

#include "Framework.h"
#include "Render.h"

// ---- Main Function ----
int main( int argc, char** argv )
{
    Framework::Init( argc, argv );    
    Framework::Run();
}
