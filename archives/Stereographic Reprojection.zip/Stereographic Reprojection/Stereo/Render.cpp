//
//  Render.cpp
//  Stereo
//
//  Created by James Van Verth on 4/11/12.
//  Copyright (c) 2012 James M. Van Verth. All rights reserved.
//

#include "Render.h"

#ifdef PLATFORM_OSX
#include <OpenGL/gl.h>
#include <GLUT/glut.h>
#else
#include <GL/glew.h>
#include <GL/glut.h>
#endif

#include <stdio.h>
#include <string.h>
#define _USE_MATH_DEFINES
#include <math.h>

#include "Shader.h"
#include "Input.h"

namespace Render
{

    static bool s_Active = false;
    
    static GLuint s_ColorTex = 0;
    static GLuint s_DepthTex = 0;
#ifdef LINEAR_DEPTH
    static GLuint s_LinearDepthTex = 0;
#endif
    static GLuint s_Fbo = 0;
    static GLuint s_LinearDepthFbo = 0;
   
    static int s_Width = 1024;
    static int s_Height = 768;
    
    static const float s_Interocular = 0.06f; // m
    static const float s_Convergence = 12.f; // m
    static const float s_ScreenWidth = 1.0f;  // m

	static float s_Pitch             = -70.f;
	static float s_Yaw               = -110.0f;
	static float s_CameraX           = 10.0f;
	static float s_CameraY           = 5.0f;
	static float s_CameraZ           = 4.0f;
    
    static const float s_FOV         = 50.f;
    static const float s_NearPlane   = 0.1f;
    static const float s_FarPlane    = 35.f;
    
    static bool s_UseReprojection = false;
    
    void CreateRenderTargets( int w, int h );
    void SetBaseRenderTarget();
    void SetLinearDepthRenderTarget();
    void CopyToDisplay();
    void CopyToStereoDisplay();
	void HandleInput( int inverval );
    
    // ---- Initialize Function ----
    void Init( int w, int h )
    {
        // turn on smooth shading
        glShadeModel(GL_SMOOTH);    
    
        // set clear color and depth
        glClearColor(0.2, 0.2, 0.2, 0.0); 
        glClearDepth(1.0);
        
        // set up depth buffer
        glEnable(GL_DEPTH_TEST);                            
        glDepthFunc(GL_LEQUAL); 
           
        // set up perspective correct textures
        glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);
    
        // turn on culling
        glCullFace(GL_BACK);
        glEnable(GL_CULL_FACE); 
        
        glEnable(GL_TEXTURE_2D);
    
        CreateRenderTargets( w, h );
    
        Shader::Init();
    
        Resize( w, h );
    }
    
    void CreateRenderTargets( int w, int h )
    {
        // Create base FBO
        glGenFramebuffersEXT(1, &s_Fbo);
        glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, s_Fbo);
        
        // RGBA8 2D color texture
        glGenTextures(1, &s_ColorTex);
        glBindTexture(GL_TEXTURE_2D, s_ColorTex);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        //NULL means reserve texture memory, but texels are undefined
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, 2048, 1024, 0, GL_RGBA, GL_UNSIGNED_BYTE, NULL);
        
        // 24 bit depth texture
        glGenTextures(1, &s_DepthTex);
        glBindTexture(GL_TEXTURE_2D, s_DepthTex);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_DEPTH_TEXTURE_MODE, GL_INTENSITY);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_COMPARE_MODE, GL_NONE);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_COMPARE_FUNC, GL_LEQUAL);
        //NULL means reserve texture memory, but texels are undefined
        glTexImage2D(GL_TEXTURE_2D, 0, GL_DEPTH_COMPONENT24, 2048, 1024, 0, GL_DEPTH_COMPONENT, GL_UNSIGNED_BYTE, NULL);

        // Attach textures to this FBO
        glFramebufferTexture2DEXT(GL_FRAMEBUFFER_EXT, GL_COLOR_ATTACHMENT0_EXT, GL_TEXTURE_2D, s_ColorTex, 0/*mipmap level*/);
        glFramebufferTexture2DEXT(GL_FRAMEBUFFER_EXT, GL_DEPTH_ATTACHMENT_EXT, GL_TEXTURE_2D, s_DepthTex, 0/*mipmap level*/);
      
        //-------------------------
        //Does the GPU support current FBO configuration?
        GLenum status;
        status = glCheckFramebufferStatusEXT(GL_FRAMEBUFFER_EXT);
        switch(status)
        {
            case GL_FRAMEBUFFER_COMPLETE_EXT:
                printf("FBO Good!\n");
                break;
            default:
                printf("FBO Bad!\n");
                break;
        }        
 
#ifdef LINEAR_DEPTH
        // Create linear depth FBO
        glGenFramebuffersEXT(1, &s_LinearDepthFbo);
        glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, s_LinearDepthFbo);
        
        // float 2D color texture
        glGenTextures(1, &s_LinearDepthTex);
        glBindTexture(GL_TEXTURE_2D, s_LinearDepthTex);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        //NULL means reserve texture memory, but texels are undefined
        glTexImage2D(GL_TEXTURE_2D, 0, GL_LUMINANCE, 2048, 1024, 0, GL_LUMINANCE, GL_UNSIGNED_BYTE, NULL);

		// Attach depth texture to this FBO
        glFramebufferTexture2DEXT(GL_FRAMEBUFFER_EXT, GL_COLOR_ATTACHMENT0_EXT, GL_TEXTURE_2D, s_LinearDepthTex, 0/*mipmap level*/);

        //-------------------------
        //Does the GPU support current FBO configuration?
        status = glCheckFramebufferStatusEXT(GL_FRAMEBUFFER_EXT);
        switch(status)
        {
            case GL_FRAMEBUFFER_COMPLETE_EXT:
                printf("FBO Good!\n");
                break;
            default:
                printf("FBO Bad!\n");
                break;
        }        
#endif
		// switch back to back buffer
        glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, 0);
   }
    
    void SetBaseRenderTarget()
    {
        glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, s_Fbo);
        glViewport(0, 0, 2048, 1024);
    }
    
    void SetLinearDepthRenderTarget()
    {
        glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, s_LinearDepthFbo);
        glViewport(0, 0, 2048, 1024);
    }

    void CopyToDisplay()
    {
        glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, 0);
        glViewport(0, 0, s_Width, s_Height);
        glDisable(GL_DEPTH_TEST);					
        
        // should probably just set the scene projection every frame
        glMatrixMode( GL_PROJECTION );
        glPushMatrix();
        glLoadIdentity();
        
        glMatrixMode( GL_MODELVIEW ); 
        glLoadIdentity(); 
        
        Shader::SetDisplayCopyShader( s_ColorTex );
        
        glBegin(GL_QUADS);
        glTexCoord2d(0.0f, 0.0f);
        glVertex2f(-1.0f, -1.0f);
        glTexCoord2d(1.0f, 0.0f);
        glVertex2f(1.0f, -1.0f);
        glTexCoord2d(1.0f, 1.0f);
        glVertex2f(1.0f, 1.0f);
        glTexCoord2d(0.0f, 1.0f);
        glVertex2f(-1.0f, 1.0f);
        glEnd();
        
        glMatrixMode( GL_PROJECTION );
        glPopMatrix();
        glEnable(GL_DEPTH_TEST);					
    }
 
//#define LEFT_ONLY
//#define RIGHT_ONLY
    
    void CopyToStereoDisplay()
    {        
        // should probably just set the scene projection every frame
        glMatrixMode( GL_PROJECTION );
        glPushMatrix();
        glLoadIdentity();
        
        glMatrixMode( GL_MODELVIEW ); 
        glLoadIdentity(); 

        glDisable(GL_DEPTH_TEST);	
        
        GLfloat depth_params[4];
        depth_params[0] = s_NearPlane*s_FarPlane;
        depth_params[1] = s_FarPlane;
        depth_params[2] = s_FarPlane - s_NearPlane;
        
#ifdef LINEAR_DEPTH
		// create linear depth texture
		SetLinearDepthRenderTarget();

        Shader::SetLinearDepthShader( s_DepthTex, depth_params );
        glBegin(GL_QUADS);

        glTexCoord2d(0.0f, 0.0f);
        glVertex2f(-1.0f, -1.0f);
        glTexCoord2d(1.0f, 0.0f);
        glVertex2f(1.0f, -1.0f);
        glTexCoord2d(1.0f, 1.0f);
        glVertex2f(1.0f, 1.0f);
        glTexCoord2d(0.0f, 1.0f);
        glVertex2f(-1.0f, 1.0f);
        glEnd();
#endif
		// now do reprojection
        glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, 0);
        glViewport(0, 0, s_Width, s_Height);

#if !defined(LEFT_ONLY) && !defined(RIGHT_ONLY)
        // render only using green channel
        glColorMask( GL_FALSE, GL_TRUE, GL_FALSE, GL_TRUE );
#endif 
        GLfloat S = 0.5f*s_Interocular/s_ScreenWidth;
        
        GLfloat stereo_params[4];

#if !defined(RIGHT_ONLY)
        stereo_params[0] = -S;
#ifdef LINEAR_DEPTH
        stereo_params[1] = S*s_Convergence/s_FarPlane;
#else
        stereo_params[1] = S*s_Convergence;
#endif
        stereo_params[2] = -0.5*S;
        stereo_params[3] = 1.5*S;
        
        Shader::SetDisplayStereoShader( s_ColorTex, s_DepthTex, stereo_params, depth_params );
        
        glBegin(GL_QUADS);
        glTexCoord2d(0.0f, 0.0f);
        glVertex2f(-1.0f, -1.0f);
        glTexCoord2d(1.0f, 0.0f);
        glVertex2f(1.0f, -1.0f);
        glTexCoord2d(1.0f, 1.0f);
        glVertex2f(1.0f, 1.0f);
        glTexCoord2d(0.0f, 1.0f);
        glVertex2f(-1.0f, 1.0f);
        glEnd();
#endif

#if !defined(LEFT_ONLY) && !defined(RIGHT_ONLY)
        // render only using red and blue channels
        glColorMask( GL_TRUE, GL_FALSE, GL_TRUE, GL_TRUE );
#endif
        
#if !defined(LEFT_ONLY)
        stereo_params[0] = S;
#ifdef LINEAR_DEPTH
        stereo_params[1] = -S*s_Convergence/s_FarPlane;
#else
        stereo_params[1] = -S*s_Convergence;
#endif
        stereo_params[2] = 0.5f*S;
        stereo_params[3] = -1.5f*S;
        
        Shader::SetDisplayStereoShader( s_ColorTex, s_DepthTex, stereo_params, depth_params );
   
        glBegin(GL_QUADS);
        glTexCoord2d(0.0f, 0.0f);
        glVertex2f(-1.0f, -1.0f);
        glTexCoord2d(1.0f, 0.0f);
        glVertex2f(1.0f, -1.0f);
        glTexCoord2d(1.0f, 1.0f);
        glVertex2f(1.0f, 1.0f);
        glTexCoord2d(0.0f, 1.0f);
        glVertex2f(-1.0f, 1.0f);
        glEnd();
#endif
        
        glMatrixMode( GL_PROJECTION );
        glPopMatrix();
        glEnable(GL_DEPTH_TEST);					
        glColorMask( GL_TRUE, GL_TRUE, GL_TRUE, GL_TRUE );
    }

    void Activate( bool active )
    {
        s_Active = active;
    }
    
    void Resize( int width, int height )
    {
        // prevent divide by zero
        if (height == 0)                                    
        {
            height = 1;                                 
        }
        
        // set up current viewport
        glViewport(0, 0, width, height);                       
        
        // set default modelview matrix
        glMatrixMode(GL_MODELVIEW);                         
        glLoadIdentity();                                   
        
        s_Width = width;
        s_Height = height;
    }
    
    void SetProjection( float interocular, float convergence, float screenWidth, float eye )
    {
        GLfloat perspective[16];
        GLfloat tanFOV = tanf( s_FOV*3.1415926f/180.f*0.5f );
        GLfloat d = 1.0f/tanFOV;
        GLfloat aspect = (float)s_Width/(float)s_Height;
        GLfloat nearZ = s_NearPlane;
        GLfloat farZ = s_FarPlane;
		GLfloat recip = 1.0f/(nearZ-farZ);
        
        GLfloat S = interocular/screenWidth;
        GLfloat T = S*convergence*tanFOV;
        
		perspective[0] = d;
        perspective[1] = 0.0f;
        perspective[2] = 0.0f;
        perspective[3] = 0.0f;
        
        perspective[4] = 0.0f;
        perspective[5] = d*aspect;
        perspective[6] = 0.0f;
        perspective[7] = 0.0f;
        
        perspective[8] = -eye*S;
        perspective[9] = 0.0f;
        perspective[10] = (nearZ+farZ)*recip;
		perspective[11] = -1.0f;
        
        perspective[12] = -eye*d*T;
        perspective[13] = 0.0f;
        perspective[14] = 2.0f*nearZ*farZ*recip;
		perspective[15] = 0.0f;
        
        glMatrixMode(GL_PROJECTION); 
        glLoadMatrixf(perspective);
    }
    
	void HandleInput( int interval )
	{
        if (Input::KeyPressed('t'))
        {
            s_UseReprojection = !s_UseReprojection;
			if ( s_UseReprojection )
			{
				glutSetWindowTitle("Stereo: Reprojection");
			}
			else
			{
				glutSetWindowTitle("Stereo: Standard");
			}
        }

		float dt = interval*0.001f;
		float forwardx = sinf(M_PI/180.f*s_Yaw);
		float forwardy = cosf(M_PI/180.f*s_Yaw);
		if (Input::KeyDown('w'))
		{
			s_CameraX += dt*forwardx;
			s_CameraY += dt*forwardy;
		}
		if (Input::KeyDown('s'))
		{
			s_CameraX -= dt*forwardx;
			s_CameraY -= dt*forwardy;
		}
        if (Input::KeyDown('a'))
        {
            s_Yaw -= 30.f*dt;
        }
        if (Input::KeyDown('d'))
        {
            s_Yaw += 30.f*dt;
        }
       
	}

    void DisplayScene( int interval )
    {
        if (!s_Active)
        {
            return;
        }
        
		HandleInput( interval );

        SetBaseRenderTarget();
        
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT); 
        
        glMatrixMode( GL_MODELVIEW );
        glLoadIdentity();
        
		glRotatef( s_Pitch, 1.0f, 0.0f, 0.0f );
		glRotatef( s_Yaw, 0.0f, 0.0f, 1.0f );
		glTranslatef( -s_CameraX, -s_CameraY, -s_CameraZ );
                
        Shader::SetBasicLighting();
        
        if (s_UseReprojection)
        {
            // set standard projection matrix and render
            SetProjection( 0.0f, 0.0f, s_ScreenWidth, -1.0f );
            DrawObjects();
                        
            // flip
            CopyToStereoDisplay();

			// (for now) clear non-projected areas
			int bar_width = 0.5f*s_Interocular/s_ScreenWidth*s_Width;
			glClearColor( 0.0, 0.0, 0.0, 0.0 );
			glEnable(GL_SCISSOR_TEST);
			glScissor(0, 0, bar_width, s_Height);
			glClear(GL_COLOR_BUFFER_BIT);
			glScissor(s_Width - bar_width, 0, bar_width, s_Height);
			glClear(GL_COLOR_BUFFER_BIT);

			glDisable(GL_SCISSOR_TEST);
            glClearColor(0.2, 0.2, 0.2, 0.0); 
        }
        else
        {
            // render only using green channel
            glColorMask( GL_FALSE, GL_TRUE, GL_FALSE, GL_TRUE );

            // set left eye projection matrix and render
            SetProjection( s_Interocular, s_Convergence, s_ScreenWidth, -1.0f );
            DrawObjects();
            
            // clear only depth
            glClear(GL_DEPTH_BUFFER_BIT); 
            
            // render only using red & blue channels
            glColorMask( GL_TRUE, GL_FALSE, GL_TRUE, GL_TRUE );
            
            // set right eye projection matrix and render
            SetProjection( s_Interocular, s_Convergence, s_ScreenWidth, 1.0f );
            DrawObjects();
            
            // flip
            glColorMask( GL_TRUE, GL_TRUE, GL_TRUE, GL_TRUE );
            CopyToDisplay();
        }
    }
    
    void DrawObjects()
    {
        glMatrixMode( GL_MODELVIEW ); 
        
        // Yes, it uses immediate mode instead of vertex buffers. So sue me.
        
		// big sphere
        glPushMatrix();
        glTranslatef( 1.0, 1.0, 1.0f );
        glColor3f( 0.5f, 0.5f, 0.5f );
        glutSolidSphere( 2.0, 32.0, 32.0 );
        glPopMatrix();
        
        // little sphere
        glPushMatrix();
        glColor4f( 0.5f, 0.5f, 0.5f, 0.5f );
        glTranslatef( -4.0, 4.0, 1.0f );
        glutSolidSphere( 1.0, 32.0, 32.0 );
        glPopMatrix();
        
        // box
        glPushMatrix();
        glColor3f( 0.5f, 0.5f, 0.5f );
        glTranslatef( -4.0, -4.0, 1.0f );
        glutSolidCube( 2.0 );
        glPopMatrix();
        
        // chessboard
        glBegin(GL_QUADS);
        glNormal3f(0.0f, 0.0f, 1.0f);
        for ( int i = -12; i <= 12; i += 3 )
        {
            for ( int j = -12; j <= 12; j += 3 )
            {
                if ( ( i & 0x1 ) == (j & 0x1 ))
                    glColor3f( 0.25f, 0.25f, 0.25f );
                else
                    glColor3f( 0.75f, 0.75f, 0.75f );
                
                glVertex3f(0.0f + (float)i, 0.0f + (float)j, 0.0f);
                glVertex3f(3.0f + (float)i, 0.0f + (float)j, 0.0f);
                glVertex3f(3.0f + (float)i, 3.0f + (float)j, 0.0f);
                glVertex3f(0.0f + (float)i, 3.0f + (float)j, 0.0f);
            }
        }
        glEnd();

    }
    
};