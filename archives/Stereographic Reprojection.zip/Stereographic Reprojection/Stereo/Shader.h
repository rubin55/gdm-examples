//
//  Shader.h
//  Stereo
//
//  Created by James Van Verth on 4/12/12.
//  Copyright (c) 2012 James M. Van Verth. All rights reserved.
//

#ifndef Stereo_Shader_h
#define Stereo_Shader_h

#ifdef PLATFORM_OSX
#include <OpenGL/OpenGL.h>
#else
#include <GL/glew.h>
#endif

namespace Shader
{
    typedef GLuint VertexShader;
    typedef GLuint FragmentShader;
    typedef GLuint Program;
 
    void Init();
    
    void SetBasicLighting();
    void SetDisplayCopyShader( GLuint textureID );
//    void SetDisplayStereoShader( GLuint colortextureID, GLuint depthtextureID, GLfloat* stereoParams );
    void SetDisplayStereoShader( GLuint colortextureID, GLuint depthtextureID, GLfloat* stereoParams, GLfloat* depthParams );
    void SetLinearDepthShader( GLuint depthtextureID, GLfloat* depthParams );
}

#endif
