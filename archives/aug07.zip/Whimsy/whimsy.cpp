﻿////////////////////////////////////////////////////////////////////////////
// 
// Using /clr required the followng chnges
// - disable exceptions 
// - no MT, use MTD instead
/// no /arch:SSE2
//
// Copyright (c) 2006 Mick West
// http://mickwest.com/
// Permission is hereby granted, free of charge, to any person obtaining a 
// copy of this software and associated documentation files (the "Software"),
// to deal in the Software without restriction, including without limitation
// the rights to use, copy, modify, merge, publish, distribute, sublicense,
// and/or sell copies of the Software, and to permit persons to whom the
// Software is furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included
// in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
// OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
// IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
// ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
// DEALINGS IN THE SOFTWARE.
//
// HOW TO COMPILE
//
// You should have Visual studio files blob.sln and blob.vcproj which will allow
// you to compile under visual studio 2005.
// if not, then the following info should be enough to get you compiling.
//
// The entire project consists of four source files:
//   scatter.cpp (this file)
//   vector2.h  (the 2D vector library)
//
// This code will compile under Visual Studio 2005, including the express 
// edition, available free at:
// http://msdn.microsoft.com/vstudio/express/ 
//
// You also need the windows SDK
// http://www.microsoft.com/downloads/details.aspx?FamilyId=A55B6B43-E24F-4EA3-A93E-40C0EC4F68E5&displaylang=en
//
// And the DirectX SDK
// http://msdn.microsoft.com/directx/sdk/
//
// Link with the following libraries:
// d3dxof.lib dxguid.lib d3dx9.lib d3d9.lib dxerr9.lib dinput8.lib winmm.lib user32.lib
//  
// You will also need to set the correct include and lib path for the Windows SDK and DirectX SDK.
// these vary by install, but for me were:
//
// C:\Program Files\Microsoft DirectX SDK (December 2005)\Include
// C:\Program Files\Microsoft Platform SDK\Include
// C:\Program Files\Microsoft DirectX SDK (December 2005)\Lib\x86
// C:\Program Files\Microsoft Platform SDK\Lib
//

  ///////////////////////////////////////////////////
  // Scatter Article specific code start around line 3564	 //
  ///////////////////////////////////////////////////

// Since this is based on my ongoing article code testbed
// it's rather messy.  Just ignore the other code (particles and event tracking)
//

#define	_SECURE_SCL 0

//#define	FIGURES  // for screenshot figures

#if 1

#define	MANUAL_OPT					// some manual optimizations
#define	PRETTY_UP					// Much nicer looking graphics and effect, a bit slower
//#define	NBODY						// all particles affect each other, reduce number of particles.
//#define	USE_WORKER_THREADS				// define either of these to enable threading
//#define USE_FORKED_THREADS
//#define SET_AFFINITY
#define PROCESS_CHUNKS
#define	MAX_THREAD	1					// any number you like, but typically 1,2,4 or 8 will work best
//#define	USE_DUMMY_PHYSICS			// compile in a full tilt thread
//#define	USE_FORK_MARKING			// fork/join a quick thread at the end of the update as a marker
//#define	CRITICAL_SECTION_RND		// Not strictly necessary, so off for speed
//#define FAST_RND

#endif

typedef	unsigned int uint32;

float g_friction = 1.0f;

#ifdef NBODY
const int	NUM_PARTICLES = 100;		// we have NxN interactions, so reduce number of particles.
#else
const int	NUM_PARTICLES = 1; //80000;  // 80000 is good on a 3.2ghz DC/HT.  
									 // But you can go up to 240000, which is quite impressive
#endif

// Checking optimizations:
//
// FP Model:
// Precise:				0.0214  << DEFAULT BASELINE
// Strict:				0.0253
// Fast:				0.0182  *** (15% faster)
//
// Exceptions -			No diff                          
//
// SIMD 2				0.0208  ***
//
// Opt Minimize size	0.0250
// Opt Full				unch

// Intrinsics			unch
//
// link time code gen	0.0206  ***
//
// RTTI off				unch
//
// Calling conv fastcall	unch

// All three Fast FP, SIMD2, Link time code
// =   0.0095
// with four threads:	0.0036, 0.0138


#pragma warning(disable: 4995)          // don't warn about deprecated functions
#define _CRT_SECURE_NO_DEPRECATE		// ditto

// Hooks into the simple sample
void MX_Init();
void MX_Render();
void MX_Logic(float time);
void MX_Cleanup();


void    debug_log( const char* text, ...);

const int   g_viewport_width = 1024;
const int   g_viewport_height = 768;

bool    g_resize = false;

// System and DirectX includes.
#include <d3d9.h>
#include <d3dx9.h>
#include <strsafe.h>
#include <math.h>
#define DIRECTINPUT_VERSION 0x0800
#include <dinput.h>

// local includes
#include "vector2.h"
//#include "ICol2d.h"
#include <vector>
#include <string>
#include <map>
#include "assert.h"


#include "binary.h"

void	WhimsyParse();
void	WhimsyRender();
void	WhimsyInit();


using namespace std;

bool	dragging=0;
int		mouse_x=0;
int		mouse_y=0;

int	key_left =0;
int key_right = 0;
int key_up = 0;
int key_down = 0;
int key_w=0;
int key_a=0;
int key_s=0;
int key_d=0;
int key_space=0;

CRITICAL_SECTION	debug_CS;


FILE *p_svg = NULL;
bool	doing_SVG = 0;
double	SVG_scale_factor = 1.0f;

void	SVG_Scale(float x)
{
	 SVG_scale_factor = x;
}

void SVG_Start(const char* p_name)
{
	p_svg = fopen(p_name,"wb");
	fprintf(p_svg,"<?xml version=\"1.0\" encoding=\"utf-8\"?>\n");
	fprintf(p_svg,"<!-- Generator: Adobe Illustrator 12.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 51448)  -->\n");
	fprintf(p_svg,"<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.1//EN\" \"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd\" [\n");
	fprintf(p_svg,"	<!ENTITY ns_svg \"http://www.w3.org/2000/svg\">\n");
	fprintf(p_svg,"	<!ENTITY ns_xlink \"http://www.w3.org/1999/xlink\">\n");
	fprintf(p_svg,"]>\n");
	fprintf(p_svg,"<svg  version=\"1.1\" id=\"Layer_1\" xmlns=\"&ns_svg;\" xmlns:xlink=\"&ns_xlink;\" width=\"315.19\" height=\"288\" viewBox=\"0 0 315.19 288\"\n");
	fprintf(p_svg,"	 overflow=\"visible\" enable-background=\"new 0 0 315.19 288\" xml:space=\"preserve\">\n");
	doing_SVG = 1;
}

void SVG_End()
{
	fprintf(p_svg,"</svg>\n");
	fclose(p_svg);
	doing_SVG = 0;

}

void SVG_Line(unsigned int stroke, float width, float x1, float y1, float x2, float y2)
{
	if (doing_SVG)
	{
		fprintf(p_svg,"<line fill=\"none\" stroke=\"#%06X\" stroke-width=\"%f\" x1=\"%f\" y1=\"%f\" x2=\"%f\" y2=\"%f\"/>\n",
			stroke, width, x1*SVG_scale_factor,y1*SVG_scale_factor,x2*SVG_scale_factor,y2*SVG_scale_factor);
	}
}

// head w and l are as fraction of the line length
void SVG_Arrow(unsigned int stroke, float width, float x1, float y1, float x2, float y2, float head_l, float head_w)
{
	if (doing_SVG)
	{
		SVG_Line(stroke,width,x1,y1,x2,y2);
		Vector2 end = Vector2(x2,y2);
		Vector2 line = Vector2(x2,y2) - Vector2(x1,y1);
		Vector2 normal = line.Normal();
		Vector2 side = Vector2(normal.y,-normal.x);
		float len = line.Length();
		Vector2 base = end - head_l * normal * len;
		Vector2 left = base + head_w * side * len; 
		Vector2 right = base - head_w * side * len; 
		SVG_Line(stroke,width,left.x,left.y,end.x,end.y);
		SVG_Line(stroke,width,right.x,right.y,end.x,end.y);
	}
}


void SVG_Dot(unsigned int stroke, float cx, float cy, float r)
{
	if (doing_SVG)
	{
		fprintf(p_svg,"<circle fill=\"#%06X\" stroke=\"#%06X\" cx=\"%f\" cy=\"%f\" r=\"%f\"/>\n", stroke, stroke, cx*SVG_scale_factor,cy*SVG_scale_factor,r*SVG_scale_factor);
	}
}

void SVG_Test()
{
	SVG_Start("C:\\Mick\\Docs\\GamesIndustry\\GameDeveloperArticles\\Fluid and Gas  Dynamics\\svg_test.svg");
	SVG_Line(0x604323,3,20,20,50,80);
	SVG_End();
}



#ifdef		CRITICAL_SECTION_RND
CRITICAL_SECTION	rnd_CS;
#endif

////
// since rand is weak, I implement my own random numbers

int rnd_a = 12345678;
int rnd_b = 12393455;
int rnd_c = 45432838;	   

void	randomize(int x)
{
	rnd_a = 12345678;
	rnd_b = 12393455;
	rnd_c = x;	   
}

unsigned int	rnd()				   
{

#ifdef		CRITICAL_SECTION_RND
	EnterCriticalSection(&rnd_CS);
#endif
#ifdef	FAST_RND
	static int rnd_a = 12345678;
	static int rnd_b = 12393455;

	rnd_a = rnd_a ^ 0x10010100;
	rnd_a = (rnd_a << 1) | ((rnd_a>> 31)&1);
	rnd_a ^= rnd_b;
	rnd_b = rnd_b * 255 + 32769;	
	unsigned int return_value = rnd_a;
#else


	rnd_a = rnd_a ^ 0x10010100;
	rnd_a = (rnd_a << 1) | ((rnd_a>> 31)&1);
	rnd_a ^= rnd_b ^ rnd_c;
	rnd_b = rnd_b * 255 + 32769;
	rnd_c = rnd_a + rnd_b + rnd_c + 1;
	unsigned int return_value = rnd_a;
#endif
#ifdef		CRITICAL_SECTION_RND
	LeaveCriticalSection(&rnd_CS);
#endif
	return return_value;
}

// return random number in the range 0 .. a-1 
int rnd (unsigned int a)
{
	return rnd() % a;
}

// return random number in the range 0 .. f
float rndf(float f = 1.0f)
{
	return f*(float)rnd()/4294967296.0f;
}

float rndf(float f1, float f2)
{
	return f1 + (f2-f1)*(float)rnd()/4294967296.0f;
}

float randf(float f1, float f2)
{
	return f1 + (f2-f1)*(float)rand()/RAND_MAX;
}


//-----------------------------------------------------------------------------
// Function-prototypes for directinput handlers
//-----------------------------------------------------------------------------
BOOL CALLBACK    EnumObjectsCallback( const DIDEVICEOBJECTINSTANCE* pdidoi, VOID* pContext );
BOOL CALLBACK    EnumJoysticksCallback( const DIDEVICEINSTANCE* pdidInstance, VOID* pContext );
HRESULT InitDirectInput( HWND hDlg );
VOID    FreeDirectInput();
HRESULT UpdateInputState( HWND hDlg );


LRESULT WINAPI MsgProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam );


//-----------------------------------------------------------------------------
// Global variables
//-----------------------------------------------------------------------------
LPDIRECT3D9             g_pD3D       = NULL; // Used to create the D3DDevice
LPDIRECT3DDEVICE9       g_pd3dDevice = NULL; // Our rendering device
LPDIRECT3DVERTEXBUFFER9 g_pVB        = NULL; // Buffer to hold Vertices
LPDIRECT3DVERTEXBUFFER9 g_pVB2       = NULL; // Another Buffer to hold Vertices for lines
ID3DXFont*              g_pFont      = NULL;

RECT                    window_rect;
int                     g_window_width,g_window_height;

inline float  scale_x(float x) {return x * (float)g_window_width / (float) g_viewport_width;}
inline float  scale_y(float y) {return y * (float)g_window_height / (float) g_viewport_height;}

struct CUSTOMVERTEX
{
    FLOAT x, y, z, rhw; // The transformed position for the vertex
    DWORD color;        // The vertex color
};

// Our custom FVF, which describes our custom vertex structure
#define D3DFVF_CUSTOMVERTEX (D3DFVF_XYZRHW|D3DFVF_DIFFUSE)

static 	LARGE_INTEGER Freq;
static 	LARGE_INTEGER BaseTime;
static 	LARGE_INTEGER PausedTime;
static 	LARGE_INTEGER UnPausedTime;


void Timer_Reset()
{
	QueryPerformanceCounter(&BaseTime);
}

void Timer_Init()
{
	QueryPerformanceFrequency(&Freq);
	Timer_Reset();
}

float Timer_Seconds()
{
	static 	LARGE_INTEGER Time;
	QueryPerformanceCounter(&Time);
	return (float)(Time.QuadPart-BaseTime.QuadPart)/(float)(Freq.QuadPart);
}

void Timer_Pause()
{
	QueryPerformanceCounter(&PausedTime);
}
void Timer_Resume()
{
	QueryPerformanceCounter(&UnPausedTime);
    // adjust the base time by the time we have been paused 
    BaseTime.QuadPart += (UnPausedTime.QuadPart - PausedTime.QuadPart); 
}

// Buffers for lines and triangles 
CUSTOMVERTEX *g_pTriVerts;
const int MAX_TRIS=500000;
int	g_nTris = 0;

CUSTOMVERTEX *g_pLineVerts;
const int MAX_LINES=5000000;
int	g_nLines = 0;

//-----------------------------------------------------------------------------
// Name: InitD3D()
// Desc: Initializes Direct3D
//-----------------------------------------------------------------------------
HRESULT InitD3D( HWND hWnd )
{
    if ( NULL == g_pD3D)
    {
        // Create the D3D object.
        if( NULL == ( g_pD3D = Direct3DCreate9( D3D_SDK_VERSION ) ) )
            return E_FAIL;
    }

    // We might be re-creating the font and device, so release them if so.
    if ( g_pFont != NULL )
    {
      g_pFont->Release();     
      g_pFont = NULL;
    }
    if( g_pd3dDevice != NULL ) 
    {
        g_pd3dDevice->Release();
        g_pd3dDevice = NULL;
    }
    
    // Set up the structure used to create the D3DDevice
    D3DPRESENT_PARAMETERS d3dpp;
    ZeroMemory( &d3dpp, sizeof(d3dpp) );
	
    d3dpp.BackBufferWidth = g_window_width;
	d3dpp.BackBufferHeight = g_window_height;
    
	d3dpp.Windowed = TRUE;
    d3dpp.SwapEffect = D3DSWAPEFFECT_FLIP;
    d3dpp.BackBufferFormat = D3DFMT_UNKNOWN;

    d3dpp.MultiSampleType = D3DMULTISAMPLE_NONE;
    d3dpp.MultiSampleQuality = D3DMULTISAMPLE_NONE;
    d3dpp.PresentationInterval = D3DPRESENT_INTERVAL_IMMEDIATE; //D3DPRESENT_INTERVAL_ONE;
    //d3dpp.PresentationInterval = D3DPRESENT_INTERVAL_ONE;

    // Create the D3DDevice
    if( FAILED( g_pD3D->CreateDevice( D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, hWnd,
                                      D3DCREATE_SOFTWARE_VERTEXPROCESSING,
                                      &d3dpp, &g_pd3dDevice ) ) )
    {
        return E_FAIL;
    }
    
               
    if( FAILED( D3DXCreateFont( g_pd3dDevice, 15, 0, FW_NORMAL, 1, FALSE, DEFAULT_CHARSET, 
                         OUT_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, 
                         (LPCSTR)"Arial", &g_pFont ) ) )
    {
        return E_FAIL;
    }


    return S_OK;
}

////////////////////////////////////////////////////////////////////////////////////////
// DirectX Joystick handling starts here:

#define SAFE_DELETE(p)  { if(p) { delete (p);     (p)=NULL; } }
#define SAFE_RELEASE(p) { if(p) { (p)->Release(); (p)=NULL; } }

LPDIRECTINPUT8       g_pDI              = NULL;         
LPDIRECTINPUTDEVICE8 g_pJoystick        = NULL;     

#define JOY_BUFFERSIZE  64
DIDEVICEOBJECTDATA   g_inputbuffer[JOY_BUFFERSIZE];        // Input buffer for joystick events


DIJOYSTATE2 js;           // DInput Joystick state 


//-----------------------------------------------------------------------------
// Name: InitDirectInput()
// Desc: Initialize the DirectInput variables.
//-----------------------------------------------------------------------------
HRESULT InitDirectInput( HWND hDlg )
{
    HRESULT hr;

	int i;


	for (i=0;i<256;i++)
		js.rgbButtons[i] = 0;
	js.rgdwPOV[0] = -1;


    // Register with the DirectInput subsystem and get a pointer
    // to a IDirectInput interface we can use.
    // Create a DInput object
    if( FAILED( hr = DirectInput8Create( GetModuleHandle(NULL), DIRECTINPUT_VERSION, 
                                         IID_IDirectInput8, (VOID**)&g_pDI, NULL ) ) )
        return hr;

    // Look for a simple Joystick we can use for this sample program.
    if( FAILED( hr = g_pDI->EnumDevices( DI8DEVCLASS_GAMECTRL, 
                                         EnumJoysticksCallback,
                                         NULL, DIEDFL_ATTACHEDONLY ) ) )
        return hr;                                            

    // Make sure we got a Joystick
    if( NULL == g_pJoystick )
    {
      //  MessageBox( NULL, TEXT("Joystick not found."),  
      //              TEXT("DirectInput Sample"), 
      //              MB_ICONERROR | MB_OK );
      //  EndDialog( hDlg, 0 );
		// Not too worried about this for this application      
		return S_OK;
    }

    // Set the data format to "simple Joystick" - a predefined data format 
    //
    // A data format specifies which controls on a device we are interested in,
    // and how they should be reported. This tells DInput that we will be
    // passing a DIJOYSTATE2 structure to IDirectInputDevice::GetDeviceState().
    if( FAILED( hr = g_pJoystick->SetDataFormat( &c_dfDIJoystick2 ) ) )
        return hr;

    // Set the cooperative level to let DInput know how this device should
    // interact with the system and with other DInput applications.
    if( FAILED( hr = g_pJoystick->SetCooperativeLevel( hDlg, DISCL_EXCLUSIVE | 
                                                             DISCL_FOREGROUND ) ) )
        return hr;

    // Enumerate the Joystick objects. The callback function enabled user
    // interface elements for objects that are found, and sets the min/max
    // values property for discovered axes.
    if( FAILED( hr = g_pJoystick->EnumObjects( EnumObjectsCallback, 
                                                (VOID*)hDlg, DIDFT_ALL ) ) )
        return hr;

    return S_OK;
}

//-----------------------------------------------------------------------------
// Name: EnumJoysticksCallback()
// Desc: Called once for each enumerated Joystick. If we find one, create a
//       device interface on it so we can play with it.
//-----------------------------------------------------------------------------
BOOL CALLBACK EnumJoysticksCallback( const DIDEVICEINSTANCE* pdidInstance,
                                     VOID* pContext )
{
    HRESULT hr;

    // Obtain an interface to the enumerated Joystick.
    hr = g_pDI->CreateDevice( pdidInstance->guidInstance, &g_pJoystick, NULL );

    DIDEVICEINSTANCE    device_info;

    g_pJoystick->GetDeviceInfo(&device_info);

    // If it failed, then we can't use this Joystick. (Maybe the user unplugged
    // it while we were in the middle of enumerating it.)
    if( FAILED(hr) ) 
        return DIENUM_CONTINUE;

    // Stop enumeration. Note: we're just taking the first Joystick we get. You
    // could store all the enumerated Joysticks and let the user pick.
    return DIENUM_STOP;
    
    // Continue Enumeration, let's pick the best joystick
//    return DIENUM_CONTINUE; 
      
}

//-----------------------------------------------------------------------------
// Name: EnumObjectsCallback()
// Desc: Callback function for enumerating objects (axes, buttons, POVs) on a 
//       Joystick. This function enables user interface elements for objects
//       that are found to exist, and scales axes min/max values.
//-----------------------------------------------------------------------------
BOOL CALLBACK EnumObjectsCallback( const DIDEVICEOBJECTINSTANCE* pdidoi,
                                   VOID* pContext )
{
    HWND hDlg = (HWND)pContext;

    static int nSliderCount = 0;  // Number of returned slider controls
    static int nPOVCount = 0;     // Number of returned POV controls

    // For axes that are returned, set the DIPROP_RANGE property for the
    // enumerated axis in order to scale min/max values.
    if( pdidoi->dwType & DIDFT_AXIS )
    {
        DIPROPRANGE diprg; 
        diprg.diph.dwSize       = sizeof(DIPROPRANGE); 
        diprg.diph.dwHeaderSize = sizeof(DIPROPHEADER); 
        diprg.diph.dwHow        = DIPH_BYID; 
        diprg.diph.dwObj        = pdidoi->dwType; // Specify the enumerated axis
        diprg.lMin              = -1000; 
        diprg.lMax              = +1000; 
    
        // Set the range for the axis
        if( FAILED( g_pJoystick->SetProperty( DIPROP_RANGE, &diprg.diph ) ) ) 
            return DIENUM_STOP;


        DIPROPDWORD  dipdw; 
        dipdw.diph.dwSize = sizeof(DIPROPDWORD); 
        dipdw.diph.dwHeaderSize = sizeof(DIPROPHEADER); 
        dipdw.diph.dwObj = 0; 
        dipdw.diph.dwHow = DIPH_DEVICE; 
        dipdw.dwData = JOY_BUFFERSIZE; 

        // Set the size of the data buffer
        if( FAILED( g_pJoystick->SetProperty(DIPROP_BUFFERSIZE, &dipdw.diph) ) )
            return DIENUM_STOP;
         
    }
    
    return DIENUM_CONTINUE;

}



//-----------------------------------------------------------------------------
// Name: FreeDirectInput()
// Desc: Initialize the DirectInput variables.
//-----------------------------------------------------------------------------
VOID FreeDirectInput()
{
    // Unacquire the device one last time just in case 
    // the app tried to exit while the device is still acquired.
    if( g_pJoystick ) 
        g_pJoystick->Unacquire();
    
    // Release any DirectInput objects.
    SAFE_RELEASE( g_pJoystick );
    SAFE_RELEASE( g_pDI );
}


///////////////////////////////////////////////////////////////////////////
// ReadControllerState is an interface function between my code
// and the DirectInput framework
// takes a 256 entry byte array
// returns with the first 12 entries being the gamepad buttons
// in the order X,A,B,Y,L1,R1,L2,R2,SELECT,START,L3,R3
// and entries 128,129,130,132 being U,D,L,R
void ReadControllerState(unsigned char *buttons)
{
    // copy over the first 128 buttons
    for (int i=0;i<128;i++)
    buttons[i] = js.rgbButtons[i];
    // and create remaining buttons from the D-Pad direction
    
    // POV in directX correspond to the DPad    
    // -1 = nothing
    // anything else = angle in degrees, time 100, so, 9000 for right. 22500 for down left

    // This is a rather odd mapping, but it works    
    switch (js.rgdwPOV[0])
    {
        case -1:
            buttons[128] = 0;
            buttons[129] = 0;
            buttons[130] = 0;
            buttons[131] = 0;
            break;
        case 0:
            buttons[128] = 1;
            buttons[129] = 0;
            buttons[130] = 0;
            buttons[131] = 0;
            break;
        case 4500:
            buttons[128] = 1;
            buttons[129] = 0;
            buttons[130] = 0;
            buttons[131] = 1;
            break;
        case 9000:
            buttons[128] = 0;
            buttons[129] = 0;
            buttons[130] = 0;
            buttons[131] = 1;
            break;
        case 13500:
            buttons[128] = 0;
            buttons[129] = 1;
            buttons[130] = 0;
            buttons[131] = 1;
            break;
        case 18000:
            buttons[128] = 0;
            buttons[129] = 1;
            buttons[130] = 0;
            buttons[131] = 0;
            break;
        case 22500:
            buttons[128] = 0;
            buttons[129] = 1;
            buttons[130] = 1;
            buttons[131] = 0;
            break;
        case 27000:
            buttons[128] = 0;
            buttons[129] = 0;
            buttons[130] = 1;
            buttons[131] = 0;
            break;
        case 31500:
            buttons[128] = 1;
            buttons[129] = 0;
            buttons[130] = 1;
            buttons[131] = 0;
            break;
    }
}


// End of DirectX joystick handling code
/////////////////////////////////////////////////////////////////////////////////

const int max_strings = 200;
const int max_string_length = 255;
struct SDrawText {
    float x,y;
    char text[max_string_length+1];
    DWORD color;
};

int num_draw_strings;

SDrawText   texts_to_draw[max_strings];
void    DrawString(float x, float y, const char *p_text, DWORD color = 0xff000000)
{
    if (num_draw_strings == max_strings)
        return;
    texts_to_draw[num_draw_strings].x = scale_x(x);    
    texts_to_draw[num_draw_strings].y = scale_y(y);    
    texts_to_draw[num_draw_strings].color = color;
    strncpy(texts_to_draw[num_draw_strings].text,p_text,max_string_length);    
    texts_to_draw[num_draw_strings].text[max_string_length]='\0'; // NULL terminator for iff p_text is >255 chars
    num_draw_strings++;
    
}


//-----------------------------------------------------------------------------
// Name: InitVB()
// Desc: Creates a vertex buffer and fills it with our Vertices. The vertex
//       buffer is basically just a chuck of memory that holds Vertices. After
//       creating it, we must Lock()/Unlock() it to fill it. For indices, D3D
//       also uses index buffers. The special thing about vertex and index
//       buffers is that they can be created in device memory, allowing some
//       cards to process them in hardware, resulting in a dramatic
//       performance gain.
//-----------------------------------------------------------------------------
HRESULT InitVB()
{

	g_pTriVerts = new CUSTOMVERTEX[MAX_TRIS * 3];
	g_nTris = 0;
	g_pLineVerts = new CUSTOMVERTEX[MAX_LINES * 2];
	g_nLines = 0;

    // Create the vertex buffer.  We also
    // specify the FVF, so the vertex buffer knows what data it contains.
    if( FAILED( g_pd3dDevice->CreateVertexBuffer( MAX_TRIS*sizeof(CUSTOMVERTEX),
                                                  0, D3DFVF_CUSTOMVERTEX,
                                                  D3DPOOL_DEFAULT, &g_pVB, NULL ) ) )
    {
        return E_FAIL;
    }
    if( FAILED( g_pd3dDevice->CreateVertexBuffer( MAX_LINES*sizeof(CUSTOMVERTEX),
                                                  0, D3DFVF_CUSTOMVERTEX,
                                                  D3DPOOL_DEFAULT, &g_pVB2, NULL ) ) )
    {
        return E_FAIL;
    }


    return S_OK;
}


HRESULT FillVB()
{
	// Now we fill the vertex buffer. To do this, we need to Lock() the VB to
    // gain access to the Vertices. This mechanism is required becuase vertex
    // buffers may be in device memory.
    VOID* pVertices;
    if( FAILED( g_pVB->Lock( 0, g_nTris * sizeof(CUSTOMVERTEX), (void**)&pVertices, 0 ) ) )
        return E_FAIL;
    memcpy( pVertices, g_pTriVerts, g_nTris * sizeof(CUSTOMVERTEX) );
    g_pVB->Unlock();

    // Repeat for lines    
    if( FAILED( g_pVB2->Lock( 0, g_nLines * sizeof(CUSTOMVERTEX), (void**)&pVertices, 0 ) ) )
        return E_FAIL;
    memcpy( pVertices, g_pLineVerts, g_nLines * sizeof(CUSTOMVERTEX) );
    g_pVB->Unlock();
	
    return S_OK;
}

//-----------------------------------------------------------------------------
// Name: Cleanup()
// Desc: Releases all previously initialized objects
//-----------------------------------------------------------------------------
VOID Cleanup()
{
    if( g_pVB != NULL )        
        g_pVB->Release();
    if( g_pVB2 != NULL )        
        g_pVB2->Release();
        
    if ( g_pFont != NULL )
      g_pFont->Release();     

    if( g_pd3dDevice != NULL ) 
        g_pd3dDevice->Release();

    if( g_pD3D != NULL )       
        g_pD3D->Release();

	if (g_pTriVerts != NULL)
		delete g_pTriVerts;
	if (g_pLineVerts != NULL)
		delete g_pLineVerts;
        
}

//-----------------------------------------------------------------------------
// Name: Render()
// Desc: Draws the scene
//-----------------------------------------------------------------------------
VOID Render()
{
    // Clear the backbuffer to a neutral color
    //g_pd3dDevice->Clear( 0, NULL, D3DCLEAR_TARGET, D3DCOLOR_XRGB(180,180,200), 1.0f, 0 );
    //g_pd3dDevice->Clear( 0, NULL, D3DCLEAR_TARGET, D3DCOLOR_XRGB(0,0,0), 1.0f, 0 );
    g_pd3dDevice->Clear( 0, NULL, D3DCLEAR_TARGET, D3DCOLOR_XRGB(44,44,72), 1.0f, 0 );		// 44,44,72 is bg of lunar module
    //g_pd3dDevice->Clear( 0, NULL, D3DCLEAR_TARGET, D3DCOLOR_XRGB(255,255,255), 1.0f, 0 );

    // Begin the scene
    if( SUCCEEDED( g_pd3dDevice->BeginScene() ) )
    {

        MX_Render();
        
        // Refill the VB, allowing us to draw whatever
		FillVB();
		
		// Draw the triangles in the vertex buffer. This is broken into a few
        // steps. We are passing the Vertices down a "stream", so first we need
        // to specify the source of that stream, which is our vertex buffer. Then
        // we need to let D3D know what vertex shader to use. Full, custom vertex
        // shaders are an advanced topic, but in most cases the vertex shader is
        // just the FVF, so that D3D knows what type of Vertices we are dealing
        // with. Finally, we call DrawPrimitive() which does the actual rendering
        // of our geometry (in this case, just one triangle).
        g_pd3dDevice->SetStreamSource( 0, g_pVB, 0, sizeof(CUSTOMVERTEX) );
        g_pd3dDevice->SetFVF( D3DFVF_CUSTOMVERTEX );
        g_pd3dDevice->DrawPrimitive( D3DPT_TRIANGLELIST, 0, g_nTris/3 );

        // And the lines
        g_pd3dDevice->SetStreamSource( 0, g_pVB2, 0, sizeof(CUSTOMVERTEX) );
        g_pd3dDevice->SetFVF( D3DFVF_CUSTOMVERTEX );
        g_pd3dDevice->DrawPrimitive( D3DPT_LINELIST, 0, g_nLines/2 );

        RECT rc;
        for (int i=0;i<num_draw_strings;i++)
        {
            SetRect( &rc, (int)texts_to_draw[i].x, (int)texts_to_draw[i].y, 0, 0 );        
            g_pFont->DrawText(NULL, (LPCSTR)texts_to_draw[i].text, -1, &rc, DT_NOCLIP, texts_to_draw[i].color);
        }
        num_draw_strings = 0;

        // and reset
        g_nTris = 0;
        g_nLines = 0;

        // End the scene
        g_pd3dDevice->EndScene();
    }

	//Make sure we have waited for some sufficient time
	static float last_time = 0.0f;
	while (Timer_Seconds()<last_time+0.01666666f*1.3333f) // 45
	//while (Timer_Seconds()<last_time+0.01666666f*2.0f)  // 30
	//while (Timer_Seconds()<last_time+0.01666666f*1.0f)  // 30
		NULL;
	last_time = Timer_Seconds();

    // Present the backbuffer contents to the display
    g_pd3dDevice->Present( NULL, NULL, NULL, NULL );
}

////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////
// Windows application initialization and message handling
// Based on DirectX SDK example applications



//-----------------------------------------------------------------------------
// Name: WinMain()
// Desc: The application's entry point
//-----------------------------------------------------------------------------
INT WINAPI WinMain( HINSTANCE hInst, HINSTANCE, LPSTR, INT )
{
	// Need to init this CS first, as it's used in debug_log
	InitializeCriticalSection(&debug_CS);
    // Register the window class
    WNDCLASSEX wc = { sizeof(WNDCLASSEX), CS_CLASSDC, MsgProc, 0L, 0L,
                      GetModuleHandle(NULL), NULL, NULL, NULL, NULL,
                      "Whimsy", NULL };
    RegisterClassEx( &wc );

    debug_log("\n\n ------------ THE WHIMSY PROJECT ----------------\n\n",g_window_width,g_window_height);


    // Create the application's window
	HWND hWnd = CreateWindow( "Whimsy", "Mick West: Domain Specific Language",
                              WS_OVERLAPPEDWINDOW, 0, 0, 1000, 1000,
                              GetDesktopWindow(), NULL, wc.hInstance, NULL );
                              
	// Get the size of the renderable rectangle
	GetClientRect(hWnd,&window_rect);
    g_window_width = window_rect.right-window_rect.left;
	g_window_height = window_rect.bottom-window_rect.top;


    debug_log("ClientRect Window = %dx%d",g_window_width,g_window_height);
                              


    if( FAILED( InitDirectInput( hWnd ) ) )
    {
        MessageBox( NULL, TEXT("Error Initializing DirectInput"), 
                    TEXT("Button Disambiguation Example"), MB_ICONERROR | MB_OK );
    }

    if( SUCCEEDED( InitD3D( hWnd ) ) )
    {
        if( SUCCEEDED( InitVB() ) )
        {
            ShowWindow( hWnd, SW_SHOWDEFAULT );
            UpdateWindow( hWnd );

            MX_Init();

            // Enter the message loop
            MSG msg;
            ZeroMemory( &msg, sizeof(msg) );
            Timer_Init();
            while( msg.message!=WM_QUIT )
            {
                if( PeekMessage( &msg, NULL, 0U, 0U, PM_REMOVE ) )
                {
                    TranslateMessage( &msg );
                    DispatchMessage( &msg );
                }
                else
                {
					static float avg = 0.0f;
					static float fps = 0.0f;
                    float   start = Timer_Seconds();
                    UpdateInputState( hWnd );
                    MX_Logic(Timer_Seconds());
					char buf[100];
					sprintf(buf, "FPS = %4.2f AVG = %4.2f",fps,avg);
					DrawString(16,32,buf,0xff202020);
                    Render();
					float end = Timer_Seconds();
					fps = 1.0f / (end - start);

					static float fps_buff[256];
					static int fps_i = 0;
					fps_buff[fps_i++] = fps;
					if (fps_i == 256) fps_i = 0;
					for (int i=0;i<256;i++)
						(avg+=fps_buff[i]);
					avg /= 256.0f;

                    //while (Timer_Seconds() > start && Timer_Seconds() < start + 4.0f * 0.016666f)
                    {
                        // Waiting for a frame to elapse, so we go to 60 fps
                    }
                        
                }
            }            
            MX_Cleanup();
        }
    }

    UnregisterClass( "ButtonDisambiguation", wc.hInstance );
    return 0;
}

// end of Windows Stuff

// The following function uses the directX wrapper stuff directly

// triangle with clockwise ordered points
void DrawTri(float x0,float y0,float x1,float y1,float x2,float y2, DWORD color)
{
    if (g_nTris > MAX_TRIS-3)
    {
        // Error - run out of triangle buffer
    }

#define	scale_x(x) x
#define	scale_y(x) x


	g_pTriVerts[g_nTris+0].x = scale_x(x0);
	g_pTriVerts[g_nTris+0].y = scale_y(y0);
	g_pTriVerts[g_nTris+0].z = 0.5f;
	g_pTriVerts[g_nTris+0].rhw = 1.0f;
	g_pTriVerts[g_nTris+0].color = color;

	g_pTriVerts[g_nTris+1].x = scale_x(x1);
	g_pTriVerts[g_nTris+1].y = scale_y(y1);
	g_pTriVerts[g_nTris+1].z = 0.5f;
	g_pTriVerts[g_nTris+1].rhw = 1.0f;
	g_pTriVerts[g_nTris+1].color = color;

	g_pTriVerts[g_nTris+2].x = scale_x(x2);
	g_pTriVerts[g_nTris+2].y = scale_y(y2);
	g_pTriVerts[g_nTris+2].z = 0.5f;
	g_pTriVerts[g_nTris+2].rhw = 1.0f;
	g_pTriVerts[g_nTris+2].color = color;
    
    g_nTris+=3;    
    
}

inline void	DrawTri(Vector2 a, Vector2 b, Vector2 c, DWORD color)
{
	DrawTri(a.x * g_window_height,a.y * g_window_height,b.x * g_window_height,b.y * g_window_height,c.x * g_window_height,c.y * g_window_height,color);
}

void DrawLine2(float x0,float y0,float x1,float y1, DWORD color0, DWORD color1)
{
    if (g_nLines > MAX_LINES-2)
    {
        // Error - run out of line buffer
    }
	g_pLineVerts[g_nLines+0].x = scale_x(x0);
	g_pLineVerts[g_nLines+0].y = scale_y(y0);
	g_pLineVerts[g_nLines+0].z = 0.5f;
	g_pLineVerts[g_nLines+0].rhw = 1.0f;
	g_pLineVerts[g_nLines+0].color = color0;
                                         
	g_pLineVerts[g_nLines+1].x = scale_x(x1);
	g_pLineVerts[g_nLines+1].y = scale_y(y1);
	g_pLineVerts[g_nLines+1].z = 0.5f;
	g_pLineVerts[g_nLines+1].rhw = 1.0f;
	g_pLineVerts[g_nLines+1].color = color1;
    
    g_nLines+=2;    
}


void DrawLine(float x0,float y0,float x1,float y1, DWORD color)
{
    DrawLine2(x0,y0,x1,y1,color,color);
}


/////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////
// Basic 2d Primitive rendering code - Triangles and Lines


void DrawLine(Vector2 start , Vector2 end, DWORD color)
{
    DrawLine(start.x, start.y, end.x, end.y,color );
}


void DrawX(Vector2 pos, float size, DWORD color)
{
    DrawLine(pos.x-size, pos.y-size, pos.x+size, pos.y+size,color);
    DrawLine(pos.x-size, pos.y+size, pos.x+size, pos.y-size,color);
}

void DrawCross(Vector2 pos, float size, DWORD color)
{
    DrawLine(pos.x-size, pos.y, pos.x+size, pos.y,color);
    DrawLine(pos.x, pos.y+size, pos.x, pos.y-size,color);
}


// Draw a quad with four points in clockwise order
void DrawQuad(float x0,float y0,float x1,float y1,float x2,float y2, float x3, float y3, DWORD color)
{
	DrawTri(x0,y0,x1,y1,x2,y2, color);
	DrawTri(x2,y2,x3,y3,x0,y0, color);
}

// Draw an axis aligned rectangle
void DrawRect(float x, float y, float w, float h, DWORD color)
{
	DrawQuad(x,y,x+w,y,x+w,y+h,x,y+h,color);
}

void DrawSquare(Vector2 pos, float size, DWORD color)
{
	DrawQuad(pos.x-size,pos.y-size, pos.x+size,pos.y-size, pos.x+size,pos.y+size, pos.x-size,pos.y+size,color);
}

void DrawCircle(Vector2 pos, float radius, DWORD color, int segments = 0)
{
	// default is to calculate number of segments automatically
	if (segments == 0)
	{
		segments = (int)(2.0f * radius * D3DX_PI / 3.0f);  // No segment longer than 3 pixels
		segments = (segments + 1) &~1;	// make it an even number
		if (segments < 8) 
			segments = 8;
	}

	float step = 2.0f * D3DX_PI / segments;
	float angle = 0.0f;
	for (int i=0;i<segments;i++)
	{
		float angle2 = angle + step;
		if (i == segments-1)
			angle2 = 0.0f;
		float x1 = radius * sin(angle); 
		float y1 = radius * cos(angle); 
		float x2 = radius * sin(angle2); 
		float y2 = radius * cos(angle2);
		DrawTri(pos.x,pos.y,pos.x+x2,pos.y+y2,pos.x+x1,pos.y+y1,color);
//		color ^= 0xff;
		angle = angle2;
	}

}


void RenderCircle(Vector2 pos, float radius, DWORD color, int segments = 0)
{
	DrawCircle(Vector2(pos.x * g_window_height, pos.y*g_window_height),radius*g_window_height,color,segments);
}





///////////////////////////////////////////////////////////////////////////////

class   CPadButton
{
    public:
        CPadButton();
        ~CPadButton();
        // The UpdateState function is called by the manager to update the state
        // based on hardware specific implementation
        // passing in the button 
        void     UpdateState(bool pressed, float current_time);
    
    
// The simplest implementation of a button would just return if it is pressed right now        
        bool    Pressed() {return m_pressed;}
// More involved would tell you when it was pressed         
        float   PressedTime() {return m_pressed_time;}
        float   ReleasedTime() {return m_released_time;}
// Even more, detecting a "Trigger", and being able to clear it after using it        
        bool    Triggered() {return m_triggered;};
        void    ClearTrigger() {m_triggered = false;}
        bool    Released() {return m_released;}
        void    ClearReleased() {m_released = false;} 
//private:
        bool    m_pressed;
        bool    m_triggered;
        bool    m_released;
        float   m_pressed_time;
        float   m_released_time;
        char    *mp_name;
};

CPadButton::CPadButton()
{
//    g_pWatchManager->SetWatch(&m_pressed);    
    m_pressed = false;
    m_triggered = false;
    m_released = false;
}

CPadButton::~CPadButton()
{
//    delete  mp_watch;
}

void     CPadButton::UpdateState(bool pressed, float current_time)
{

    if (pressed)
    {
        if (!m_pressed)
        {
            debug_log("%4.3f: + Pressed %s",current_time, mp_name);
            m_triggered = true;
            m_pressed_time = current_time;
        }
    }
    else
    {
        if (m_pressed)
        {
            debug_log("%4.3f: - Released %s",current_time, mp_name);
            m_released = true;
            m_released_time = current_time;
        }
    }
    m_pressed = pressed;
}

class   CGamepad
{
    public:
        CGamepad();
        // We are just going to store an array of buttons
        // so we give each one a name so we can refer to it.
        enum    EButton
        {
            BTN_A,
            BTN_B,
            BTN_X,
            BTN_Y,
            BTN_U,
            BTN_D,
            BTN_L,
            BTN_R,
            BTN_L1,
            BTN_R1,
            BTN_L2,
            BTN_R2,
            BTN_START,
            BTN_SELECT,
            BTN_L3,
            BTN_R3,
            
            
            NUM_BUTTONS
        };
        
        CPadButton  button[NUM_BUTTONS];
    
        void        Update( float time);

    private:
    
        
};

char * p_names[] =  {"A","B","X","Y","Up","Down","Left","Right","L1","R1","L2","R2","START","SELECT","L3","R3" };

CGamepad::CGamepad()
{
    for (int i=0;i<NUM_BUTTONS;i++)
    {
        button[i].mp_name = p_names[i];
		button[i].m_pressed = false;
    }
}


void    CGamepad::Update(float time)
{

    unsigned char buttons[256];
    ReadControllerState(buttons);      // Hook into the framework to get the controller state                
                   
    // For each button, update with the relevent state from the DirectInput joystick
    // (the ?true:false is to avoid the compiler's "performance warning" by making the conversion explicit
    
    button[BTN_X].UpdateState((buttons[0]?true:false || key_space), time);
    button[BTN_Y].UpdateState((buttons[3]?true:false) || key_a, time);
    button[BTN_A].UpdateState((buttons[1]?true:false) || key_s, time);
    button[BTN_B].UpdateState((buttons[2]?true:false) || key_d, time);
    button[BTN_L1].UpdateState((buttons[4]?true:false) , time);
    button[BTN_R1].UpdateState(buttons[5]?true:false, time);
    button[BTN_L2].UpdateState(buttons[6]?true:false, time);
    button[BTN_R2].UpdateState(buttons[7]?true:false, time);
    button[BTN_SELECT].UpdateState(buttons[8]?true:false, time);
    button[BTN_START].UpdateState(buttons[9]?true:false, time);
    button[BTN_L3].UpdateState(buttons[10]?true:false, time);
    button[BTN_R3].UpdateState(buttons[11]?true:false, time);
    button[BTN_U].UpdateState((buttons[128]?true:false) || key_up, time);
    button[BTN_D].UpdateState((buttons[129]?true:false) || key_down, time);
    button[BTN_L].UpdateState((buttons[130]?true:false) || key_left, time);
    button[BTN_R].UpdateState((buttons[131]?true:false) || key_right, time);
}

CGamepad                    * g_pGamepad;

///////////////////////////////////////////////////////////////////////////////////////////////////////
// CWatch - Records the state of a particular variable
// this is a debugging class, and would not be used in production code
class   CWatch
{
    friend class    CWatchManager;
                 
                 CWatch();
    void        SetWatch(float *p);
    void        SetWatch(int *p);
    void        SetWatch(char *p);
    void        SetWatch(unsigned char *p);
    void        SetWatch(bool *p);
    void        Update(float time);
    void        Render(float pos_x, float pos_y, float width, float height, float border, float period, float left_area, float time, float time_off );
    
    private:
        enum    EWatchType {
            WATCH_CHAR,
            WATCH_INT,
            WATCH_FLOAT,
            WATCH_BOOL,
        };    
    struct SWatchValue{
        float time;
        union {
            int             i;
            float           f;   
        };
    };  
    
    void init(void*p, EWatchType type);
            
    int get_1_0_at_index(int index);

    const static int   max_watch = 1024;
    
    SWatchValue     m_values[max_watch];       //  MEMOPT!!!   1024*8  8K hmm
    int             m_value_index;
    int             m_num_values;
    void          * mp_watch;       // The address to watch
    EWatchType      m_type;

    DWORD           m_color;
    const char *    mp_desc;
    CWatch  *       mp_next;        // next one in the list

};

CWatch::CWatch()
{
    mp_next = NULL;
}

void CWatch::init(void*p, EWatchType type)
{
    m_value_index   = 0;
    m_num_values    = 0;
    mp_watch        = p;
    m_type          = type;
}

void        CWatch::SetWatch(float *p)
{
    init((void*)p, WATCH_FLOAT);
}

void        CWatch::SetWatch(int *p)
{
    init((void*)p, WATCH_INT);
}

void        CWatch::SetWatch(char *p)
{
    init((void*)p, WATCH_CHAR);
}

void        CWatch::SetWatch(unsigned char *p)
{
    init((void*)p, WATCH_CHAR);
}

void        CWatch::SetWatch(bool *p)
{
    init((void*)p, WATCH_BOOL);
}

void        CWatch::Update(float time)
{
// in theory we could just store it when it changes
// but for now it's simpler just to store all the entries.
    m_values[m_value_index].time = time;
    switch (m_type)
    {
        case WATCH_CHAR:
            m_values[m_value_index].i = *(char*)mp_watch;
            break;
        case WATCH_INT:
            m_values[m_value_index].i = *(int*)mp_watch;
            break;
        case WATCH_FLOAT:
            m_values[m_value_index].f = *(float*)mp_watch;
            break;
        case WATCH_BOOL:
            m_values[m_value_index].i = *(bool*)mp_watch;
            break;
    }
    // increment the buffer and wrap around
    m_value_index++;                // m_value index will point to the entry AFTER the latest valid entry
    if (m_value_index == max_watch) m_value_index = 0;
    if (m_num_values<max_watch) m_num_values++;       // counts up to maximum.
}

// get the value at a particular index and convert it to 1 or 0
int CWatch::get_1_0_at_index(int index)
{
    switch (m_type)
    {
        case WATCH_INT:
        case WATCH_CHAR:
        case WATCH_BOOL:
            return m_values[index].i == 0 ? 0 : 1;
        case WATCH_FLOAT:
            return m_values[index].f == 0.0f ? 0 : 1;
    }
    return 0;
}


void CWatch::Render(float pos_x, float pos_y, float width, float height, float border, float period, float left_area, float time, float time_off )
{

    float   x = width;
    int index = m_value_index;
    int num = m_num_values;
    
    index--;
    if (index <0) index = max_watch-1;

    float   prev_time = time;
    int     prev_value = get_1_0_at_index(index);

    DrawRect(pos_x-border,pos_y-border, width+border*2 + left_area ,height+border*2,0xffffffff);
    DrawString(pos_x, pos_y, mp_desc, m_color);
    
    while (x > 0.01f && num > 2)
    {
        int index_value = get_1_0_at_index(index);
        float   index_time = m_values[index].time + time_off;                
        x = width - width*(time-prev_time)/period;
        float xp = width - width*(time-index_time)/period;
        if (x<0) x = 0;
        if (xp<0) xp = 0;
        DrawLine(left_area+pos_x+x ,pos_y+height*(1-index_value) , left_area+pos_x+xp , pos_y+height*(1-index_value),m_color);              
        DrawLine(left_area+pos_x+x,pos_y+height*(1-prev_value)     , left_area+pos_x+x    , pos_y+height*(1-index_value),m_color);              
        num--;
        index--;
        if (index <0) index = max_watch-1;
        prev_time = index_time;
        prev_value = index_value;
    }
    

}

// End of CWatch
/////////////////////////////////////////////////////////////////////////////

class   CWatchManager
{
public:    
    CWatchManager();
    void        Update(float time);
    void        Render(float time, bool paused);
    void        SetWatch(float *p, DWORD color, const char*c); 
    void        SetWatch(int *p, DWORD color, const char*c); 
    void        SetWatch(char *p, DWORD color, const char*c);
    void        SetWatch(unsigned char *p, DWORD color, const char*c);
    void        SetWatch(bool *p, DWORD color, const char*c);

    void        RecordEvent(int event, float time, char *desc, DWORD color);

    void        ToggleEventDisplay() {m_display_events = !m_display_events;}
                                    
private:
    CWatch *    add_watch(DWORD color, const char *desc);    
    CWatch *    mp_head;

    struct SWatchEvent{
        int         event;
        float       time;
        char        desc[64];                   //  MEMOPT!!!
        DWORD       color;
        float y;
    };  
    
    const static int   max_watch_event = 1024;
    SWatchEvent     m_events[max_watch_event];        // 80 K
    int             m_event_index;
    int             m_num_events;
    float           m_last_event_time;
    float           m_last_event_y;

    float           m_tick_time;
    float           m_last_tick_time;

    bool            m_display_events;
    
};


CWatchManager           * g_pWatchManager;


CWatchManager::CWatchManager()
{
    mp_head = NULL;
    m_event_index = 0;
    m_num_events = 0;
    m_last_event_time =0;
    m_last_event_y =0.0f;
    m_display_events = true;
}

void        CWatchManager::RecordEvent(int event, float time, char *desc, DWORD color)
{

//    if (event >= 0) debug_log("%4.3f: Event %s",time, desc);

    float   event_y = 12.0f;

    // For the "tick" event, record the length of the tick, for later dispay
    if (event == -1)
    {
        m_tick_time = time - m_last_tick_time;
        m_last_tick_time = time;
    }
    else
    // for regular events
    {
        // alternate the height of the event text if it is close to the previous event    
        if (time - m_last_event_time < 0.50)
        {   
            event_y = 12.0f - m_last_event_y;
        }
        m_last_event_time = time;
        m_last_event_y = event_y;
    }
        
    m_events[m_event_index].event = event;
    m_events[m_event_index].time = time;
    m_events[m_event_index].y = event_y;
    m_events[m_event_index].color = color;
    strncpy(m_events[m_event_index].desc,desc,63);
    m_events[m_event_index].desc[63]='\0';           //  MEMOPT!!! (if you change above...... const it or something!!
    // increment the buffer and wrap around
    m_event_index++;                // m_event index will point to the entry AFTER the latest valid entry
    if (m_event_index == max_watch_event) m_event_index = 0;
    if (m_num_events<max_watch_event) m_num_events++;       // counts up to maximum.

}




void CWatchManager::Render(float time, bool paused)
{
    static float   period = 5.0f;           // period to draw in seconds
    static float   time_off = 0.0f;         // time offset to start drawing from
    
    
    float   height = 10;
    float   pos_x = 0;
    float   start_y = 0;
    float   pos_y = start_y;
    float   border = 3;
    const float left_area = 40;
    float   width = 1024-left_area;

    const   float   max_tick_period = 2.5f;


    if (paused)
    {
        // Zoom in and out, scaling around the center of the window
        if (g_pGamepad->button[CGamepad::BTN_A].Pressed())
        {
            time_off -= period * (1.01f - 1.0f) * 0.5f;
            period *= 1.01f;
        }
        if (g_pGamepad->button[CGamepad::BTN_Y].Pressed())
        {
            time_off -= period * (1.0f - 1.01f) * 0.5f;
            period *= 1.0f/1.01f;
        }
        if (g_pGamepad->button[CGamepad::BTN_L].Pressed())
            time_off += period / 100.0f;
        if (g_pGamepad->button[CGamepad::BTN_R].Pressed())
            time_off -= period / 100.0f;
        
    }
    else
    {
        time_off = 0;
     //   period = 5.0f;
    }

    if (!mp_head)
        return;

// Count how many there are, so we can put the events at the bottom
    int watches = 0;
    CWatch *p_watch = mp_head;
    while (p_watch)
    {
        watches++;
        p_watch=p_watch->mp_next;
    }

    pos_y = start_y + watches * ( height+border*3);

///////////////////////////////
// Now render the events

    float x = width;
    int index = m_event_index;
    int num = m_num_events;

    DrawRect(pos_x-border,pos_y-border, width+border*2 + left_area ,height*2+border*5,0xffffffff);
    if (m_display_events)
    {
        DrawString(pos_x, pos_y, "Events", 0xff000000);
    }
    char c[128];
    if  (period < max_tick_period)
    {
        sprintf(c,"%3.1fms",m_tick_time*1000);
    }
    else
    {
        sprintf(c,"%3.0fms",m_tick_time*10000);
    }
    DrawString(pos_x, pos_y+height+border, c, 0xff000000);
    float last_index_time = 0.0f;
    while (x > 0.01f && num > 0)
    {
        index--;
        if (index <0) index = max_watch_event-1;
        float   abs_index_time = m_events[index].time;
        float   index_time = m_events[index].time+time_off;                
        x = width - width*(time-index_time)/period;
        if (x>0)
        {
            if (m_events[index].event == -1)
            {
                // Draw the dicks as little grey lines at the bottom
                if (period < max_tick_period)
                {
                    DrawLine(left_area+pos_x+x,start_y - border, left_area+pos_x+x , pos_y + height * 3 , 0xfff0f0f0);              
                    DrawLine2(left_area+pos_x+x,pos_y + height , left_area+pos_x+x , pos_y + height * 3 , 0xfff0f0f0, 0xff808080);              
                }
                else if (last_index_time != 0.0f)
                {
                    //  draw the ticks that fall as close to 1/10th as possible
                    //  get prev, round it down to 1/10th, and see if this one is below it
                    // if so, draw it here as a blue line
                    float rounded = (float)((int)(last_index_time*10))/10.0f;
                    if (abs_index_time < rounded)
                    {
                        DrawLine2(left_area+pos_x+x,pos_y-border  , left_area+pos_x+x    , pos_y + height * 3 , 0xffffffff, 0xffe0f0f0);              
                        DrawLine2(left_area+pos_x+x+1,pos_y-border, left_area+pos_x+x+1 , pos_y + height * 3  , 0xffffffff, 0xffe0f0f0);              
                    }
                    
                }
                last_index_time = abs_index_time;
            }
            else
            {
                if (m_display_events)
                {
                    DrawLine(left_area+pos_x+x,start_y , left_area+pos_x+x , pos_y + m_events[index].y,m_events[index].color);              
                    DrawString(left_area+pos_x+x,pos_y + m_events[index].y, m_events[index].desc, m_events[index].color);
                }
            }
        }
        num--;
    }
    
    pos_y=start_y;

    p_watch = mp_head;
    while (p_watch)
    {
        p_watch->Render(pos_x, pos_y, width, height, border, period, left_area, time, time_off);
        pos_y += height+3.0f*border;
        p_watch = p_watch->mp_next;
        // Draw a line between individual watches 
        DrawRect(pos_x-border,pos_y-border*2, width+border*2 + left_area ,border,0xffe0e0e0);
    }
}

void CWatchManager::Update(float time)
{
    CWatch *p_watch = mp_head;
    while (p_watch)
    {
        p_watch->Update(time);
        p_watch = p_watch->mp_next;
    }
}


CWatch  *    CWatchManager::add_watch(DWORD color, const char *desc)
{
    CWatch * p_new_watch = new CWatch();
    p_new_watch->m_color = color;
    p_new_watch->mp_desc = desc;
    if (!mp_head)
    {
        mp_head = p_new_watch;
    }
    else
    {
        CWatch * p_tail = mp_head;
        while (p_tail->mp_next) p_tail = p_tail->mp_next;
        p_tail->mp_next = p_new_watch;
    }
    return p_new_watch;
}
                              
void        CWatchManager::SetWatch(float *p, DWORD color , const char*c)  { add_watch(color,c)->SetWatch(p); } 
void        CWatchManager::SetWatch(int *p, DWORD color, const char*c)     { add_watch(color,c)->SetWatch(p); } 
void        CWatchManager::SetWatch(char *p, DWORD color, const char*c)    { add_watch(color,c)->SetWatch(p); }
void        CWatchManager::SetWatch(unsigned char *p, DWORD color, const char*c)  { add_watch(color,c)->SetWatch(p); }
void        CWatchManager::SetWatch(bool *p, DWORD color, const char*c)  { add_watch(color,c)->SetWatch(p); }




/////////////////////////////////////////////////////////////////////////////////
// The main MX application




/*

// problem happend before around 00260

all with no threads
	10000			.0051
	12000			.0062
	14000			.0071
	15000			.0078
	16000			.0083
	17000			.0088
	18000			.0095
	20000			.0104
	40000			.0207
	48000			.0246
	50000			.0255
	50250			.0257
	50400			.0260
	50500			.0269, 0.0266 .0273  <<<< ODD
	50550			.0258
	50600			.0262
	51000			.0264
	51500			.0265
	52000			.0270
	52500			.0273
	53000			.0271
	54000			.0279
	80000			.0414

*/

void MX_Init()
{
#ifdef		CRITICAL_SECTION_RND
	InitializeCriticalSection(&rnd_CS);
#endif
	g_pWatchManager = new CWatchManager();
    g_pGamepad = new CGamepad();

	WhimsyInit();
	WhimsyParse();

}

char  printf_buffer[1024];

void    debug_log( const char* text, ...)
{
	EnterCriticalSection(&debug_CS);

// Get Text into a printable buffer	 (maybe prepend time)
    va_list args;
	va_start( args, text );
	vsprintf( printf_buffer, text, args);
	va_end( args );
// output as debug text
    OutputDebugString(printf_buffer);

	LeaveCriticalSection(&debug_CS);

}

float game_time = 0.0f;

static bool paused = false;

void MX_Logic(float time)
{
    static float last_time = 0.0f;
    
    float timestep = time - last_time;
    
    if (timestep > 0.25f) timestep = 0.25f;

    last_time = time;


    if (paused)
    {
        g_pGamepad->Update(game_time);

        if (g_pGamepad->button[CGamepad::BTN_R1].Triggered())
        {
            g_pGamepad->button[CGamepad::BTN_R1].ClearTrigger();
            g_pWatchManager->ToggleEventDisplay();
        }
    }
    else
    {
        //game_time += timestep;
        game_time = Timer_Seconds();
        g_pGamepad->Update(game_time);
        g_pWatchManager->Update(game_time);
        //  adding the tick event last, as they are drawn in reverse order and we don't want ot overwrite actual events
        g_pWatchManager->RecordEvent(-1, game_time, "Tick", 0xffc00000);  // Special event to record clock ticks, displayed along the bottom
    }
    
    if (g_pGamepad->button[CGamepad::BTN_START].Triggered())
    {
        g_pGamepad->button[CGamepad::BTN_START].ClearTrigger();
        paused = !paused;
        if (paused)
            Timer_Pause();
        else
            Timer_Resume();
    }

	WhimsyParse();
}

void MX_Render()
{
	WhimsyRender();
}

void MX_Cleanup()
{
    delete      g_pWatchManager;
    delete      g_pGamepad;
}



//-----------------------------------------------------------------------------
// Name: MsgProc()
// Desc: The window's message handler
//-----------------------------------------------------------------------------
LRESULT WINAPI MsgProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam )
{
    switch( msg )
    {
        case WM_DESTROY:
            Cleanup();
            PostQuitMessage( 0 );
            return 0;
    	
        case WM_SIZE:
    	{
//    	    resize_db(hWnd);		
//    		InitD3D(hWnd);
            g_resize = true;
            break;
    	}           

		case WM_LBUTTONUP:
		{
			dragging = false;
			break;
		}


		case WM_LBUTTONDOWN:
		{
			dragging = true;
	// DROP THROUGH
	//		break;
		}
		
		case WM_MOUSEMOVE:
		{
			//if (dragging)
			{
				mouse_x = LOWORD(lParam);  // X position of cursor 
				mouse_y = HIWORD(lParam);  // Y position of cursor
			}
			break;	
		}

	case WM_KEYDOWN:
		{
			int key = HIWORD(lParam) & 0x1ff;
			debug_log("%x",key);
			if (key == 0x11) key_w = 1;
			if (key == 0x1e) key_a = 1;
			if (key == 0x1f) key_s = 1;
			if (key == 0x20) key_d = 1;
			if (key == 0x39) key_space = 1;
			if (key == 0x14b) key_left = 1;
			if (key == 0x14d) key_right = 1;
			if (key == 0x148) key_up = 1;
			if (key == 0x150) key_down = 1;

		}
		break;

		case WM_KEYUP:
		{
			int key = HIWORD(lParam) & 0x1ff;
			if (key == 0x11) key_w = 0;
			if (key == 0x1e) key_a = 0;
			if (key == 0x1f) key_s = 0;
			if (key == 0x20) key_d = 0;
			if (key == 0x39) key_space = 0;
			if (key == 0x14b) key_left = 0;
			if (key == 0x14d) key_right = 0;
			if (key == 0x148) key_up = 0;
			if (key == 0x150) key_down = 0;

		}
		break;

            
    }

    if (g_pWatchManager)  // Might not have been initialized yet
    {
        char win_event[1024]; 
        sprintf(win_event, "%x (%d)", msg, wParam);
    
//        g_pWatchManager->RecordEvent(5, Timer_Seconds(), win_event, 0xffc00000);  // Special event to record clock ticks, displayed along the bottom
    }

    return DefWindowProc( hWnd, msg, wParam, lParam );
}



//-----------------------------------------------------------------------------
// Name: UpdateInputState()
// Desc: Get the input device's state and display it.
//-----------------------------------------------------------------------------
HRESULT UpdateInputState( HWND hDlg )
{
    HRESULT     hr;
    TCHAR       strText[512] = {0}; // Device state text

    if( NULL == g_pJoystick ) 
        return S_OK;

    // Poll the device to read the current state
    hr = g_pJoystick->Poll(); 
    if( FAILED(hr) )  
    {
        // DInput is telling us that the input stream has been
        // interrupted. We aren't tracking any state between polls, so
        // we don't have any special reset that needs to be done. We
        // just re-acquire and try again.
        hr = g_pJoystick->Acquire();
        while( hr == DIERR_INPUTLOST ) 
            hr = g_pJoystick->Acquire();

        // hr may be DIERR_OTHERAPPHASPRIO or other errors.  This
        // may occur when the app is minimized or in the process of 
        // switching, so just try again later 
        return S_OK; 
    }

    // Get the input's device state
    if( FAILED( hr = g_pJoystick->GetDeviceState( sizeof(DIJOYSTATE2), &js ) ) )
        return hr; // The device should have been acquired during the Poll()

    // Get the buffered input events

    DWORD     pdwInOut = JOY_BUFFERSIZE;
    g_pJoystick->GetDeviceData(sizeof(DIDEVICEOBJECTDATA), g_inputbuffer, &pdwInOut, 0);         
    DWORD system_ticks = GetTickCount();
    float   game_time = Timer_Seconds();
    float system_time = system_ticks/1000.0f;
    if (pdwInOut != 0)
    {

        //debug_log("Have %d buffered from joy", pdwInOut);

        // Go through them and note them as events so we can see timing

        for (unsigned int i=0;i<pdwInOut;i++)
        {
            float timestamp = (float)g_inputbuffer[i].dwTimeStamp/1000.0f;
          //  debug_log("[%d] = 0x%x at Time = %f, system_time = %f, (%f), gametime = %f",(int)g_inputbuffer[i].dwOfs, (int)g_inputbuffer[i].dwData, timestamp, system_time, timestamp-system_time, Timer_Seconds());

            g_pWatchManager->RecordEvent(6, game_time + (timestamp - system_time), g_inputbuffer[i].dwData?"On":"Off", 0xffc00000);  
        }
    }
    return S_OK;
}





/////////////////////////////////////////////////////////////////////////////////////////////////
// A CWhim is our base class for a thing, kinda virtual
// A whim can be a collection of other whims, recursivly
// such collections 
// Our "world" is a collection
// objects within the world can be grouped into arbitary collections
// collections can be named

class	CWhim
{
public:
	
	enum EWhimType {
		WHIM_NONE = 0,
		WHIM_COLOR,
		WHIM_PRIMITIVE,
		WHIM_COLLECTION,
	};
	//virtual Vector2	GetPosition();
		//virtual float	GetRadius();
	void	SetName(std::string name) {m_name = name;}
	string  GetName() {return m_name;}
	void	Larger();
	void	Smaller();
	uint32	GetColor(){return m_color;};
	void	SetColor(uint32 color){m_color=color;}
	virtual void	DebugDump();
	EWhimType	GetType(){return m_type;}
	void SetType(EWhimType type){m_type=type;}

	virtual void	Resize(float scale);
	virtual void	Render();
	virtual	void	SetPosition(Vector2 pos);
	virtual	Vector2	GetPosition(){return Vector2(0,0);}
	void	Show() {m_renderable = true;}
	void	Hide() {m_renderable = false;}
	bool	IsRenderable() {return m_renderable;}
private:
	string m_name;
	uint32	m_color;
	EWhimType	m_type;
	bool	m_renderable;
};

// A class to contain everything to do with the current whim creation state
// like where we are looking, etc
class CWhimState
{
	Vector2	m_pos;		// current position within the space
	Vector2 m_size;		// the size of the space

};

void	CWhim::SetPosition(Vector2 pos)
{
	// assert?
}


// Utility function to find a whim, must encapsulat later

CWhim * GetWhim(string name)
{
	// Not implemented
	return NULL;
}



void	CWhim::Larger()
{
	Resize(1.25f);
}

void	CWhim::Smaller()
{
	Resize(1.0f/1.25f);
}

void CWhim::Resize(float size)
{
}

void CWhim::Render()
{
}

void CWhim::DebugDump()
{
	debug_log ("WARNING: base class CWhim (%s)",GetName().data());
}

/////////////////////////////////////////////////////////////
// ConvexShape
// A convex shape is something like a circle or a square
//
// It has a parametric perimiter which is used to render the shape
// you can get points a certain percentage of the distance along the shape
// which allows us to render it with triangles
// and do other things, such as render it distorted



class	CConvexShape : public CWhim
{
public:
	virtual void Render();
	virtual	int GetSegments(){return 4;}
	void SetPosition(Vector2 pos);
	virtual Vector2	GetPoint(float ratio){return Vector2(0,0);};
	virtual Vector2	GetLinearPoint(float ratio){return GetPoint(ratio);};
	virtual	Vector2 GetPosition() {return m_pos;}
	Vector2	GetAbsPoint(float ratio) {return m_pos + GetPoint(ratio);}
	Vector2	GetAbsLinearPoint(float ratio) {return m_pos + GetLinearPoint(ratio);}
protected:
	Vector2	m_pos;
};

void CConvexShape::Render()
{

	int segments = GetSegments();

	//segments = 20;

	float step = 1.0f / segments;
	float amount = 0.0f;
	for (int i=0;i<segments;i++)
	{
		float amount2 = amount + step;
		if (i == segments-1)
			amount2 = 0.0f;
		Vector2 p1 = GetPoint(amount);
		Vector2 p2 = GetPoint(amount2);
		DrawTri(m_pos,m_pos+p1,m_pos+p2,GetColor());
		amount = amount2;
		//RenderCircle(m_pos,0.003f,0xff00ff);
		//RenderCircle(m_pos+p1,0.003f,0xff00ff);
		//RenderCircle(m_pos+p2,0.003f,0xff00ff);
	}

	//RenderCircle(m_pos,0.03f,0xff00ff);

}

void CConvexShape::SetPosition(Vector2 pos)
{
	m_pos = pos;
}

////////////////////////////////////////////////////////////
// Circle
class	CCircle : public CConvexShape
{
public:
	CCircle();
	virtual void Resize(float scale);
	virtual void DebugDump();
	virtual Vector2	GetPoint(float ratio);
	virtual	int GetSegments();
protected:
	float m_radius;
};

CCircle::CCircle()
{
	m_pos = Vector2(0.5f,0.5f);
	m_radius = 0.1f;
	Show();
}

// Return a point on the perimiter, relative to the center of the circle, a certain amount along the perimiter
Vector2	CCircle::GetPoint(float ratio)
{		
	float angle = 2.0f * D3DX_PI * ratio;
	float x = m_radius * cos(angle); 
	float y = m_radius * sin(angle);
	return Vector2(x,y);		
}

int CCircle::GetSegments()
{
	int segments = (int)(2.0f * m_radius * D3DX_PI * g_window_height / 3.0f);  // No segment longer than 3 pixels
	segments = (segments + 1) &~1;	// make it an even number
	if (segments < 8)
		segments = 8;
	return segments;
}

void CCircle::DebugDump()
{
	debug_log ("Circle: [%s] pos=(%f,%f) radius = %f",GetName().data(),m_pos.x,m_pos.y,m_radius);
}


void CCircle::Resize(float scale)
{
	m_radius *= scale;
}


////////////////////////////////////////////////////////////
// SuperEgg
// See http://mathworld.wolfram.com/Superellipse.html
//
class	CSuperEgg : public CConvexShape
{
public:
	CSuperEgg(float a, float b, float r);
	virtual void Resize(float scale);
	virtual void DebugDump();
	virtual Vector2	GetPoint(float ratio);
	virtual Vector2	GetLinearPoint(float ratio);
	virtual	int GetSegments();
	void	PrecalculateCurve();
protected:
	float m_a,m_b,m_r;
	// TODO!!! This resolution is way too high, we should be able to smoothly interpolate from as few as 1024 samples.
	static const int samples = 102400;  // sample this many angles, we do the whole 2PI, since we want to be generic later,
	double angle_to_linear[samples+1]; // array of distances of a point at an angle ratio along the curce
	double linear_to_angle[samples+1]; // corrected angles.
};

// We precalculate the curve to a rough resolution in order
// to better calculate distances along it.
void CSuperEgg::PrecalculateCurve()
{
	Vector2	last_point;
	double total = 0.0;
	int s;
	for (s=0;s<=samples;s++)
	{
		Vector2	point = GetPoint((float)s/samples);
		if (s>0)
		{
			Vector2	chord = (point-last_point);
			float len = chord.Length();
			total += len;
			angle_to_linear[s-1] = total; // note this ignores ratio 0.0, which is assumed to be at distance 0.0, but includes 1.0
		//	debug_log("angle_to_linear[%d] = %f",s-1,total);
		}
		last_point = point;
	}
	for (s=0;s<samples;s++)
	{
		angle_to_linear[s] /= total;	// get each point distance as a ratio
		//debug_log("angle_to_linear[%d] = %f",s,d[s]);

	}
	// Okay, we now have an array of the linear distance at each angular position
	// so calculate the inverse table
	// 
	int angular_ratio_index=0;
	for (int r = 1;r<=samples;r++)
	{
		float linear_ratio = (float)(r)/samples;
		//debug_log("looking for %f",linear_ratio);
		// given this linear_ratio, find the first angular ratio with a higher linear ratio
		while (angle_to_linear[angular_ratio_index] < linear_ratio  && angular_ratio_index<samples)
		{
		//	debug_log("%f < %f, so skipping entry %d",angle_to_linear[angular_ratio_index],linear_ratio,angular_ratio_index);
			angular_ratio_index++;
		}
		// Okay, now we know we are between this one and the previous one
		// we could interpolate, but just use this for now

		// INTERPOLATE HERE!!!!

		linear_to_angle[r-1] = (float)angular_ratio_index / samples;
		//debug_log("a[%d] = %f",r-1,a[r-1]);
	}


}

CSuperEgg::CSuperEgg(float a, float b, float r)
{
	m_pos = Vector2(0.5f,0.5f);
	m_a = a;
	m_b = b;
	m_r = r;
	Show();
	PrecalculateCurve();
}

// Return a point on the perimiter, relative to the center of the SuperEgg, a certain amount along the perimiter
Vector2	CSuperEgg::GetPoint(float ratio)
{		
	float angle = 2.0f * D3DX_PI * ratio;
//	float x = m_a * powf(cos(angle),m_r); 
//	float y = m_b * powf(sin(angle),m_r);
	float c = cosf(angle);
	float s = sinf(angle);
	float x,y;
	if (c<0)
		x = -m_a * powf(-c,2.0f/m_r); 
	else
		x = m_a * powf(c,2.0f/m_r); 
	if (s<0)
		y = -m_b * powf(-s,2.0f/m_r);
	else
		y = m_b * powf(s,2.0f/m_r);
	return Vector2(x,y);		
}

Vector2 CSuperEgg::GetLinearPoint(float ratio)
{	
	float temp_b = m_b;
	m_b = m_a;
	Vector2 circ = GetPoint(ratio);
	m_b = temp_b;
	circ.y *= m_b/m_a;
	return circ;


	// Not sure if this interpolation is helping.
	ratio = fmodf(ratio,1.0f);
	float prev = 0.0f;
	int index = (int)((float)samples*ratio);
	float remainder = (ratio*samples)-(float)index;
	float angle = (float)linear_to_angle[index];
	if (index > 0)
	{
		prev = (float)linear_to_angle[index-1];
	}
	angle = prev + (angle-prev) * remainder;
	return GetPoint(angle);
}

/*
Vector2 CSuperEgg::GetLinearPoint(float segment, float segments)
{
	// Get a point that is a certain distance around the perimiter, 
	// so that two points 
}
*/

int CSuperEgg::GetSegments()
{
	// Same as for circles, but use (m_a + m_b) instead of 2xRadius
	int segments = (int)((m_a+m_b) * D3DX_PI * g_window_height / 3.0f);  // No segment longer than 3 pixels
	segments = (segments + 1) &~1;	// make it an even number
	if (segments < 8)
		segments = 8;
	return segments;
}

void CSuperEgg::DebugDump()
{
	debug_log ("SuperEgg: [%s] pos=(%f,%f) a = %f, b = %f, r=%f",GetName().data(),m_pos.x,m_pos.y,m_a,m_b,m_r);
}


void CSuperEgg::Resize(float scale)
{
	m_a *= scale;
	m_b *= scale;
}





////////////////////////////////////////////////////////////
// Rectangle
class	CRectangle : public CConvexShape
{
public:
	CRectangle();
	virtual void Resize(float scale);
	virtual void DebugDump();
	virtual int GetSegments();
	virtual Vector2	GetPoint(float ratio);
protected:
	float m_width;
	float m_height;
};

CRectangle::CRectangle()
{
	m_pos = Vector2(0.5f,0.5f);
	m_width = 0.1f;
	m_height = 0.1f;
	Show();
}

// Return a point on the perimiter, relative to the center of the Rectangle, a certain amount along the perimiter
// This could be generazied for an arbitary polygon
Vector2	CRectangle::GetPoint(float ratio)
{		
	float border = (2.0f * (m_width + m_height));
	if (ratio < (m_width / border))
	{
		// Point along the top
		return Vector2(-m_width/2.0f + ratio * border, -m_height/2.0f);
	}
	else if (ratio < ((m_width + m_height) / border))
	{
		return Vector2(m_width/2.0f, -m_height/2.0f + ratio * border - m_width);
	}
	else if (ratio < ((m_width + m_height + m_width) / border))
	{
		return	Vector2(m_width/2.0f - (ratio * border - m_height - m_width), m_height/2.0f);
	}
	else
	{
		return	Vector2(-m_width/2.0f, m_height/2.0f - (ratio * border - m_width - m_height - m_width));
	}
		
}

int CRectangle::GetSegments()
{
	return 4;		// only need 4 segments for a rectangle
}

void CRectangle::DebugDump()
{
	debug_log ("Rectangle: [%s] pos=(%f,%f) Size = (%f,%f)",GetName().data(),m_pos.x,m_pos.y,m_width,m_height);
}


void CRectangle::Resize(float scale)
{
	m_width *= scale;
	m_height *= scale;
}

////////////////////////////////////////////////////////////////////////////////
// Petals are sub-objects
// a petal has a parent object
// and is defined by two points around the perimeter
// a height relative to the width
// and a color
// Right now the shape of a petal is fixed, but could be made arbitary.

class CPetal : public CConvexShape
{
public:
	CPetal(CWhim *p_parent, float start, float end, float height);
	virtual void Resize(float scale);
	//virtual void DebugDump();
	virtual int GetSegments();
//	virtual Vector2	GetPoint(float ratio);
	virtual void Render();
protected:
	CWhim *mp_parent;
	float m_start;
	float m_end;
	float m_height;
};


CPetal::CPetal(CWhim *p_parent, float start, float end, float height)
{
	mp_parent = p_parent;
	m_start = start;
	m_end = end;
	m_height = height;
	Show();
}

void CPetal::Resize(float scale)
{
	m_height *= scale;
}

int CPetal::GetSegments()
{
	return 20;		// arb for now
}

void CPetal::Render()
{
	// Oh, crap

	CConvexShape *p_parent = dynamic_cast<CConvexShape*>(mp_parent);
	assert(p_parent != NULL);

	// Get start and end points
	Vector2	start = p_parent->GetAbsLinearPoint(m_start);
	Vector2	end = p_parent->GetAbsLinearPoint(m_end);

	// temp render
	//RenderCircle(start, 0.01f, 0xff0000);
	//RenderCircle(end, 0.01f, 0xffffff);

	// Given start and end, we can get the tangent (well, really the chord for start to end)
	// and then get the normal
	// We know the points are always clockwise, so -y,x should do it
	Vector2 chord = (end-start);
	Vector2 normal = Vector2(chord.y,-chord.x).Normal();
	float width = chord.Length();
	float height = width * m_height;

	// Okay, now iterate over the base, which is the segment of the parent object
	// and just draw a semi-elipse over that for now

	int segments = 30;
	Vector2	last_base;
	Vector2	last_point;
	for (int seg = 0;seg<=segments;seg++)
	{
		// calculate the distance along the line  0.0 to 1.0
		float x = (float)(seg)/segments;
		float r = x - 0.5f; // distance from axis
		float h = height * sqrtf(0.25f - r*r);
		//Vector2 base = start + chord * (float)seg/segments;

		Vector2 base  = p_parent->GetAbsLinearPoint(m_start + (m_end-m_start)*(float)seg/segments);

		Vector2	point = base + h * normal;
		if (seg >= 1)
		{
			DrawTri(last_base,last_point,point,GetColor());
			DrawTri(last_base,point,base,GetColor());
		}
		//RenderCircle(base, 0.005f, 0xffff00);
		//RenderCircle(point, 0.005f, 0x00ff00);

		last_base = base;
		last_point = point;
	}




}


///////////////////////////////////////////////////////////////////////////////
// Inner
class CInner : public CConvexShape
{
public:
	CInner(CWhim *p_parent, float ratio, float vary, float phase);
	//virtual void Resize(float scale);
	//virtual void DebugDump();
	virtual int GetSegments();
	virtual Vector2	GetPoint(float ratio);
	virtual Vector2	GetLinearPoint(float ratio);
	//virtual void Render();
protected:
	CWhim *mp_parent;
	float m_ratio;
	float m_vary;
	float m_phase;
};


CInner::CInner(CWhim *p_parent, float ratio, float vary, float phase)
{
	mp_parent = p_parent;
	m_vary = vary;
	m_ratio = ratio;
	m_phase = phase;
	SetColor(mp_parent->GetColor());
	CConvexShape *p_p = dynamic_cast<CConvexShape*>(mp_parent);
	assert(p_p != NULL);
	m_pos = p_p->GetPosition();
	Show();
}

int CInner::GetSegments()
{
	CConvexShape *p_parent = dynamic_cast<CConvexShape*>(mp_parent);
	assert(p_parent != NULL);
	return p_parent->GetSegments();		// arb for now
}

Vector2	CInner::GetPoint(float ratio)
{

	CConvexShape *p_parent = dynamic_cast<CConvexShape*>(mp_parent);
	assert(p_parent != NULL);
	Vector2	pos = p_parent->GetPosition();
	//float v = sinf(ratio*D3DX_PI * 5.0f);
	Vector2	point = p_parent->GetPoint(ratio);
	float angle = ratio + m_phase; 
	float v = sinf(angle*D3DX_PI*2.0f * 7.0f) + sinf((angle+0.2f)*D3DX_PI*2.0f * 3.0f);
	return (point * m_ratio * (1.0f + v * m_vary));
}

// REFACTOR: This is the same as above, except for the "linear" call
Vector2	CInner::GetLinearPoint(float ratio)
{

	CConvexShape *p_parent = dynamic_cast<CConvexShape*>(mp_parent);
	assert(p_parent != NULL);
	Vector2	pos = p_parent->GetPosition();
	//float v = sinf(ratio*D3DX_PI * 5.0f);
	Vector2	point = p_parent->GetLinearPoint(ratio);
	float angle = ratio + m_phase; 
	float v = sinf(angle*D3DX_PI*2.0f * 7.0f) + sinf((angle+0.2f)*D3DX_PI*2.0f * 3.0f);
	return (point * m_ratio * (1.0f + v * m_vary));
}






////////////////////////////////////////////////////////////////////////////////
// A color is a whim, since we can create new colors, have a sets of them, etc
class	CColor : public CWhim
{
public:
	virtual void DebugDump();
	CColor(string m_name, uint32 color);
private:
//	uint32	m_color;
	
};

CColor::CColor(string name, uint32 color)
{
	SetType(WHIM_COLOR);
	SetName(name);
	SetColor(color);
}

void CColor::DebugDump()
{
	debug_log ("Color: [%s] 0x%08x",GetName().data(),GetColor());
}

class	CCollection : public CWhim
{
public:
	void	Parse(string fileName);
	void	Render();
	void	Add(CWhim* whim);
	void	RenderAll();
	void	Reset();
private:
	vector<CWhim*> m_whims;
	vector<CWhim*> m_parse_context;

	_BY_HANDLE_FILE_INFORMATION m_file_info;
	_BY_HANDLE_FILE_INFORMATION m_last_file_info;

};

void CCollection::Reset()
{
	m_whims.clear();
	m_parse_context.clear();
}


void	CCollection::Add(CWhim* whim)
{
	m_whims.push_back(whim);
}

void	CCollection::Render()
{
	// Iterate over all the Whims, and render any that are renderable.
}

// Tokenizer class to take a string an split it one token at a time
class CTokenizer 
{
	string	m_string;
	string	m_delimiters;
	size_t	m_offset;
	size_t	m_last_offset;
public:
	CTokenizer(string& a_string, string& limits = string(" ,;");) {m_string = a_string; m_delimiters=limits; m_offset=0;m_last_offset=0;}
	void	Reset();
	void	Back();
	string	NextToken();
}




string CTokenizer::NextToken()
{
	if (m_string.empty())
	{
		return m_string;
	}

	size_t i = m_string.find_first_not_of(m_delimiters, m_offset);
    if (i == string::npos)
	{
        return string("");
    }

    size_t j = m_string.find_first_of(m_delimiters, i);
    if (j == string::npos) 
	{
        return string("");
    }

    // to intercept the token and save current position
    m_last_offset = m_offset;
    m_offset = j;
    return m_string.substr(i, j - i);
}

// Step back one token, if possible
void CTokenizer::Back()
{
	m_offset = m_last_offset;
}

void CTokenizer::Reset()
{
	m_offset = 0;
}



void CCollection::Parse(string fileName)
{
	// Load a file and parse it.
	// Use the nice fast memory mapped method, as suggested by me.
	//HANDLE hInFile = ::CreateFile(L"IMAGE.JPG",
	HANDLE hInFile = ::CreateFile((LPCSTR)fileName.data(),GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_READONLY,NULL);
	GetFileInformationByHandle(hInFile,&this->m_file_info);
	if (m_file_info.ftLastWriteTime.dwHighDateTime == m_last_file_info.ftLastWriteTime.dwHighDateTime
		&& m_file_info.ftLastWriteTime.dwLowDateTime == m_last_file_info.ftLastWriteTime.dwLowDateTime)
	{
		::CloseHandle(hInFile);
		return;
	}

	bool	grouping = false;

	Reset();

	// CRAP - factor this out into the class or something
	WhimsyInit();

	m_last_file_info = m_file_info;


	DWORD  dwFileSize = ::GetFileSize(hInFile, NULL);
	HANDLE hMappedInFile = ::CreateFileMapping(hInFile, NULL,PAGE_READONLY,0,0,NULL);
	LPBYTE lpMapInAddress = (LPBYTE) ::MapViewOfFile( hMappedInFile,FILE_MAP_READ,0,0,0);


	char *p_in=(char*)lpMapInAddress;
	int madness = 200000;
	while (*p_in  && madness--)
	{
		// read each line as a string, and parse it.
		string line;
		string skipped;
		while (*p_in && *p_in != 0x0d && *p_in !=0x0a)
		{
			if (p_in[0] == '/' && p_in[1] == '/')
			{
				// If it's a comment, then skip to the end of the line
				while (*p_in && *p_in != 0x0d && *p_in !=0x0a)
				{
					skipped += *p_in++;
				}
			}
			else
			{
				if (p_in[0] == '/' && p_in[1] == '*')
				{
					// skip possibly multi-line comment, which hence allows us to combine lines, but WTH
					// No nested comments allowed.
					while (*p_in && (p_in[0] != '*' || p_in[1] != '/'))
					{
						p_in++;
					}
					p_in += 2;	// skip the */

				}
				else
				{
					line += *p_in++;
				}
			}
		}
		// Skip any CRs, LF, or totally blank lines
		while (*p_in == 0x0d || *p_in ==0x0a)
		{
			p_in++;
		}


		if (line.empty())
		{
		//	debug_log ("SKIPPED: <%s>",skipped.data());
		}
		else
		{
			line = string(" ") + line;
			// PARSE A LINE into a vector of words
			line += ' ';	// add a space first so things will be delimited
//			transform(line.begin(),line.end(), line.begin(),tolower);
			debug_log ("LINE: <%s>",line.data());

			// "decorating" means that new things like petals are not part of the selection group
			// so the selection group remains unchanged
			// NOTE: This DOES NOT WORK, since we still want to modify in the local context of the line
			// so we want to be able to change the petal colors with modifier on the decorator line.
			bool	decorating = false;

			// Loop over the tokens in the line, parsing them until they are all gone
			CTokenizer tokenizer(line);
			string token = tokenizer.NextToken();
			while (!token.empty())
			{

				// PARSE A TOKEN
				// WHAT HAPPENS HERE DEPENDS ON THE STATE\

				if (token == string("decorate"))
				{
					decorating = true;
				}

				// First check to see if it is one of our atomic objects, like a circle
				if (token == string("circle"))
				{
					debug_log("NEW CIRCLE");
					// Create a new circle, and add it to the end of the list
					CWhim *p_whim = new CCircle();
					Add(p_whim);
					// The collection's parse context should now be the things we just added
					// So erase any existing parse context
					if (!grouping)
						m_parse_context.clear();
					// and add the new object
					m_parse_context.push_back(p_whim);

				}

				// First check to see if it is one of our atomic objects, like a circle
				if (token == string("superegg") || token == string("superellipse"))
				{
					debug_log("NEW SUPERELLIPSE");
					float	a = (float)atof(tokenizer.NextToken().data());
					float	b = (float)atof(tokenizer.NextToken().data());
					float	r = (float)atof(tokenizer.NextToken().data());
					if (r == 0.0f)
					{
						r = 2.5f;  // traditional superegg
					}
					// Create a new circle, and add it to the end of the list
					CWhim *p_whim = new CSuperEgg(a,b,r);
					Add(p_whim);
					// The collection's parse context should now be the things we just added
					// So erase any existing parse context
					if (!grouping)
						m_parse_context.clear();
					// and add the new object
					m_parse_context.push_back(p_whim);

				}

				// First check to see if it is one of our atomic objects, like a circle
				if (token == string("rectangle"))
				{
					debug_log("NEW RECTANGLE");
					// Create a new circle, and add it to the end of the list
					CWhim *p_whim = new CRectangle();
					Add(p_whim);
					// The collection's parse context should now be the things we just added
					// So erase any existing parse context
					if (!grouping)
						m_parse_context.clear();
					// and add the new object
					m_parse_context.push_back(p_whim);
				}

				if (token == string("color"))
				{
					string name = tokenizer.NextToken();
					int	r = atoi(tokenizer.NextToken().data());
					int	g = atoi(tokenizer.NextToken().data());
					int	b = atoi(tokenizer.NextToken().data());
					CWhim *p_whim = new CColor(name, (r<<16) | (g<<8) | b);
					debug_log("NEW COLOR %s, %d,%d,%d",name,r,g,b);
					Add(p_whim);
					// Does not do anything to the parse context
				}

				if (token == string("petals"))
				{
					debug_log("NEW PETALS");
					int petals = atoi(tokenizer.NextToken().data());
					float	spacing = (float)atof(tokenizer.NextToken().data());
					if (spacing == 0.0f)
					{
						tokenizer.Back();
					}
					// Create a new circle, and add it to the end of the list
					vector<CWhim*>::iterator i;
					vector<CWhim*> new_whims;
					for (i=m_parse_context.begin();i!=m_parse_context.end();++i)
					{
						

						for (int p = 0; p<petals; p++)
						{
							CWhim *p_petal_whim = new CPetal((*i),((float)p+0.5f*spacing) * 1.0f/petals, ((float)p+1.0f-0.5f*spacing)*1.0f/petals,1.5f);
							Add(p_petal_whim);
							new_whims.push_back(p_petal_whim);
						}
					}
					if (!decorating)
					{
						m_parse_context = new_whims;
					}
				}

				// Inner outline
				if (token == string("inner"))
				{
					debug_log("NEW INNER");
					float ratio = (float)atof(tokenizer.NextToken().data());
					float varience = (float)atof(tokenizer.NextToken().data());
					vector<CWhim*> new_whims;
					// Create a new circle, and add it to the end of the list
					vector<CWhim*>::iterator i;
					for (i=m_parse_context.begin();i!=m_parse_context.end();++i)
					{
						CWhim *p_inner_whim = new CInner((*i),ratio, varience, rndf(1.0f));
						Add(p_inner_whim);
						new_whims.push_back(p_inner_whim);
					}
					if (!decorating)
					{
						m_parse_context = new_whims;
					}
				}

				if (token == string("group"))
				{
					grouping = true;
				}

				if (token == string("endgroup"))
				{
					grouping = false;
				}


				debug_log ("Token [%s]",token.data());
				token = tokenizer.NextToken();
			}

			// Loop again for modifiers
			tokenizer.Reset();
			token = tokenizer.NextToken();
			while (!token.empty())
			{

				// PARSE A TOKEN
				// WHAT HAPPENS HERE DEPENDS ON THE STATE\

				if (token == string("larger"))
				{
					debug_log("MODIFY LARGER");
					vector<CWhim*>::iterator i;
					for (i=m_parse_context.begin();i!=m_parse_context.end();++i)
					{
						(*i)->Larger();
					}
				}

				if (token == string("size"))
				{
					debug_log("MODIFY SIZE");
					float scale = (float)atof(tokenizer.NextToken().data());
					vector<CWhim*>::iterator i;
					for (i=m_parse_context.begin();i!=m_parse_context.end();++i)
					{
						(*i)->Resize(scale);
					}
				}


				if (token == string("at"))
				{
					float x = (float)atof(tokenizer.NextToken().data());
					float y = (float)atof(tokenizer.NextToken().data());
					//vector<CWhim*>::iterator i;
					//for (i=m_parse_context.begin();i!=m_parse_context.end();++i)
					//{
					m_parse_context.back()->SetPosition(Vector2(x,y));
					//}
				}


				// a distortion takes the parse context, and hides it, creating a new set of objects that
				// are simple "inners" of the parent object
				if (token == string("distort"))
				{
					debug_log("MODIFY DISTORT");
					debug_log("NEW INNER");
					float varience = (float)atof(tokenizer.NextToken().data());
					vector<CWhim*> new_whims;
					// Create a new circle, and add it to the end of the list
					vector<CWhim*>::iterator i;
					for (i=m_parse_context.begin();i!=m_parse_context.end();++i)
					{
						// Note the ratio is 1.0f, as we are just replacing one thing with another
						CWhim *p_inner_whim = new CInner((*i),1.0f, varience, rndf(1.0f));
						Add(p_inner_whim);
						new_whims.push_back(p_inner_whim);
						(*i)->Hide();
					}
					m_parse_context = new_whims;
				}



				// Iterate over the other whimsys, see if this token is one of them like a color
				// (or maybe later, a macro)
				
				
				vector<CWhim*>::iterator other;
				for (other=m_whims.begin();other!=m_whims.end();++other)
				{
					if ((*other)->GetName() == token)
					{
						debug_log ("Token [%s] matches existing",token.data());
						if ((*other)->GetType() == WHIM_COLOR)
						{
							vector<CWhim*>::iterator i;
							for (i=m_parse_context.begin();i!=m_parse_context.end();++i)
							{
								(*i)->SetColor((*other)->GetColor());
							}
						}
					}
				}

// tail of loop
				debug_log ("Token [%s]",token.data());
				token = tokenizer.NextToken();


			}



		}

	}

	// Dump out the whims
	vector<CWhim*>::iterator other;
	int a = 0;
	for (other=m_whims.begin();other!=m_whims.end();++other,++a)
	{
		(*other)->DebugDump();
	}



	// A line will either:
	// 1 - Create a new whimsy (with optional modifers), which becomes the new working set
	// 2 - Modify the working set
	// 3 - Change the working set (like, choose a previous identifier).


::CloseHandle(hMappedInFile);
::CloseHandle(hInFile);
}

void CCollection::RenderAll()
{
	vector<CWhim*>::iterator i;
	for (i=m_whims.begin();i!=m_whims.end();++i)
	{
		if ((*i)->IsRenderable())
			(*i)->Render();
	}

}


CCollection	g_world;

void	WhimsyInit()
{
//	tokens["Hello"] = 0;

	// we set up a bunch of defaults first

#if 0
	// Add the 16 default HTML 4.01 colors to give us a starting point
	g_world.Add(new CColor("aqua", 0x00ffff));
	g_world.Add(new CColor("gray", 0x808080));
	g_world.Add(new CColor("navy", 0x000080));
	g_world.Add(new CColor("silver", 0xc0c0c0));
	g_world.Add(new CColor("black", 0x000000));
	g_world.Add(new CColor("green", 0x008000));
	g_world.Add(new CColor("olive", 0x808000));
	g_world.Add(new CColor("teal", 0x008080));
	g_world.Add(new CColor("blue", 0x0000ff));
	g_world.Add(new CColor("lime", 0x00ff00));
	g_world.Add(new CColor("purple", 0x800080));
	g_world.Add(new CColor("white", 0xffffff));
	g_world.Add(new CColor("fuchsia", 0xff00ff));
	g_world.Add(new CColor("maroon", 0x800000));
	g_world.Add(new CColor("red", 0xff0000));
	g_world.Add(new CColor("yellow", 0xffff00));
#else
	// Or add all the CSS3 colors
	g_world.Add(new CColor("aliceblue", 0xf0f8ff));
	g_world.Add(new CColor("antiquewhite", 0xfaebd7));
	g_world.Add(new CColor("aqua", 0x00ffff));
	g_world.Add(new CColor("aquamarine", 0x7fffd4));
	g_world.Add(new CColor("azure", 0xf0ffff));
	g_world.Add(new CColor("beige", 0xf5f5dc));
	g_world.Add(new CColor("bisque", 0xffe4c4));
	g_world.Add(new CColor("black", 0x000000));
	g_world.Add(new CColor("blanchedalmond", 0xffebcd));
	g_world.Add(new CColor("blue", 0x0000ff));
	g_world.Add(new CColor("blueviolet", 0x8a2be2));
	g_world.Add(new CColor("brown", 0xa52a2a));
	g_world.Add(new CColor("burlywood", 0xdeb887));
	g_world.Add(new CColor("cadetblue", 0x5f9ea0));
	g_world.Add(new CColor("chartreuse", 0x7fff00));
	g_world.Add(new CColor("chocolate", 0xd2691e));
	g_world.Add(new CColor("coral", 0xff7f50));
	g_world.Add(new CColor("cornflowerblue", 0x6495ed));
	g_world.Add(new CColor("cornsilk", 0xfff8dc));
	g_world.Add(new CColor("crimson", 0xdc143c));
	g_world.Add(new CColor("cyan", 0x00ffff));
	g_world.Add(new CColor("darkblue", 0x00008b));
	g_world.Add(new CColor("darkcyan", 0x008b8b));
	g_world.Add(new CColor("darkgoldenrod", 0xb8860b));
	g_world.Add(new CColor("darkgray", 0xa9a9a9));
	g_world.Add(new CColor("darkgreen", 0x006400));
	g_world.Add(new CColor("darkgrey", 0xa9a9a9));
	g_world.Add(new CColor("darkkhaki", 0xbdb76b));
	g_world.Add(new CColor("darkmagenta", 0x8b008b));
	g_world.Add(new CColor("darkolivegreen", 0x556b2f));
	g_world.Add(new CColor("darkorange", 0xff8c00));
	g_world.Add(new CColor("darkorchid", 0x9932cc));
	g_world.Add(new CColor("darkred", 0x8b0000));
	g_world.Add(new CColor("darksalmon", 0xe9967a));
	g_world.Add(new CColor("darkseagreen", 0x8fbc8f));
	g_world.Add(new CColor("darkslateblue", 0x483d8b));
	g_world.Add(new CColor("darkslategray", 0x2f4f4f));
	g_world.Add(new CColor("darkslategrey", 0x2f4f4f));
	g_world.Add(new CColor("darkturquoise", 0x00ced1));
	g_world.Add(new CColor("darkviolet", 0x9400d3));
	g_world.Add(new CColor("deeppink", 0xff1493));
	g_world.Add(new CColor("deepskyblue", 0x00bfff));
	g_world.Add(new CColor("dimgray", 0x696969));
	g_world.Add(new CColor("dimgrey", 0x696969));
	g_world.Add(new CColor("dodgerblue", 0x1e90ff));
	g_world.Add(new CColor("firebrick", 0xb22222));
	g_world.Add(new CColor("floralwhite", 0xfffaf0));
	g_world.Add(new CColor("forestgreen", 0x228b22));
	g_world.Add(new CColor("fuchsia", 0xff00ff));
	g_world.Add(new CColor("gainsboro", 0xdcdcdc));
	g_world.Add(new CColor("ghostwhite", 0xf8f8ff));
	g_world.Add(new CColor("gold", 0xffd700));
	g_world.Add(new CColor("goldenrod", 0xdaa520));
	g_world.Add(new CColor("gray", 0x808080));
	g_world.Add(new CColor("green", 0x008000));
	g_world.Add(new CColor("greenyellow", 0xadff2f));
	g_world.Add(new CColor("grey", 0x808080));
	g_world.Add(new CColor("honeydew", 0xf0fff0));
	g_world.Add(new CColor("hotpink", 0xff69b4));
	g_world.Add(new CColor("indianred", 0xcd5c5c));
	g_world.Add(new CColor("indigo", 0x4b0082));
	g_world.Add(new CColor("ivory", 0xfffff0));
	g_world.Add(new CColor("khaki", 0xf0e68c));
	g_world.Add(new CColor("lavender", 0xe6e6fa));
	g_world.Add(new CColor("lavenderblush", 0xfff0f5));
	g_world.Add(new CColor("lawngreen", 0x7cfc00));
	g_world.Add(new CColor("lemonchiffon", 0xfffacd));
	g_world.Add(new CColor("lightblue", 0xadd8e6));
	g_world.Add(new CColor("lightcoral", 0xf08080));
	g_world.Add(new CColor("lightcyan", 0xe0ffff));
	g_world.Add(new CColor("lightgoldenrodyellow", 0xfafad2));
	g_world.Add(new CColor("lightgray", 0xd3d3d3));
	g_world.Add(new CColor("lightgreen", 0x90ee90));
	g_world.Add(new CColor("lightgrey", 0xd3d3d3));
	g_world.Add(new CColor("lightpink", 0xffb6c1));
	g_world.Add(new CColor("lightsalmon", 0xffa07a));
	g_world.Add(new CColor("lightseagreen", 0x20b2aa));
	g_world.Add(new CColor("lightskyblue", 0x87cefa));
	g_world.Add(new CColor("lightslategray", 0x778899));
	g_world.Add(new CColor("lightslategrey", 0x778899));
	g_world.Add(new CColor("lightsteelblue", 0xb0c4de));
	g_world.Add(new CColor("lightyellow", 0xffffe0));
	g_world.Add(new CColor("lime", 0x00ff00));
	g_world.Add(new CColor("limegreen", 0x32cd32));
	g_world.Add(new CColor("linen", 0xfaf0e6));
	g_world.Add(new CColor("magenta", 0xff00ff));
	g_world.Add(new CColor("maroon", 0x800000));
	g_world.Add(new CColor("mediumaquamarine", 0x66cdaa));
	g_world.Add(new CColor("mediumblue", 0x0000cd));
	g_world.Add(new CColor("mediumorchid", 0xba55d3));
	g_world.Add(new CColor("mediumpurple", 0x9370db));
	g_world.Add(new CColor("mediumseagreen", 0x3cb371));
	g_world.Add(new CColor("mediumslateblue", 0x7b68ee));
	g_world.Add(new CColor("mediumspringgreen", 0x00fa9a));
	g_world.Add(new CColor("mediumturquoise", 0x48d1cc));
	g_world.Add(new CColor("mediumvioletred", 0xc71585));
	g_world.Add(new CColor("midnightblue", 0x191970));
	g_world.Add(new CColor("mintcream", 0xf5fffa));
	g_world.Add(new CColor("mistyrose", 0xffe4e1));
	g_world.Add(new CColor("moccasin", 0xffe4b5));
	g_world.Add(new CColor("navajowhite", 0xffdead));
	g_world.Add(new CColor("navy", 0x000080));
	g_world.Add(new CColor("oldlace", 0xfdf5e6));
	g_world.Add(new CColor("olive", 0x808000));
	g_world.Add(new CColor("olivedrab", 0x6b8e23));
	g_world.Add(new CColor("orange", 0xffa500));
	g_world.Add(new CColor("orangered", 0xff4500));
	g_world.Add(new CColor("orchid", 0xda70d6));
	g_world.Add(new CColor("palegoldenrod", 0xeee8aa));
	g_world.Add(new CColor("palegreen", 0x98fb98));
	g_world.Add(new CColor("paleturquoise", 0xafeeee));
	g_world.Add(new CColor("palevioletred", 0xdb7093));
	g_world.Add(new CColor("papayawhip", 0xffefd5));
	g_world.Add(new CColor("peachpuff", 0xffdab9));
	g_world.Add(new CColor("peru", 0xcd853f));
	g_world.Add(new CColor("pink", 0xffc0cb));
	g_world.Add(new CColor("plum", 0xdda0dd));
	g_world.Add(new CColor("powderblue", 0xb0e0e6));
	g_world.Add(new CColor("purple", 0x800080));
	g_world.Add(new CColor("red", 0xff0000));
	g_world.Add(new CColor("rosybrown", 0xbc8f8f));
	g_world.Add(new CColor("royalblue", 0x4169e1));
	g_world.Add(new CColor("saddlebrown", 0x8b4513));
	g_world.Add(new CColor("salmon", 0xfa8072));
	g_world.Add(new CColor("sandybrown", 0xf4a460));
	g_world.Add(new CColor("seagreen", 0x2e8b57));
	g_world.Add(new CColor("seashell", 0xfff5ee));
	g_world.Add(new CColor("sienna", 0xa0522d));
	g_world.Add(new CColor("silver", 0xc0c0c0));
	g_world.Add(new CColor("skyblue", 0x87ceeb));
	g_world.Add(new CColor("slateblue", 0x6a5acd));
	g_world.Add(new CColor("slategray", 0x708090));
	g_world.Add(new CColor("slategrey", 0x708090));
	g_world.Add(new CColor("snow", 0xfffafa));
	g_world.Add(new CColor("springgreen", 0x00ff7f));
	g_world.Add(new CColor("steelblue", 0x4682b4));
	g_world.Add(new CColor("tan", 0xd2b48c));
	g_world.Add(new CColor("teal", 0x008080));
	g_world.Add(new CColor("thistle", 0xd8bfd8));
	g_world.Add(new CColor("tomato", 0xff6347));
	g_world.Add(new CColor("turquoise", 0x40e0d0));
	g_world.Add(new CColor("violet", 0xee82ee));
	g_world.Add(new CColor("wheat", 0xf5deb3));
	g_world.Add(new CColor("white", 0xffffff));
	g_world.Add(new CColor("whitesmoke", 0xf5f5f5));
	g_world.Add(new CColor("yellow", 0xffff00));
	g_world.Add(new CColor("yellowgreen", 0x9acd32));


#endif

}

void	WhimsyParse()
{
	g_world.Parse("lunar.whimsy");
}

void	WhimsyRender()
{
	g_world.RenderAll();
}
