// Copyright (c) 2010 Luis Semp�
// http://www.luissempe.com
//
// Permission is hereby granted, free of charge, to any person
// obtaining a copy of this software and associated documentation
// files (the "Software"), to deal in the Software without
// restriction, including without limitation the rights to use,
// copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the
// Software is furnished to do so, subject to the following
// conditions:
//
// The above copyright notice and this permission notice shall be
// included in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
// OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
// NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
// HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
// WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
// FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
// OTHER DEALINGS IN THE SOFTWARE.

#include "BaseStateData.h"

#include "StateActionData.h"
#include "StateQueryData.h"

BaseStateData::BaseStateData(StateType type)
: mType(type)
{
}

BaseStateData::~BaseStateData()
{
}

///
/// Load will parse the XML data in the provided element and use the element's value as the 
/// class name to instantiate the proper class.
///
/*static */BaseStateData* StateDataFactory::Load(TiXmlElement* element)
{
	if ( element )
	{
		const char* className = element->Value();
		
		if ( strcmp(className, "StateActionData") == 0 )
		{
			StateActionData* stateData = new StateActionData();			
			stateData->Load(element->FirstChild());
			return stateData;
		}
		else
		if ( strcmp(className, "StateQueryData") == 0 )
		{
			StateQueryData* stateData = new StateQueryData();			
			stateData->Load(element->FirstChild());
			return stateData;
		}
	}

	return 0;
}

///
/// Same as Load(TiXmlElement* element) but will load from the provided file
///
/*static */BaseStateData* StateDataFactory::Load(const char* filename)
{
	TiXmlDocument document(filename);
	if ( document.LoadFile() )
	{
		TiXmlHandle handleDocument(&document);
		TiXmlElement* element = handleDocument.FirstChildElement().Element();

		Load(element);
	}
	document.Clear();

	return 0;
}