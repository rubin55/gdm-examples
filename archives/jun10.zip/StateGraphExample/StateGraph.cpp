// Copyright (c) 2010 Luis Semp�
// http://www.luissempe.com
//
// Permission is hereby granted, free of charge, to any person
// obtaining a copy of this software and associated documentation
// files (the "Software"), to deal in the Software without
// restriction, including without limitation the rights to use,
// copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the
// Software is furnished to do so, subject to the following
// conditions:
//
// The above copyright notice and this permission notice shall be
// included in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
// OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
// NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
// HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
// WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
// FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
// OTHER DEALINGS IN THE SOFTWARE.

#include "StateGraph.h"
#include "StateFactory.h"
#include "BaseState.h"
#include "StateGraphData.h"

StateGraph::StateGraph(StateGraphData* data)
: m_graphData(data)
, m_nextStateIndex(-1)
, m_currentState(0)
, m_previousState(0)
{
}

StateGraph::~StateGraph()
{
}

void StateGraph::Start(int startStateIndex)
{
	// Create the starting state from the provided index
	m_currentState = StateFactory::Create( &m_graphData->mStateList[startStateIndex], this );
}

void StateGraph::Stop()
{
}

StateGraph::Status StateGraph::Process()
{
	// If the state has changed since the last frame, we need to enter it
	if ( m_currentState != m_previousState )
	{
		m_currentState->OnEntry();
		m_previousState = m_currentState;
	}

	// if the state returns Done, we will exit it and find the next state if there is one available
	if ( m_currentState->Process() == BaseState::Done )
	{
		m_currentState->OnExit();

		m_currentState = GetNextState();
	}

	// If we don't have a current state, the graph has completed running
	if ( !m_currentState )
		return StateGraph::Done;

	// Continue to the next frame
	return StateGraph::Processing;
}

BaseState* StateGraph::GetNextState()
{
	const State* stateData = m_currentState->GetData();
	if ( m_nextStateIndex < 0 )
	{
		if ( stateData->mNumTransitions == 1 )
			m_nextStateIndex = stateData->mTransitions[0]->DestStateIndex;
		else
		if ( stateData->mNumTransitions > 1 )
		{
			// If there are many transitions to take and we are not sure which one, pick a random one.
			// (note that this behavior may not always be desired)
			int randomIndex = rand() % (stateData->mNumTransitions);
			m_nextStateIndex = stateData->mTransitions[randomIndex]->DestStateIndex;
		}
	}

	if ( m_nextStateIndex >= 0 )
	{
		delete m_currentState;		
		
		BaseState* nextState = StateFactory::Create( &m_graphData->mStateList[ m_nextStateIndex ], this );

		m_previousState = 0;
		m_currentState = 0;
		m_nextStateIndex = -1;

		return nextState;
	}

	delete m_currentState;
	m_currentState = 0;

	// If we got here, there is nothing more to do
	return 0;
}

void StateGraph::SetNextState(int stateIndex)
{
	m_nextStateIndex = stateIndex;
}

void StateGraph::Notify(StateGraphEvent& event)
{
	if ( m_currentState )
		m_currentState->HandleEvent(event);
}
