// Copyright (c) 2010 Luis Semp�
// http://www.luissempe.com
//
// Permission is hereby granted, free of charge, to any person
// obtaining a copy of this software and associated documentation
// files (the "Software"), to deal in the Software without
// restriction, including without limitation the rights to use,
// copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the
// Software is furnished to do so, subject to the following
// conditions:
//
// The above copyright notice and this permission notice shall be
// included in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
// OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
// NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
// HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
// WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
// FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
// OTHER DEALINGS IN THE SOFTWARE.

#pragma once

#include "StateTypes.h"
#include "tinyxml/tinyxml.h"
#include "BaseStateData.h"

static const int kMAX_TRANSITIONS_PER_STATE = 10;

struct Transition
{
	int SourceStateIndex;
	int DestStateIndex;
};

class State
{
public:

	StateType		mType;
	void*			mStateData;
	Transition*		mTransitions[kMAX_TRANSITIONS_PER_STATE];
	int				mNumTransitions;
	char			mName[80];

	State()
		: mType(StateType_Invalid)
		, mStateData(0)		
		, mNumTransitions(0)
	{
		mName[0] = '\0';
	}
};

class StateGraphData
{
public:

	State*		mStateList;
	int			mNumStates;
	Transition* mTransitionList;
	int			mNumTransitions;

	StateGraphData() 
		: mStateList(0)
		, mNumStates(0)
		, mTransitionList(0)
		, mNumTransitions(0)
	{}

	~StateGraphData()
	{
		delete [] mStateList;
		delete [] mTransitionList;
	}

	static int GetStateIndex(StateGraphData* data, const char* stateName)
	{
		for ( int i = 0; i < data->mNumStates; ++i )
		{
			if ( _stricmp( data->mStateList[i].mName, stateName ) == 0 )
			{
				return i;
			}
		}
		return -1;
	}

	static int CountSiblings(TiXmlNode* node)
	{
		int siblings = 0;
		TiXmlNode* n = node;
		while ( n )
		{
			++siblings;
			n = n->NextSibling();
		}
		return siblings;
	}
	
	static StateGraphData* Load(const char* filename)
	{		
		StateGraphData* stateGraphData = 0;

		TiXmlDocument document;
		if ( document.LoadFile(filename) )
		{
			stateGraphData = new StateGraphData();

			TiXmlNode* node = document.RootElement();
		
			const char* key = node->Value();
			if ( _stricmp(key, "StateGraph") == 0 )
			{
				node = node->FirstChild();
				
				while ( node )
				{										
					// States
					if ( _stricmp( node->Value(), "StateList") == 0 )
					{
						TiXmlNode* child = node->FirstChild();

						int numStates = CountSiblings( child );
						if ( numStates > 0 )
						{
							stateGraphData->mNumStates = numStates;
							stateGraphData->mStateList = new State[ numStates ];
							
							int stateIndex = 0;
							TiXmlNode *stateNode = child;
							while ( stateNode )
							{
								BaseStateData* stateData = StateDataFactory::Load(stateNode->FirstChildElement());								
								stateGraphData->mStateList[ stateIndex ].mType = stateData->GetType();
								strcpy_s( stateGraphData->mStateList[ stateIndex ].mName, sizeof(stateGraphData->mStateList[ stateIndex ].mName), stateNode->ToElement()->FirstAttribute()->Value() );

								stateGraphData->mStateList[ stateIndex ].mStateData = stateData;
								
								++stateIndex;

								stateNode = stateNode->NextSibling();
							}
						}
					}

					// Transitions
					if ( _stricmp( node->Value(), "TransitionList") == 0 )
					{
						TiXmlNode* child = node->FirstChild();

						int numTransitions = CountSiblings( child );

						if ( numTransitions > 0 )
						{
							stateGraphData->mNumTransitions = numTransitions;
							stateGraphData->mTransitionList = new Transition[ numTransitions ];

							int transitionIndex = 0;
							TiXmlNode* transitionNode = node->FirstChild();
							while ( transitionNode )
							{
								TiXmlElement* transitionChild = transitionNode->FirstChildElement();

								while ( transitionChild )
								{
									if ( _stricmp(transitionChild->Value(), "Source") == 0 )
									{
										const char* sourceStateName = transitionChild->FirstChild()->Value();									
										
										int sourceStateIndex = GetStateIndex(stateGraphData, sourceStateName);
										stateGraphData->mTransitionList[ transitionIndex ].SourceStateIndex = sourceStateIndex;

										State* sourceState = &stateGraphData->mStateList[ sourceStateIndex ];
										
										if ( sourceState->mNumTransitions + 1 < kMAX_TRANSITIONS_PER_STATE )
											sourceState->mTransitions[ sourceState->mNumTransitions++ ] = &stateGraphData->mTransitionList[ transitionIndex ];
									}

									if ( _stricmp(transitionChild->Value(), "Destination") == 0 )
									{
										const char* destState = transitionChild->FirstChild()->Value();
										stateGraphData->mTransitionList[ transitionIndex ].DestStateIndex = GetStateIndex(stateGraphData, destState);
									}

									transitionChild = transitionChild->NextSiblingElement();
								}

								++transitionIndex;
								transitionNode = transitionNode->NextSibling();
							}
						}
					}					
					
					node = node->NextSibling();
				}								
			}					
		}		

		return stateGraphData;
	}
};