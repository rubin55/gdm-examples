// Copyright (c) 2010 Luis Semp�
// http://www.luissempe.com
//
// Permission is hereby granted, free of charge, to any person
// obtaining a copy of this software and associated documentation
// files (the "Software"), to deal in the Software without
// restriction, including without limitation the rights to use,
// copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the
// Software is furnished to do so, subject to the following
// conditions:
//
// The above copyright notice and this permission notice shall be
// included in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
// OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
// NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
// HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
// WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
// FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
// OTHER DEALINGS IN THE SOFTWARE.

#pragma once

#include "tinyxml/tinyxml.h"

#include <string>
#include <map>

/*
//
// Persitent
//
// The Persitent is an easy to implement mechanism that binds XML to a C++ class.
// It is limited to an XML format that corresponds with the layout of the class
// as described in the Register function via the REGISTER and REGISTER_ALTERNATE macros.
//
// It is important to note that there will be a memory overhead in each instance of this class, as each instance
// will keep its own map where it binds a text name to the pointer to the data member of the class.
//
// Example use:
//
// class Example : public Persitent
// {
//		int integer_value;
//
// public:
//		PERSISTENT_DECL(Example);
//		virtual void Register()
//		{
//			REGISTER(integer_value, PT_int);
//		}
// }
//
// Here, an XML in this form would be properly loaded:
//
// <Example> <!-- this can be anything, we just need a root level tag -->
//		<integer_value>42</integer_value>
// </Example>
//
// Passing in that XML text to Example.Load( xmlText ); would initialize the value of the
// member variable integer_value to 42.
//
// REGISTER: will bind a member variable's name to the member variable
// REGISTER_ALTERNATE: this can be used in cases in which the member variable name must differ from the name used to register it.
//
*/

enum PrimitiveType
{
	  PT_int
	, PT_string
	, PT_bool
	, PT_color
	, PT_INVALID
};

struct PersistentData {

	PrimitiveType m_type;
	void* m_memberPtr;
	
	PersistentData(): m_memberPtr(0), m_type(PT_INVALID)
	{}

	PersistentData(PrimitiveType type, void* memberPtr)
		: m_type(type)
		, m_memberPtr(memberPtr)
	{}

	PersistentData(const PersistentData& d)
	{
		m_memberPtr = d.m_memberPtr;
		m_type = d.m_type;
	}
};

#define REGISTER(member, primitiveType) ms_typeMap[#member] = PersistentData(primitiveType, &member);
#define REGISTER_ALTERNATE(member, typeName, primitiveType) ms_typeMap[#typeName] = PersistentData(primitiveType, &member);

#define PERSISTENT_DECL(className) \
	PersistentTypeMap ms_typeMap; \
	virtual PersistentTypeMap& GetTypeMap() { return ms_typeMap; }


class Persistent
{
public:
	
	Persistent() : mRegistered(false) {}
	virtual ~Persistent() {}
	
	// Derived classes must implement Register to bind member variables to XML
	virtual void Register() = 0;

	virtual void Load(const char* xml);
	virtual void Load(TiXmlNode* root);

	virtual void LoadFromFile(const char* filename);

protected:

	typedef std::map<std::string, PersistentData> PersistentTypeMap;
	virtual PersistentTypeMap& GetTypeMap() = 0;

	bool mRegistered;
};
