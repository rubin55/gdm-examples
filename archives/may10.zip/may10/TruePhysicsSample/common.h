//impliments common/abstract structures, such as physics state and force models, as well as a simple spring model.
//The spring model represents a mass M attached to the origin by a spring with constant K

#include "math.h"
#pragma once

namespace TruePhysicsSample
{
	//The State represents the dynamical state of a physical object
	struct State
	{
		Vector pos;
		Vector vel;

		//function to zero the state vectors
		void Zero()
		{
			pos.Zero();
			vel.Zero();
		}
	};

	//A force model is an abstract representation of a force.  The force model in this sample
	//allows any integration technique to query the information pertinent
	class ForceModel
	{
	public:

		//Not all integration techniques require the force to know about the size
		//of the timeStep, but the true physics technique can benifit from precalculation
		//which may involve the time step
		FLOAT deltaT;
		FLOAT invMass;

		//constructure
		ForceModel()
		{
			deltaT = 0.0f;
			invMass = 0.0f;
		}

		//initialize force model variables
		void Init(FLOAT mass, FLOAT delta)
		{
			deltaT = delta;
			invMass = 1.0f / mass;
		}

		//abstract methods for the different integration techniques to query the force
		virtual Vector CalcAcceleration(const State& state, FLOAT time) = 0;
		virtual void AccumulateAcceleration(const State& state, FLOAT time, Vector& accel) = 0;
		virtual void CalcDxDv(const State& state, FLOAT time, Vector& dx, Vector& dv) = 0;
		virtual void AccumulateDxDv(const State& state, FLOAT time, Vector& dx, Vector& dv) = 0;
	};

	//The spring force is a well known and solvable force.  We extend the spring force from the force model interface
	class SpringForce : public ForceModel
	{
		//These variables store the coefficients used to calculate the dx and dv for the true physics method
		FLOAT a1;
		FLOAT a2;
		FLOAT a3;

	public:
		
		//omega is the angular frequency of the spring, related to k and m.
		FLOAT omega;
		FLOAT k;

		//constructor
		SpringForce()
			: ForceModel()
		{
			omega = 0.0f;
			k = 0.0f;
		}

		//Initialize the spring by pre-calculating all of the necessary variables
		void InitSpring(FLOAT springK)
		{
			k = springK;

			//precalculate the coefficients of pos and vel
			omega = sqrt(springK * invMass);
			FLOAT angle = omega*deltaT;
			FLOAT s = sin(angle);
			FLOAT c = cos(angle);

			a1 = (FLOAT)(c - 1.0);
			a2 = (FLOAT)(s * omega);
			a3 = (FLOAT)(s / omega - (FLOAT)deltaT);
		}

		virtual Vector CalcAcceleration(const State& state, FLOAT time)
		{
			return state.pos*(-k * invMass);
		}

		virtual void AccumulateAcceleration(const State& state, FLOAT time, Vector& accel)
		{
			accel -= state.pos*(k * invMass);
		}

		virtual void CalcDxDv(const State& state, FLOAT time, Vector& dx, Vector& dv)
		{
			dx = state.pos * a1 + state.vel * a3;
			dv = state.vel * a1 - state.pos * a2;
		}

		virtual void AccumulateDxDv(const State& state, FLOAT time, Vector& dx, Vector& dv)
		{
			dx += state.pos * a1 + state.vel * a3;
			dv += state.vel * a1 - state.pos * a2;
		}

		//This function represents the motion of a non-integrated spring of constant k at time t, given an initial state.
		State ExactSpring(const State& initialState, FLOAT k, FLOAT time)
		{
			State ret;

			FLOAT w = sqrt(k * invMass);
			FLOAT s = sin(w * time);
			FLOAT c = cos(w * time);

			ret.pos = initialState.vel * (s / omega) + initialState.pos * c;
			ret.vel = initialState.vel * c - initialState.pos * omega * s;

			return ret;
		}
	};

	//A physics object stores a dynamical state, a mass, and references forces acting on it.
	class PhysicsObject
	{
	public:
		State state;
		FLOAT mass;

		ForceModel* forces[4];

		PhysicsObject(const State& initialState, FLOAT m)
		{
			state = initialState;
			mass = m;

			forces[0] = forces[1] = forces[2] = forces[3] = 0;
		}

		//Acceleration is the sum of all of the forces acting
		Vector CalcAcceleration(FLOAT time) const
		{
			Vector accel;

			accel.Zero();

			for(int i = 0; i < 4; i++)
			{
				if(forces[i] != 0)
					forces[i]->AccumulateAcceleration(state, time, accel);
			}

			return accel;
		}

		//Accumulating the integral contributions dx and dv is an approximation that seems to be
		//a reasonably good approximation.  However, summing of dx's and dv's is only truly valid
		//under certain circumstances
		void CalcDxDv(FLOAT time, Vector& dx, Vector& dv) const
		{
			for(int i = 0; i < 4; i++)
			{
				if(forces[i] != 0)
					forces[i]->AccumulateDxDv(state, time, dx, dv);
			}
		}
	};
};