//This true physics sample can be used to calculate the trajectory and error
//of several different integration techniques, including the TruePhysics technique

#include "Euler.h"
#include "RK4.h"
#include "TruePhysics.h"

#include <stdio.h>

using namespace TruePhysicsSample;

#define TIMESTEP	(1.0f / 60.0f)
#define MASS		10.0f
#define SPRINGK		100.0f
#define AMPLITUDE	5.0f

int main(int argc, char** argv)
{
	//initialize the integrator objects
	RK4 rk4 = RK4(TIMESTEP);
	Euler euler = Euler(TIMESTEP);
	TruePhysics truePhysics = TruePhysics(TIMESTEP);

	truePhysics.average = true;

	//initialize the spring force
	SpringForce spring;

	spring.Init(MASS, TIMESTEP);
	spring.InitSpring(SPRINGK);

	//create the initial state
	State initialState;

	initialState.pos = Vector(AMPLITUDE, 0.0f, 0.0f);
	initialState.vel.Zero();

	//create a physics object for RK4 to act on - attach some forces
	PhysicsObject rk4Obj = PhysicsObject(initialState, MASS);
	rk4Obj.forces[0] = &spring;
	rk4Obj.forces[1] = &spring;

	//create a physics object for Euler to act on - attach some forces
	PhysicsObject eulerObj = PhysicsObject(initialState, MASS);
	eulerObj.forces[0] = &spring;
	eulerObj.forces[1] = &spring;

	//create a physics object for TruePhysics to act on - attach some forces
	PhysicsObject truePhysicsObj = PhysicsObject(initialState, MASS);
	truePhysicsObj.forces[0] = &spring;
	truePhysicsObj.forces[1] = &spring;

	FLOAT t = 0.0f;

	FILE* f = fopen("data.csv", "w");

	FLOAT rk4ErrMax = 0.0f;
	FLOAT eulerErrMax = 0.0f;
	FLOAT truePhysicsErrMax = 0.0f;

	//step the physics objects forward in time for 1000 steps
	for(int i = 0; i < 10000; i++)
	{
		//find the error in the x component
		Vector exactPos = spring.ExactSpring(initialState, 2.0f * SPRINGK, t).pos;

		FLOAT rk4Error = abs(rk4Obj.state.pos.x - exactPos.x) / AMPLITUDE;
		FLOAT eulerError = abs(eulerObj.state.pos.x - exactPos.x) / AMPLITUDE;
		FLOAT truePhysicsError = abs(truePhysicsObj.state.pos.x - exactPos.x) / AMPLITUDE;

		if(rk4Error > rk4ErrMax)
			rk4ErrMax = rk4Error;

		if(eulerError > eulerErrMax)
			eulerErrMax = eulerError;

		if(truePhysicsError > truePhysicsErrMax)
			truePhysicsErrMax = truePhysicsError;

		if((i % 1) == 0)
			fprintf(f, "%e, %e, %e, %e, %e, %e, %e\n", exactPos.x, rk4Obj.state.pos.x, eulerObj.state.pos.x, truePhysicsObj.state.pos.x, rk4ErrMax, eulerErrMax, truePhysicsErrMax);

		//step each object forward based on the given integration technique.
		rk4.takeStep(rk4Obj, t);
		euler.takeStep(eulerObj, t);
		truePhysics.takeStep(truePhysicsObj, t);

		t += TIMESTEP;
	}

	fclose(f);


	return 0;
}