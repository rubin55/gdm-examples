//Implements the RK4 technique.  As with the other integration techniques
//we are assuming in this sample that deltaT is fixed, and does not change.

#include "common.h"

namespace TruePhysicsSample
{
	class RK4
	{
	public:

		FLOAT deltaT;

		RK4(FLOAT delta)
		{
			deltaT = delta;
		}

		//helper function used to assist in evaluating the stepping equations
		State evaluate(const PhysicsObject& obj, FLOAT t, FLOAT dt, const State& deriv)
		{
			State tmp;
			tmp.pos = obj.state.pos + deriv.pos*dt;
			tmp.vel = obj.state.vel + deriv.vel*dt;

			State output;
			output.pos = tmp.vel;
			output.vel = obj.CalcAcceleration(t + dt);
			return output;
		}

		//RK4 technique progressing a physics object forward in time by deltaT
		void takeStep(PhysicsObject& obj, FLOAT t)
		{
			State initial;
			initial.Zero();

			State a = evaluate(obj, t, 0.0f, initial);
			State b = evaluate(obj, t + deltaT*0.5f, deltaT*0.5f, a);
			State c = evaluate(obj, t + deltaT*0.5f, deltaT*0.5f, b);
			State d = evaluate(obj, t + deltaT, deltaT, c);

			Vector dx = (a.pos + (b.pos + c.pos)*2.0f + d.pos) / 6.0f;
			Vector dv = (a.vel + (b.vel + c.vel)*2.0f + d.vel) / 6.0f;

			obj.state.pos += dx * deltaT;
			obj.state.vel += dv * deltaT;

		}
	};
};