//Impliments a simple 3D vector with add, subtract, and multiply by a scalar operations

#include <math.h>
#pragma once

#define FLOAT double

namespace TruePhysicsSample
{
	class Vector
	{
	public:
		float x;
		float y;
		float z;

		//empty constructor
		Vector()
		{
			x = y = z = 0.0f;
		}

		//copy constructor
		Vector(const Vector& vec)
		{
			x = vec.x;
			y = vec.y;
			z = vec.z;
		}

		//constructor to initialize components
		Vector(FLOAT X, FLOAT Y, FLOAT Z)
		{
			x = X; y = Y; z = Z;
		}


		//addition operator
		Vector operator+(const Vector& vec) const
		{
			return Vector(x + vec.x, y + vec.y, z + vec.z);
		}

		//self addition operator
		const Vector& operator+=(const Vector& vec)
		{
			x += vec.x;
			y += vec.y;
			z += vec.z;

			return *this;
		}

		//subtraction operator
		Vector operator-(const Vector& vec) const
		{
			return Vector(x - vec.x, y - vec.y, z - vec.z);
		}

		//self subtraction operator
		const Vector& operator-=(const Vector& vec)
		{
			x -= vec.x;
			y -= vec.y;
			z -= vec.z;

			return *this;
		}

		//multiplication by scalar
		Vector operator*(FLOAT scale) const
		{
			return Vector(x*scale, y*scale, z*scale);
		}

		//self multiplication by scalar
		const Vector& operator*=(FLOAT scale)
		{
			x *= scale;
			y *= scale;
			z *= scale;

			return *this;
		}

		//division by a scalar
		Vector operator/(FLOAT denom) const
		{
			return Vector(x/denom, y/denom, z/denom);
		}

		//self division by a scalar
		const Vector& operator/=(FLOAT denom)
		{
			x /= denom;
			y /= denom;
			z /= denom;
		}

		//zero the components
		void Zero()
		{
			x = y = z = 0.0f;
		}
	};
};