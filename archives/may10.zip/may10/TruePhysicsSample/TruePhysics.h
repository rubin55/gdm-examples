//Implements the TruePhysics technique.  As with the other integration techniques
//we are assuming in this sample that deltaT is fixed, and does not change.

#include "common.h"

namespace TruePhysicsSample
{
	class TruePhysics
	{
	public:
		FLOAT deltaT;

		//this variable switches between the exact method, and the average acceleration method
		bool average;

		TruePhysics(FLOAT delta)
		{
			deltaT = delta;
			average = false;
		}

		//TruePhysics technique progressing a physics object forward in time by deltaT
		void takeStep(PhysicsObject& obj, FLOAT t)
		{
			Vector dx, dv;

			dx.Zero();
			dv.Zero();

			obj.CalcDxDv(t, dx, dv);

			if(average)
				dx = dv * 0.5f * deltaT;

			obj.state.pos += obj.state.vel * deltaT + dx;
			obj.state.vel += dv;
		}
	};
};