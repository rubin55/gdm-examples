//Implements the Symplectic-Euler technique.  As with the other integration techniques
//we are assuming in this sample that deltaT is fixed, and does not change.

#include "common.h"

namespace TruePhysicsSample
{
	class Euler
	{
	public:

		FLOAT deltaT;

		Euler(FLOAT delta)
		{
			deltaT = delta;
		}

		//Symplectic-Euler technique progressing a physics object forward in time by deltaT
		void takeStep(PhysicsObject& obj, FLOAT t)
		{
			Vector accel = obj.CalcAcceleration(t);
			obj.state.vel += accel*deltaT;
			obj.state.pos += obj.state.vel*deltaT;
		}

	};
};