// Game Developer Magazine (April 2010) Sample Code:
//
// Author: Nicholas Vining (mordred@icculus.org)
//
// Somewhere, somebody should have a license agreement for this file.
//
// This implements the actor messaging loop for our Erlang-style message passing model. You will need a recent Boost
// install for this to work.
//
// Some general thoughts on the source code: in general, I'm pretty happy here. There are a few things that would be obvious
// improvements, and I will probably do them at some point:
//
// - we make a call to new() and a call to delete() every time we push (or pop) a message. This can get ugly fast, especially
// because we're busy being threadsafe. The correct thing to do would be to have a thread-safe, lock-free micro-allocator, but I don't
// even know if that exists.
//
// - this empty message passing thing could be better. In fact, there are some obvious improvements to the message passing system
// that could be made. Maybe boost::any<> is too heavy weight a class for use here.
//
// - The empty message could be behind some kind of const-safe barrier to stop you putting things in it. That's just laziness on my part. :)

#include "actor.h"

ActorManager *ActorManager::__p = NULL;				// This is the standard singleton thing that never cleans itself up.

boost::any EmptyMessage;			// Do NOT put anything in the empty message. I mean it!

ActorManager::ActorManager()
{

}

void ActorManager::AddActor( ActorTemplateBase *actor )
{
	actorQueueWriteMutex.lock();
	actorQueue.Produce(actor);
	actorQueueWriteMutex.unlock();
}

void ActorManager::PumpThreadLoop( int threadID )
{
	// in the thread loop

	__threadID = threadID;

	bool done = FALSE;

	while(!done)
	{
		actorQueueReadMutex.lock();
		ActorTemplateBase *t;
		bool success = actorQueue.Consume(t);
		actorQueueReadMutex.unlock();

		if (success && (t != NULL))
		{		
			{
				bool mustAddActor = t->PumpMessages();
				if (mustAddActor)
				{
					actorQueueWriteMutex.lock();

					// Okay, shove it back in the queue!

					actorQueue.Produce(t);

					actorQueueWriteMutex.unlock();
				}
			}
		}		
		else
		{
			done = TRUE;
		}
	}
}

void ActorManager::Go( int numThreads )
{
	// Spawn threads for the other threads

	for (int i = 0; i < numThreads-1; i++)
	{
		boost::thread b(&ActorManager::PumpThreadLoop, this, i);
	}

	// And take over myself.

	PumpThreadLoop(numThreads-1);
}