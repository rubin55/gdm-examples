#ifndef __LOCKFREEQUEUE_H_
#define __LOCKFREEQUEUE_H_

// Lock-free queue implementation. Based on Herb Sutter's September/October 2008 column in Dr. Dobb's Journal but with modifications
// to actually work without the atomic<> keyword.

#include <windows.h>							// required for interlock functions

// Shut up C++ typecast messages (32 bit)
#pragma warning (disable: 4311)
#pragma warning (disable: 4312)

template <typename T> class LockFreeQueue 
{
	private:

	struct Node 
	{
		Node( T val ) : value(val), next(NULL) { }
		T value;
		Node* next;
	};

	Node* first;			   // for producer only
	Node* divider;
	Node* last;         // shared

	public:
		
	LockFreeQueue(void) 
	{
		first = divider = last =
			new Node( T() );           // add dummy separator
	}

	~LockFreeQueue() 
	{
		while( first != NULL ) 
		{   // release the list
			Node* tmp = first;
			first = tmp->next;
			delete tmp;
		}
	}

	void Produce( const T& t )
	{
		last->next = new Node(t);  	// add the new item
		InterlockedExchangePointer(&last, last->next);

		for (void *iter = first; InterlockedCompareExchangePointer((void **)&iter, NULL, (void *)divider), iter; iter = first)
		{
			Node* tmp = first;
			first = first->next;
			delete tmp;
		}
	}

	bool Consume( T& result ) 
	{
		void *test = divider;
		InterlockedCompareExchangePointer((void **)&test, NULL, (void *)last);

		if( test ) 
		{
			// if queue is nonempty
			result = divider->next->value; 	// C: copy it back

			test = divider;
			InterlockedExchangePointer(&divider, divider->next);
			((Node *)(test))->next = NULL;
			return true;          	// and report success
		}

		return false;           	// else report empty
	}
};

#endif
