// Game Developer Magazine (April 2010) Sample Code:
//
// Author: Nicholas Vining (mordred@icculus.org)
//
// Somewhere, somebody should probably have a license agreement for this file.
//
// This is demonstration code for the article on message-based multithreaded programming using an Erlang
// style message passing model. To build it, you will need SDL 1.2.14 (or above) and a recent distribution of the
// Boost C++ libraries. Everything will expect to find pointers to everything else.
//
// Usage:
//
// 1. Get a copy of Boost, and a copy of SDL.
// 2. Place source code in a Visual Studio solution of your choice. Provide appropriate include and linking paths.
// 3. Run the application! Make sure you have a correct version of SDL.dll in the run time directory, and a copy of the
// attached test bitmap.
// 4. Enjoy the sight of 200 tiny kittens on your screen, running across four processors.

#include "lockfreequeue.h"
#include "actor.h"
#include <string>

#include "SDL.h"

// Utility random number-y functions.

inline int Random2(int max)

{
	if (max < 1 || max >= RAND_MAX)
		return 0;
	else
		return (int) rand() / (RAND_MAX / max + 1);
}

inline bool OneChanceIn(int a_million)
{
	return (Random2(a_million) == 0);
}

inline bool CoinFlip() 
{
	return OneChanceIn(2);
}

// Actor material.

typedef enum
{
	ACTORMESSAGE_SET_RENDERER,
	ACTORMESSAGE_QUIT_APPLICATION

} ActorMessageType;

// This is not a great message structure, but it will do for this demonstration.

struct ActorMessage
{
	ActorMessageType messageType;
	ActorTemplateBase *renderer;
};

typedef enum
{
	RM_CREATE_ACTOR,
	RM_MOVE_ACTOR,
	RM_RENDER_SCREEN
} RendererMessageType;

struct RendererMessage
{
	public:
		int messageType;

		class TestActor *actor;
		ActorTemplateBase *actorThread;
		int xPos;
		int yPos;
		int sprite;	
};

class TestActor
{
	private:
		int actorID;
		static int nextID;

		ActorTemplateBase *renderer;

		int x;
		int y;
		int dirX;
		int dirY;

	public:
		
		TestActor()
		{
			actorID = nextID;
			nextID++;

			x = Random2(800);
			y = Random2(800);
			dirX = CoinFlip() ? -1 : 1;
			dirY = CoinFlip() ? -1 : 1;
		};

		~TestActor()
		{
			
		};

		void SetRenderer (ActorTemplateBase *a_renderer)
		{
			renderer = a_renderer;
		}

		ActorMessageResponse ParseMessage ( const boost::any &message )
		{
			if (!message.empty())
			{
				ActorMessage msg = boost::any_cast<ActorMessage>(message);

				if (msg.messageType == ACTORMESSAGE_SET_RENDERER)
				{
					SetRenderer(msg.renderer);					
				}				
				
				if (msg.messageType == ACTORMESSAGE_QUIT_APPLICATION)
				{
					return AMR_KILL_ACTOR;				// get me out of here!
				}

				return AMR_CONTINUE;
			}

			// I got an empty message. If we reached this point, assume that I want to do something. Say... send the renderer a message telling it where
			// to draw me. (In fact, we could have an actor message, say, AMR_TICK, to do this. There are lots of ways to do scheduling here.)

			// So let's update our position with the renderer!

			{
				RendererMessage message;
				message.messageType = RM_MOVE_ACTOR;
				message.actor = this;			
				
				x += dirX;
				y += dirY;

				message.xPos = x;
				message.yPos = y;
				renderer->SendAMessage(message);				

				if (OneChanceIn(10))
				{
					dirX *= -1;
				}
				if (OneChanceIn(10))
				{
					dirY *= -1;
				}
			}

			return AMR_CONTINUE;
		}
};

int TestActor::nextID = 0;

// Here's the renderer thread.

class RendererThread
{
	struct ActorPosition
	{
		TestActor *actor;
		ActorTemplateBase *actorThread;
		int x;
		int y;
		int sprite;	
	};

	private:

		// Keep your data hidden! This will reduce the likelihood of anything going wrong.

		SDL_Surface *screen;
		SDL_Surface *actorSprite;

		// Our local copy of the actor positions.

		std::list<ActorPosition> actorPositions;

		ActorTemplateBase *__myself;

	public:

		// When we create the renderer thread, initialize SDL.

		RendererThread()
		{
			SDL_Init(SDL_INIT_VIDEO);
			screen = SDL_SetVideoMode(800, 600, 32, 0);		// whatever.

			// Create some dummy surfaces.

			actorSprite = SDL_LoadBMP("testobject.bmp");			// Tiny adorable kitten art provided by David Baumgart.
			SDL_SetColorKey(actorSprite, SDL_SRCCOLORKEY, 0);
		}

		void SetThreadActor (ActorTemplateBase *b)
		{
			__myself = b;		
		}

		~RendererThread()
		{

		}
 
		ActorMessageResponse ParseMessage ( const boost::any &message )
		{
			if (!message.empty())
			{
				RendererMessage m = boost::any_cast<RendererMessage>(message);

				if (m.messageType == RM_CREATE_ACTOR)
				{
					ActorPosition p;
					p.actor = m.actor;
					p.actorThread = m.actorThread;
					p.sprite = 0;
					p.x = 0;
					p.y = 0;
					actorPositions.push_back(p);
				}
				else if (m.messageType == RM_MOVE_ACTOR)
				{
					for (std::list<ActorPosition>::iterator iter = actorPositions.begin(); iter != actorPositions.end(); ++iter)
					{
						if (iter->actor == m.actor)
						{
							iter->x = m.xPos;
							iter->y = m.yPos;
						}
					}
				}
			}
			else
			{
				// Okay, so we didn't really get a message. We just got a poke from ourselves reminding ourselves to update the screen.								

				SDL_FillRect(screen, NULL, 0x00000000);

				for (std::list<ActorPosition>::iterator iter = actorPositions.begin(); iter != actorPositions.end(); ++iter)
				{
					SDL_Rect r;
					r.x = iter->x;
					r.y = iter->y;
					r.w = actorSprite->w;
					r.h = actorSprite->h;
					SDL_BlitSurface(actorSprite, NULL, screen, &r);
				}

				SDL_Flip(screen);				

				static int lastTicks = SDL_GetTicks();
				int curTicks = SDL_GetTicks();

				
				// update other sprites at 50 Hz
				if (curTicks - lastTicks > 20)
				{
					lastTicks = curTicks;
					for (std::list<ActorPosition>::iterator iter = actorPositions.begin(); iter != actorPositions.end(); ++iter)
					{
						// Hey, guys, we need to update!
						iter->actorThread->SendAMessage(EmptyMessage);
					}					
				}

				// Pump events.

				SDL_Event event;
				while (SDL_PollEvent(&event))
				{
					if (event.type == SDL_KEYUP && event.key.keysym.sym == SDLK_ESCAPE)
					{
						ActorMessage m;
						m.messageType = ACTORMESSAGE_QUIT_APPLICATION;

						for (std::list<ActorPosition>::iterator iter = actorPositions.begin(); iter != actorPositions.end(); ++iter)
						{
							// Hey, guys, we need to update!
							iter->actorThread->SendAMessage(m);
						}
						return AMR_KILL_ACTOR;
					}
				}

				// Instruct the threading system to make sure that we do get processed again.

				return AMR_SEND_NULL_MESSAGE;
			}

			return AMR_CONTINUE;
		}
};


// Entry point for the program.

int main ( int argc, char *argv[] )
{

	// Create renderer thread.

	ActorTemplate<RendererThread> *rendererThread = new ActorTemplate<RendererThread>;
	ActorManager::p()->AddActor(rendererThread);

	RendererMessage m;

	// Make sure we render *something* to the screen.

	m.messageType = RM_RENDER_SCREEN;

	rendererThread->SendAMessage(EmptyMessage);						// Throw ourselves a first, empty, message, to make sure the render queue does its thing.

	// Make sure that we know how to get set up here. I'm really not happy with this message passing right now,
	// but it will do for this small demonstration.

	for (int i = 0; i < 200; i++)
	{	
		ActorTemplate<TestActor> *test = new ActorTemplate<TestActor>;
		ActorManager::p()->AddActor(test);

		ActorMessage m;

		m.messageType = ACTORMESSAGE_SET_RENDERER;
		m.renderer = rendererThread;

		test->SendAMessage(m);
		test->SendAMessage(EmptyMessage);
		RendererMessage message;

		message.messageType = RM_CREATE_ACTOR;
		message.actor = test->GetImpl();
		message.actorThread = test; 
		rendererThread->SendAMessage(message);

		// Kick the actors!
	}

	// Set the whole thing going across 4 threads. No shared data required!

	ActorManager::p()->Go(4);

	return 0;
}

