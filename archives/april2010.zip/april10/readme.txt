This is the sample code to accompany my article on message-based multi-threaded programming in the April 2010 issue of
Game Developer Magazine. I'm not sure what license it's under; as far as I am concerned, I would like you to use this
source code if you find it useful or educational, and would appreciate you dropping me a line and telling me what
you're doing with it.




To build this:

I have never gotten somebody else's .SLN file to work correctly, and unless you are going so far as to embed an entire
copy of the Boost and SDL source trees in the ZIP file, it's pretty much impossible to make a distribution for a project
like this that compiles out of the box on everybody's computer. If you're interested in multi-threaded programming, chances
are you know how to create a Visual Studio solution, and how to make the compiler and linker work. :) I have verified that this compiles with MSVC 2008, and I would be surprised if worked out of the box with anything else. You will need a recent
copy of the Boost library, and a recent copy of SDL 1.2.



Some general thoughts that didn't make it into the article:

- It turns out that building a good message-passing architecture in C++ is probably worthy of its own article. The one
included in main.cpp isn't great, but it will do. The good news, of course, is that because we are using boost::any<>, you
can just pass whatever sort of messages you like and can do whatever works best for your particular style of programming
and object hierarchy. It's as close as we'll get to a dynamically typed language while still being C++ programmers, anyhow.

- There is some room for optimization. I think we spend too much time doing memory allocation, but I haven't profiled
carefully to figure out where the bottlenecks are in the current system. If anybody has a lock-free, thread-safe micro-allocator that can neatly be dropped into the current system, I'd love to hear about it.

- Race conditions are hard. The demo application doesn't have any race conditions - in fact, it's designed so that it
doesn't! - but I spent seven hours debugging a race condition in the messaging library itself. After chasing it all the
way through the lock-free queue code and back again, and fiddling with everything from compiler settings to shoving the
"volatile" keyword on everything and hoping it works, it turns out that I'd just forgotten a mutex lock and unlock. I think this experience reinforces the point of the article: even when your program only has two mutexes, concurrent-data based programming is still hard!



Cheers,

Nicholas