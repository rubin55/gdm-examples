#ifndef __ACTOR_H_
#define __ACTOR_H_

#include "lockfreequeue.h"
#include "boost/thread.hpp"
#include "boost/any.hpp"

typedef enum
{
	// Normality.

	AMR_CONTINUE = 0,

	// This actor wishes to die. Get its template out of the message queue.

	AMR_KILL_ACTOR,

	// Sometimes we want an actor to send itself a parse message. This gets recursive and hideous fast. In Erlang,
	// most of the situations where you would encounter this would be handled by tail recursion, which we don't have
	// in C++. As a quick hack, we simply allow ParseMessage() functions to send a simple "Hey, kick me!" message.

	AMR_SEND_NULL_MESSAGE

} ActorMessageResponse;

extern boost::any EmptyMessage;

// Virtual base class.

class ActorTemplateBase
{
	public:
		
		virtual ~ActorTemplateBase() {};
		virtual void SendAMessage ( const boost::any &message ) = 0;
		virtual bool PumpMessages() = 0;
};

template < class T > class ActorTemplate : public ActorTemplateBase
{
	private:
		LockFreeQueue<boost::any> messageQueue;

		// Note: we never need a read mutex here, because we are the only thing reading our messages.

		boost::mutex writeMutex;

		// By making this private, we give ourselves some measure of security.

		T *impl;


	public:


		ActorTemplate()
		{
			impl = new T;			
		};

		virtual ~ActorTemplate()
		{
			if (impl)
			{
				delete impl;
				impl = NULL;
			}
			
		};

		virtual T *GetImpl() { return impl; }

		// We have to call this SendAMessage to avoid conflict with the appropriate Windows function (and resulting predefines... ugh.)

		virtual void SendAMessage ( const boost::any &message )
		{
			writeMutex.lock();
			messageQueue.Produce(message);
			writeMutex.unlock();
		}

		// Pump the message queue. Returns "true" if we need to add this sucker to the queue again.

		virtual bool PumpMessages()
		{
			boost::any result;			

			bool mustKill = FALSE;
			bool mustAddNull = FALSE;

			while (messageQueue.Consume(result))
			{
				ActorMessageResponse response = impl->ParseMessage(result);				

				if (response == AMR_KILL_ACTOR)
				{
					mustKill = TRUE;
				}
				if (response == AMR_SEND_NULL_MESSAGE)
				{
					mustAddNull = TRUE;
				}
			}	

			if (mustAddNull)
			{
				SendAMessage(EmptyMessage);
			}

			return (!mustKill);
		}
};

// Actor manager singleton.

class ActorManager
{
	private:
		static ActorManager *__p;
		ActorManager();

		LockFreeQueue<ActorTemplateBase *> actorQueue;
		boost::mutex actorQueueReadMutex;
		boost::mutex actorQueueWriteMutex;


		int __threadID;

	public:

		void PumpThreadLoop( int threadID );

		static ActorManager* p()
		{
			if (__p == NULL)
			{
				__p = new ActorManager;
			}
			return __p;
		}

		// Add an actor to the queue. This is a thread-safe function.

		void AddActor( ActorTemplateBase *actor );

		// Call this to start the ActorManager class 

		void Go ( int numThreads );
		
};

#endif